package utils;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.model.Log;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class CreateReport {
	@Test
	public void name() throws IOException {
		//Report Path
		//D:\NewWorkspace\PageObjectModel\ => ./
		
		ExtentHtmlReporter html = new ExtentHtmlReporter("./reports/result.html");
		html.setAppendExisting(true);
		ExtentReports extent = new ExtentReports();
		extent.attachReporter(html);
		ExtentTest Login = extent.createTest("TC001Login", "Login to Leaftaps");
		Login.assignCategory("smoke");
		Login.assignAuthor("Sarath");
		
		//step report
		Login.pass("Enter Username is Successful",
				MediaEntityBuilder.createScreenCaptureFromPath("./output.png").build());

		Login.pass("Enter Password is Successful");
		Login.fail("Login is Clicked Successful");

		// Create Report And Clear Memory
		extent.flush();
	}

}







