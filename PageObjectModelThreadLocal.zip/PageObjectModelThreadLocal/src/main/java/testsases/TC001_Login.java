package testsases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;
import utils.ReadExcel;

public class TC001_Login extends PreAndPost{
	
	@BeforeTest
	public void setData() {
		testCaseName = "TC001Login";
		testDes = "Login to Leaftaps";
		category = "smoke";
		author = "sarath";  
		fileName = "TC001";
		module = "Leads";
	}
	
	

	@Test(dataProvider="getData")
	public void login(String uName,String pwd) {
		new LoginPage()
		.typeUserName(uName)
		.typePassword(pwd)
		.clickLogin()
		.clickLogOut();
		
	}
	
	
}
