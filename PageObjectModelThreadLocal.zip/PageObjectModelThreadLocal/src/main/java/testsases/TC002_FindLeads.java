package testsases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.HomePage;
import pages.LoginPage;

public class TC002_FindLeads extends PreAndPost{
	
	@BeforeTest
	public void setData() {
		testCaseName = "TC002 - Find Leads";
		testDes = "Find the new leads";
		category = "smoke";
		author = "sarath";  
		fileName = "TC001";
		module = "Leads";
	}
	

	@Test(dataProvider="getData")
	public void login(String uName,String pwd) {
	
		new LoginPage()
		.typeUserName(uName)
		.typePassword(pwd)
		.clickLogin()
		.clickCRMSFA();
	}
	
	
}
