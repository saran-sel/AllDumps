package runner;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import base.PreAndPost;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.TestNGCucumberRunner;

@CucumberOptions(features="src/main/java/features/login.feature", glue="pages")


public class RunnerCucumberTests extends PreAndPost {



	@BeforeTest
	public void setData() {

		TestNGCucumberRunner runner = new TestNGCucumberRunner(this.getClass());
		String scenarioName = runner.provideScenarios()[0][0].toString();
		System.out.println(scenarioName);

		testCaseName = scenarioName;
		testDes = "Login to Leaftaps";
		category = "CucumberTests";
		author = "Babu";  
		module = "Leads";
	}

	@DataProvider(parallel=true)
	public Object[][] scenarios() {
		return super.scenarios();
	}

}
