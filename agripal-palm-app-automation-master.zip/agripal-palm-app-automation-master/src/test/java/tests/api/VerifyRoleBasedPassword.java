package tests.api;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import lib.api.RESTAssuredBase;

public class VerifyRoleBasedPassword extends RESTAssuredBase{

	public static final String PALM = "1";
	public static final String RUBBER = "2";
	static String plantationType;
	String accessToken;
	String user_id;
	String role_id;
	String password;
	String firstName;
	static List<HashMap<Object, Object>> userListWithRoleID;
	static HashMap<String, String> rolePassword;
	List<HashMap<String, String>> createdUserDetails = new ArrayList();


	@Parameters({"plantation_Type_Id"})
	@BeforeTest
	public void setValues(String plantation_Type_Id) {

		testCaseName = "Verify RoleBased Password";
		testDescription = "Executing access token check for all users in DB - "
				+ "Failured set will be transferred to excel sheet at the end";
		nodes = "Access Token";
		authors = "Saravanan";
		category = "Integration";
		dataFileName = "data";
		dataFileType = "JSON";
		this.plantationType = plantation_Type_Id;

	}

	public static void getAllUserfromServer() {
		RESTAssuredBase api = new RESTAssuredBase();
		userListWithRoleID = api.db("select user_id , role_id , first_name from dbo.[user] where plantation_type_id=1 and is_deleted=0 and role_id != 8;", "SELECT");
		List<HashMap<Object, Object>> roleCodeListWithRoleID = api.db("select role_id , role_code from dbo.role where plantation_type_id=1;", "SELECT");
		rolePassword = new HashMap<>();
		for (HashMap<Object, Object> roleMap : roleCodeListWithRoleID) {
			rolePassword.put(roleMap.get("role_id").toString(), "Gabpa1"+roleMap.get("role_code").toString().toLowerCase()+"@1");
		}
	}

	@DataProvider(name="getUserList",parallel=true)
	public static Object[][] palmUserSet(){
		getAllUserfromServer();
		String[][] ret = new String[userListWithRoleID.size()][4];
		int rowNum = 0;
		for(HashMap<Object, Object> userMap : userListWithRoleID) {
			ret[rowNum][0] = userMap.get("user_id").toString();
			ret[rowNum][1] = userMap.get("role_id").toString();
			ret[rowNum][2] = rolePassword.get(userMap.get("role_id").toString());
			ret[rowNum][3] = userMap.get("first_name").toString();
			rowNum++;
		}
		return ret;

	}


	@Test(dataProvider="getUserList")
	public void verifyRoleBasedPassword(String userId,String roleId, String password,String firstName) {
		Map<String, String> headerMapForAccessToken;
		JSONObject requestParamsForAccessToken;
		Response response = null ;


		headerMapForAccessToken = new LinkedHashMap<>();
		headerMapForAccessToken.put("Content-Type", "application/json");
		requestParamsForAccessToken = new JSONObject();

		requestParamsForAccessToken.put("username", userId);
		requestParamsForAccessToken.put("password", password);

		//System.out.println(requestParamsForAccessToken.toJSONString());
		try {
			response = postWithHeaderAndJsonBody(headerMapForAccessToken, requestParamsForAccessToken.toJSONString(),"/user/retrieveToken");
			accessToken = getAccessToken(response, "data[0].accessToken");
			getAccessTokenTime = System.currentTimeMillis();
		}catch (Exception e) {
			System.out.println("Incorrect Password for -- role "+roleId + " - User--" + userId );
			HashMap<String,String> temp = new HashMap();
			temp.put("user_id",userId);
			temp.put("role_id",roleId);
			temp.put("first_Name",firstName);
			createdUserDetails.add(temp);

		}

	}

	@AfterTest
	public void printInvalidUsers() {

		if(createdUserDetails.size()!= 0) {

			try {

				XSSFWorkbook workbook = new XSSFWorkbook();
				XSSFSheet sheet = workbook.createSheet("Users");
				XSSFRow row=null;
				XSSFCell cell=null;

				for(int i = 0; i < createdUserDetails.size(); i++) {
					row = sheet.createRow(i);
					row.createCell(0).setCellValue(createdUserDetails.get(i).get("user_id"));
					row.createCell(1).setCellValue(createdUserDetails.get(i).get("role_id"));
					row.createCell(2).setCellValue(createdUserDetails.get(i).get("first_Name"));
					row.createCell(3).setCellValue(rolePassword.get(createdUserDetails.get(i).get("role_id").toString()));
				}
				try {

					FileOutputStream fos = new FileOutputStream(new File("./data/Password_Reset/UserListForPassword_Reset.xlsx"));
					workbook.write(fos);
					fos.close();
					workbook.close();

				} catch (Exception e) {

					e.printStackTrace();
				} 
			}catch(Exception e) {
				e.printStackTrace();
			}
		}else {
			System.out.println("No users found for Password Reset");
		}

	}

}







