package tests.api;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import lib.api.RESTAssuredBase;

public class VerifyUserRoleHeirarchy extends RESTAssuredBase {

	public static final String PALM = "1";
	public static final String RUBBER = "2";
	static String plantationType;
	String accessToken;
	String user_id;
	String role_id;
	String password;
	String firstName;
	static List<HashMap<Object, Object>> getWorkerList;
	static List<HashMap<Object, Object>> getReportingManagerList;
	static List<HashMap<Object, Object>> getManagerRoleIdList;
	static List<HashMap<Object, Object>> invalidMappingList;

	static HashMap<String, String> rolePassword;
	List<HashMap<String, String>> createdUserDetails = new ArrayList();

	ArrayList<String> userList = new ArrayList<>();
	ArrayList<String> managerList = new ArrayList<>();
	ArrayList<String> roleList = new ArrayList<>();


	@Parameters({"plantation_Type_Id"})
	@BeforeTest
	public void setValues(String plantation_Type_Id) {

		testCaseName = "Verify improper user heirarchy";
		testDescription = "Run access token check for all users and identify";
		nodes = "Access Token";
		authors = "Saravanan";
		category = "Integration";
		dataFileName = "data";
		dataFileType = "JSON";
		this.plantationType = plantation_Type_Id;

	}

	@DataProvider(name = "dataSet")
	public Object[][] createData1() {
		return new Object[][] {
			{ "8"},
			{ "5,6,16,17"},
			{ "4"},
			{ "3"},
			{ "2"},
			{ "1"},


		};
	}

	@Test(dataProvider="dataSet")
	public void getListOfInvalidHeirarchyUsers(String role_id) throws Exception {

		String roleId = role_id;
		String sheetName = null;

		String temp1 = "";
		String temp2 = "";
		String temp3 = "";
		String whereClause = "";

		System.out.println("select user_id from dbo.[user] where role_id in ("+roleId+") and is_deleted=0");

		getWorkerList = db("select user_id from dbo.[user] where role_id in ("+roleId+") and is_deleted=0", "SELECT");

		for (HashMap<Object, Object> obj : getWorkerList) {

			userList.add(obj.get("user_id").toString());
		}

		for (int i = 0; i < userList.size(); i++) {

			temp1= temp1+",'"+userList.get(i)+"'";

		}

		temp1 = temp1.substring(1,temp1.length());

		//System.out.println("WorkerList:::::"+temp1);


		getReportingManagerList = db("select distinct usr_id from dbo.user_reporting_hierarchy where reportee_user_id in ("+temp1+");", "SELECT");
		System.out.println("Q1:::"+"select distinct usr_id from dbo.user_reporting_hierarchy where reportee_user_id in ("+temp1+");");

		for (HashMap<Object, Object> obj : getReportingManagerList) {

			managerList.add(obj.get("usr_id").toString());
		}

		for (int i = 0; i < managerList.size(); i++) {

			temp2= temp2+",'"+managerList.get(i)+"'";

		}

		temp2 = temp2.substring(1,temp2.length());

		if(roleId.equals("8")) {
			sheetName = "Worker";
			getManagerRoleIdList = db("select user_id from dbo.[user] where user_id in ("  +temp2+  ") and role_id !=5 and role_id !=6 and role_id !=16 and role_id !=17", "SELECT");
		}
		else if(roleId.equals("5,6,16,17")) {
			sheetName = "CDQ";
			whereClause = " and b.role_id  != 8"; 
			//b.role_id = reportee role_id
			//c.role_id = manager role_id
			getManagerRoleIdList = db("select user_id from dbo.[user] where user_id in ("  +temp2+  ") and role_id !=4", "SELECT");

		}else if(roleId.equals("4")) {
			sheetName = "AM";
			whereClause = " and b.role_id  not in (5,6,16,17)"; 
			getManagerRoleIdList = db("select user_id from dbo.[user] where user_id in ("  +temp2+  ") and role_id !=3", "SELECT");

		}else if(roleId.equals("3")) {
			sheetName = "EM";
			whereClause = " and b.role_id  not in (4)"; 
			getManagerRoleIdList = db("select user_id from dbo.[user] where user_id in ("  +temp2+  ") and role_id !=2", "SELECT");

		}else if(roleId.equals("2")) {
			sheetName = "RM";
			whereClause = " and b.role_id  not in (3)"; 
			getManagerRoleIdList = db("select user_id from dbo.[user] where user_id in ("  +temp2+  ") and role_id !=1", "SELECT");

		}else if(roleId.equals("1")) {
			sheetName = "GM";
			whereClause = " and b.role_id  not in (2)"; 
			getManagerRoleIdList = db("select user_id from dbo.[user] where user_id in ("  +temp2+  ") and role_id !=7", "SELECT");
		}


		for (HashMap<Object, Object> obj : getManagerRoleIdList) {

			roleList.add(obj.get("user_id").toString());
		}

		for (int i = 0; i < roleList.size(); i++) {

			temp3= temp3+",'"+roleList.get(i)+"'";

		}

		temp3 = temp3.substring(1,temp3.length());
		System.out.println("roleList:::::"+temp3);

		System.out.println("Q3::::"+"select a.usr_id,c.role_id as 'User_Role_ID',a.reportee_user_id,b.role_id as 'Reportee_Role_ID',a.updated_timestamp\\r\\n\" + \r\n" + 
				"				\"from dbo.user_reporting_hierarchy a\\r\\n\" + \r\n" + 
				"				\"LEFT JOIN dbo.[user] b on b.user_id = a.reportee_user_id\\r\\n\" + \r\n" + 
				"				\"LEFT JOIN dbo.[user] c on c.user_id = a.usr_id\\r\\n\" + \r\n" + 
				"				\"where a.usr_id in ("+temp3+")"+whereClause+";");


		invalidMappingList = db("select a.usr_id,c.role_id as 'User_Role_ID',a.reportee_user_id,b.role_id as 'Reportee_Role_ID',a.updated_timestamp\r\n" + 
				"from dbo.user_reporting_hierarchy a\r\n" + 
				"LEFT JOIN dbo.[user] b on b.user_id = a.reportee_user_id\r\n" + 
				"LEFT JOIN dbo.[user] c on c.user_id = a.usr_id\r\n" + 
				"where a.usr_id in ("+temp3+")"+whereClause+";", "SELECT");


		String excelFilePath = "./data/User_Mapping/ImproperUserHeirarchy.xlsx";
		FileInputStream inputStream = new FileInputStream(new File(excelFilePath));

		XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
		XSSFSheet sheet = workbook.createSheet(sheetName);
		XSSFRow row=null;
		XSSFCell cell=null;

		row = sheet.createRow(0);
		row.createCell(0).setCellValue("UserID");
		row.createCell(1).setCellValue("User_Role_ID");
		row.createCell(2).setCellValue("Reportee_ID");
		row.createCell(3).setCellValue("Reportee_Role_ID");

		System.out.println("size of map"+invalidMappingList.size());

		for (int i = 0; i < invalidMappingList.size(); i++) {

			row = sheet.createRow(i+1);
			row.createCell(0).setCellValue(invalidMappingList.get(i).get("usr_id").toString());
			row.createCell(2).setCellValue(invalidMappingList.get(i).get("reportee_user_id").toString());
			row.createCell(1).setCellValue(invalidMappingList.get(i).get("User_Role_ID").toString());
			row.createCell(3).setCellValue(invalidMappingList.get(i).get("Reportee_Role_ID").toString());
		}

		//workbook.removeSheetAt(0);

		FileOutputStream fos = new FileOutputStream(excelFilePath);
		workbook.write(fos);
		fos.close();
		workbook.close();
	}


}
