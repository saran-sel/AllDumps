package tests.api;

import java.util.LinkedHashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import lib.api.RESTAssuredBase;

public class CreateFertilizationData extends RESTAssuredBase {

	public static final String PALM = "1";
	String plantationType = "";
	String accessToken;
	Map<String, String> headerMap = new LinkedHashMap<>();
	JSONObject requestParams = new JSONObject();
	String deviceID = getRandomString(15);

	@Parameters({ "plantation_Type_Id" })
	@BeforeTest
	public void setValues(String plantation_Type_Id) {

		this.plantationType = plantation_Type_Id;
		testCaseName = "Create Fertilization Data";
		testDescription = "Creating Fertilization data for all test users";
		nodes = "Fertilization Data";
		authors = "Saravanan";
		category = "Regression";
		dataFileName = "data";
		dataFileType = "JSON";

		getAccessToken();

	}

	public void getAccessToken() {

		Map<String, String> headerMapForAccessToken = new LinkedHashMap<>();
		JSONObject requestParamsForAccessToken = new JSONObject();

		headerMapForAccessToken.put("Content-Type", "application/json");

		requestParamsForAccessToken = new JSONObject();
		requestParamsForAccessToken.put("password", "olam");
		requestParamsForAccessToken.put("username", getValueFromListOfMap(db(
				"select TOP (1) user_id from [dbo].[user] where role_id in(select role_id from [dbo].[role] where role_code='PR' and plantation_type_id="
						+ plantationType + ")\r\n" + " and plantation_type_id=" + plantationType + " and is_deleted=0;",
				"SELECT"), null, null, "user_id"));

		Response response = postWithHeaderAndJsonBody(headerMapForAccessToken, requestParamsForAccessToken.toJSONString(),
				"/login/retrieveToken?plantationTypeId=" + plantationType);

		accessToken = getAccessToken(response, "data[0].accessToken");
		System.out.println("accessToken-----123" + accessToken);
		getAccessTokenTime = System.currentTimeMillis();

	}

	@DataProvider(name = "palmUserGangFertilization")
	public static Object[][] palmUserSet() {
		return getPalmUsersFertilization("User Details");
	}

	@Test(dataProvider = "palmUserGangFertilization")
	public void createFertilizationData(String username, String userRole, String fertilizerID, String locationCode) {

		int currentBlockID,latitude,longitude;
		String cordinates;
		String[] parts;
		
		getFertilizationData();
		if (username != null && userRole != null && fertilizerID != null && !"HAR".equals(userRole)) {
			
			System.out.println("Iam here");
			headerMap.put("Content-Type", "application/json");
			headerMap.put("Authorization", "Bearer " + accessToken);
			reportRequest("Access token generation successful and passed on to create Fertilization data", "PASS");

			requestParams = new JSONObject();
			requestParams.put("accuracy", 15);
			requestParams.put("balancedFertilizer", balance);
			requestParams.put("dosage", wrongDosage);
			requestParams.put("emptyFertilizer", empty);
			requestParams.put("frType", wrongType);
			requestParams.put("fertilizationId", 1);
			requestParams.put("harvesterUserId", fertilizerID);
			requestParams.put("balancedFertilizer", balance);

			if ("FER".equals(userRole)) {
				requestParams.put("isAudit", 0);
				reportRequest("Generated user is FERTILIZER, Audit value set to 0 ", "PASS");
			} else {
				reportRequest("Generated user is not a FERTILIZER, Audit value set to 1 ", "PASS");
				requestParams.put("isAudit", 1);
			}

			requestParams.put("isDeleted", false);
			requestParams.put("isGuest", false);
			
			requestParams.put("missedOut", 0);
			requestParams.put("placement", 0);
			requestParams.put("plantationTypeId", 1);
			requestParams.put("recordId", 0);
			requestParams.put("timeOfCapture", System.currentTimeMillis());
			requestParams.put("timeOfInsertion", System.currentTimeMillis());
			requestParams.put("timing", 1);
			requestParams.put("totalPalms", 10);
			requestParams.put("userId", username);
			requestParams.put("deviceId", "a5117739762df902");

			String estateloc = loc.get(fertilizerID).toString();
			Object divisionLoc = getValueFromListOfMap(
					db("select TOP (1) sub_location_id from [dbo].[geo_location_hierarchy] " + " where location_id="
							+ estateloc + ";", "SELECT"),
					null, null, "sub_location_id");
			//System.out.println("Division-------------" + divisionLoc);

			requestParams.put("plantId", gmLoc);
			requestParams.put("regionId", rmLocation);
			requestParams.put("estateId", estateloc);
			requestParams.put("divisionId", divisionLoc);

			requestParams.put("blockId",
					Integer.valueOf(getValueFromListOfMap(
							db("select TOP(1) sub_location_id from [dbo].[geo_location_hierarchy]"
									+ " where location_id = " + divisionLoc + ";", "SELECT"),
							null, null, "sub_location_id").toString()));
			
			reportRequest("Plant Region Estate Division Block ID's fetched from DB", "PASS");
			currentBlockID = Integer.valueOf(
					getValueFromListOfMap(db("select TOP(1) sub_location_id from [dbo].[geo_location_hierarchy]"
							+ " where location_id = "+divisionLoc+";", "SELECT"), null, null, "sub_location_id")
					.toString());
			
			cordinates = getValueFromListOfMap(db("select geolocation_json from [dbo].[geo_location_xref] where location_id='"+currentBlockID+"';", "SELECT"), null, null, "geolocation_json").toString();
			reportRequest("Based on Block ID XREF data fetched from DB", "PASS");
			parts = cordinates.split(",");
			
			reportRequest("Latitutude, Longitute processed and taken from DB", "PASS");
			requestParams.put("latitude", parts[3].replace("]", "").trim());
			requestParams.put("longitude", parts[2].replace("[", "").trim());

			System.out.println("[" + requestParams.toJSONString() + "]");

			Response response = postWithHeaderAndJsonBody(headerMap, "[" + requestParams.toJSONString() + "]",
					"/fertilization/saveFertilizationData");
			reportRequest("POST request successful with generated payload", "PASS");
			
			String retMessage =verifyContentsWithKeystring(response, "message", "Fertilization data recorded successfully");

			if(retMessage.equals("Token Expire")) {
				
				reportRequest("Token Expired! -Sit back and  relax, I will be generating new one for you ", "PASS");
				
				System.out.println("Regenerating New Access Token.....");
				getAccessToken();
				reportRequest("New Access token generation successful", "PASS");
				
				response = postWithHeaderAndJsonBody(headerMap, "[" + requestParams.toJSONString() + "]",
						"/fertilization/saveFertilizationData");
				reportRequest("Data saved with new access token generated", "PASS");
				

			}

			getValueFromListOfMap(db(
					"select * from [dbo].[palm_fertilizer] where record_id in (select record_id from [dbo].[fertilizer] where device_id='"
							+ deviceID + "');",
					"SELECT"), "empty_fertilizer", String.valueOf(empty) + ".00", "empty_fertilizer");
			
			reportRequest("Data saved in DB successfully and verified the same", "PASS");


			System.out.println(
					"select * from [dbo].[palm_fertilizer] where record_id in (select record_id from [dbo].[fertilizer] where device_id='"
							+ deviceID + "');");
			System.out.println(balance);

			deviceID = "REST" + getRandomString(7);

		}
	}

}
