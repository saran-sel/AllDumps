package tests.api;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import lib.api.RESTAssuredBase;

public class AttendanceDetails  extends RESTAssuredBase {
	
	public static final String PALM = "1";
	public static final int BIOMETRIC = 1;
	public static final int MANUAL = 2;
	String plantationType ="";
	String accessToken;
	Map<String, String> headerMap = new LinkedHashMap<>();
	JSONObject requestParams = new JSONObject();
	JSONObject activityParams = new JSONObject();
	String deviceID = "REST-"+getRandomString(7);
	String fingerPrintData = "AutoFP"+getRandomString(30);

	@Parameters({"plantation_Type_Id"})
	@BeforeTest
	public void setValues(String plantation_Type_Id) {

		this.plantationType=plantation_Type_Id;
		testCaseName = "Attendance Details";
		testDescription = "Retreiving registered users from DB, and creating Signin details";
		nodes = "Attendance Details - SignIn";
		authors = "Saravanan";
		category = "Regression";
		dataFileName = "data";
		dataFileType = "JSON";

		getAccessToken();

	}


	public void getAccessToken() {

		headerMap.put("Content-Type", "application/json");

		requestParams = new JSONObject();
		requestParams.put("password", "olam");
		requestParams.put("username", getValueFromListOfMap(db("select TOP (1) user_id from [dbo].[user] where role_id in(select role_id from [dbo].[role] where role_code='PR' and plantation_type_id="+plantationType+")\r\n" + 
				" and plantation_type_id="+plantationType+" and is_deleted=0;", "SELECT"), null, null, "user_id"));

		//requestParams.put("username", "000058");
		Response response = postWithHeaderAndJsonBody(headerMap, requestParams.toJSONString(),"/login/retrieveToken?plantationTypeId="+plantationType);

		accessToken = getAccessToken(response, "data[0].accessToken");
		System.out.println("accessToken-----"+accessToken);

	}
	
	@DataProvider(name="palmUserGang")
	public static Object[][] palmUserSet(){
		return getUsersForRegistration("User Details");
	}
	
	@Test(dataProvider="palmUserGang")
	public void user_signIn_signOut(String username,String userRole,String workerId, String location) {
		
		if(username != null && userRole != null  && !"GM".equals(userRole) && !"RM".equals(userRole)
				&& !"EM".equals(userRole) && !"AM".equals(userRole) ) {
		
		headerMap.put("Content-Type", "application/json");
		headerMap.put("Authorization","Bearer "+accessToken);
		reportRequest("Access token generation successful and passed on to create User Registration data", "PASS");
		
		requestParams = new JSONObject();

		requestParams.put("attendanceId", 0);
		requestParams.put("userId", username);
		requestParams.put("attendanceStatus", "string");
		requestParams.put("attendanceTransactionId", fingerPrintData);
		requestParams.put("cdqUserId", getValueFromListOfMap(db("select usr_id from [dbo].[user_reporting_hierarchy] where reportee_user_id='"+username+"';", "SELECT"), null, null, "usr_id"));
		requestParams.put("createdBy", getValueFromListOfMap(db("select usr_id from [dbo].[user_reporting_hierarchy] where reportee_user_id='"+username+"';", "SELECT"), null, null, "usr_id"));
		requestParams.put("createdCaptureTimestamp", System.currentTimeMillis());
		requestParams.put("createdTimestamp", System.currentTimeMillis());
		requestParams.put("deviceId", deviceID);
		requestParams.put("estateId", location);
		requestParams.put("lastUpdatedBy", getValueFromListOfMap(db("select usr_id from [dbo].[user_reporting_hierarchy] where reportee_user_id='"+username+"';", "SELECT"), null, null, "usr_id"));
		requestParams.put("lastUpdatedTimestamp", System.currentTimeMillis());
		requestParams.put("plantationTypeId", plantationType);
		requestParams.put("signinCaptureTimestamp", getMorningNineTimestamp());
		requestParams.put("signinTimestamp", getMorningNineTimestamp());
		requestParams.put("signinType", BIOMETRIC);
		requestParams.put("signoutCaptureTimestamp", "");
		requestParams.put("signoutTimestamp", "");
		requestParams.put("signoutType", "");
		ArrayList<JSONObject> objList = new ArrayList<>();
		activityParams.put("activityId", getValueFromListOfMap(db("select TOP (1) activity_id from [dbo].[user_activities_details] where UOM ='Hours';", "SELECT"), null, null, "activity_id"));
		activityParams.put("activityTransactionId", getRandomString(10));
		activityParams.put("attendanceTransactionId", fingerPrintData);
		activityParams.put("createdBy", getValueFromListOfMap(db("select usr_id from [dbo].[user_reporting_hierarchy] where reportee_user_id='"+username+"';", "SELECT"), null, null, "usr_id"));
		activityParams.put("createdCaptureTimestamp", System.currentTimeMillis());
		activityParams.put("createdTimestamp", System.currentTimeMillis());
		activityParams.put("duration", "9H : 00M");
		activityParams.put("isDeleted",false);
		activityParams.put("lastUpdatedBy",getValueFromListOfMap(db("select usr_id from [dbo].[user_reporting_hierarchy] where reportee_user_id='"+username+"';", "SELECT"), null, null, "usr_id"));
		activityParams.put("locationId", getValueFromListOfMap(db("select TOP (1) sub_location_id from [dbo].[geo_location_hierarchy] where location_id in (select TOP (1) sub_location_id from [dbo].[geo_location_hierarchy] where location_id="+location+")", "SELECT"), null, null, "sub_location_id"));
		activityParams.put("outputMetric", 20.999);
		activityParams.put("uom", "Hours");
		activityParams.put("userActivityId", 25);
		objList.add(activityParams);
		requestParams.put("userActivitiesDetails", objList);
		
		System.out.println("["+requestParams.toJSONString()+"]");
		
		
		
		Response response = postWithHeaderAndJsonBody(headerMap, "["+requestParams.toJSONString()+"]", "/eattendance/saveOrUpdateUserAttendanceDetails");
		verifyContentsWithKeystring(response, "message", "User Attendance data saved successfully");
		reportRequest("POST request successful with generated payload", "PASS");
		
		deviceID = "REST-"+getRandomString(7);
		fingerPrintData = "AutoFP"+getRandomString(10);
		
		}
		
	}

	

}
