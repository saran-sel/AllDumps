package tests.api;

import java.util.LinkedHashMap;
import java.util.Map;

import org.json.simple.JSONObject;

import io.restassured.RestAssured;
import io.restassured.authentication.PreemptiveBasicAuthScheme;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lib.api.RESTAssuredBase;

public class Sage_yActivity extends RESTAssuredBase {
	
	Map<String, String> headerMap = new LinkedHashMap<>();
	JSONObject requestParams = new JSONObject();
	
	
	//@Test
	
	public static void main(String[] args) {
		Sage_yActivity sg = new Sage_yActivity();
		sg.getYActivityFromSage();
	}
	public void getYActivityFromSage() {
		
		
		Response response = setLogs().given().auth()
		  .basic("DTF", "olam@123")
		  .when()
		  .get("http://localhost:8080/spring-security-rest-basic-auth/api/foos/1");
		
		response.prettyPrint();
		  
		
		/*headerMap.put("Content-Type", "application/json");
		PreemptiveBasicAuthScheme authScheme = new PreemptiveBasicAuthScheme();
		authScheme.setUserName("DTF");
		authScheme.setPassword("olam@123");
		
		Response withHeader = getWithHeader(headerMap, "http://10.110.11.102:8124/api1/x3/hrm/OLAMPAY/YACTIVITY?representation=YACTIVITYWS.$query&count=1000");
		
		withHeader.prettyPrint();*/
		
		
	}

}
