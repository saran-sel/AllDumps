package tests.api;

import lib.api.RESTAssuredBase;

public class DeleteCreatedData extends RESTAssuredBase{
    String SELECT_USER_QUERY = "select user_id from [dbo].[user] where email = 'createdByAutomation@olamnet.com' and created_on >= 1555501471577";
	public static void main(String[] args) {
		DeleteCreatedData deleteObj = new DeleteCreatedData();
		//select user ids to delete
		deleteObj.db("", "SELECT");
	}
}
