package tests.api;

import java.util.LinkedHashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import lib.api.RESTAssuredBase;

public class UserRegistration extends RESTAssuredBase {

	public static final String PALM = "1";
	String plantationType ="";
	String accessToken;
	Map<String, String> headerMap = new LinkedHashMap<>();
	JSONObject requestParams = new JSONObject();
	String deviceID = "REST-"+getRandomString(7);
	String fingerPrintData = "AutoFP"+getRandomString(10);


	@Parameters({"plantation_Type_Id"})
	@BeforeTest
	public void setValues(String plantation_Type_Id) {

		this.plantationType=plantation_Type_Id;
		testCaseName = "User Registration";
		testDescription = "Creating Bio-Metric Registration for created users";
		nodes = "User Registration";
		authors = "Saravanan";
		category = "Regression";
		dataFileName = "data";
		dataFileType = "JSON";

		getAccessToken();

	}


	public void getAccessToken() {

		headerMap.put("Content-Type", "application/json");

		requestParams = new JSONObject();
		requestParams.put("password", "olam");
		requestParams.put("username", getValueFromListOfMap(db("select TOP (1) user_id from [dbo].[user] where role_id in(select role_id from [dbo].[role] where role_code='PR' and plantation_type_id="+plantationType+")\r\n" + 
				" and plantation_type_id="+plantationType+" and is_deleted=0;", "SELECT"), null, null, "user_id"));

		//requestParams.put("username", "000058");
		Response response = postWithHeaderAndJsonBody(headerMap, requestParams.toJSONString(),"/login/retrieveToken?plantationTypeId="+plantationType);

		accessToken = getAccessToken(response, "data[0].accessToken");
		System.out.println("accessToken-----"+accessToken);

	}

	@DataProvider(name="palmUserGang")
	public static Object[][] palmUserSet(){
		return getUsersForRegistration("User Details");
	}

	@Test(dataProvider="palmUserGang")
	public void registerUser(String username,String userRole,String workerId,String location) {

		if(username != null && userRole != null  && !"GM".equals(userRole) && !"RM".equals(userRole)
				&& !"EM".equals(userRole) && !"AM".equals(userRole) ) {

			headerMap.put("Content-Type", "application/json");
			headerMap.put("Authorization","Bearer "+accessToken);
			reportRequest("Access token generation successful and passed on to create User Registration data", "PASS");

			requestParams = new JSONObject();

			requestParams.put("createdCaptureTimestamp", System.currentTimeMillis());
			requestParams.put("deviceId", deviceID);
			requestParams.put("estateId", Integer.valueOf(location));
			requestParams.put("fingerPrintData", fingerPrintData);
			requestParams.put("hrUserId", getValueFromListOfMap(db("select user_id from [dbo].[user] where user_id='778899';", "SELECT"), null, null, "user_id"));
			requestParams.put("isDeleted", false);
			requestParams.put("noOfFingersScanned", 10);
			requestParams.put("plantationTypeId", Integer.valueOf(plantationType));
			requestParams.put("userId", username);
			
			reportRequest("Payload created successfully with random input values", "PASS");

			System.out.println("["+requestParams.toJSONString()+"]");

			Response response = postWithHeaderAndJsonBody(headerMap, "["+requestParams.toJSONString()+"]", "/eattendance/saveUserBiomtericRegistrationDetails");
			
			reportRequest("POST request successful with generated payload", "PASS");
			
			verifyContentsWithKeystring(response, "message", "User Biometric Registration data saved successfully");
			deviceID = "REST-"+getRandomString(7);
			fingerPrintData = "AutoFP"+getRandomString(10);

		}

	}



}
