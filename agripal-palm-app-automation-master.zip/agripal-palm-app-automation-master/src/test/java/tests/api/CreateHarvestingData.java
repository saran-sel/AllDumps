package tests.api;

import java.util.LinkedHashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import lib.api.RESTAssuredBase;

public class CreateHarvestingData extends RESTAssuredBase {

	public static final String PALM = "1";
	String plantationType = "";
	String accessToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ik4tbEMwbi05REFMcXdodUhZbkhRNjNHZUNYYyIsImtpZCI6Ik4tbEMwbi05REFMcXdodUhZbkhRNjNHZUNYYyJ9.eyJhdWQiOiJodHRwczovL29sYW10ZXN0Lm9ubWljcm9zb2Z0LmNvbS8yOTY5ZTM2Mi1iMGYyLTQxMTUtOTgzYS03YjJiMDliNDNhMDkiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC85YWQ2ZTc4Ni0xNzkyLTQxNWItOGNiOS1mYmM5ZGY5NjAxNDkvIiwiaWF0IjoxNTU1NDMwMjg2LCJuYmYiOjE1NTU0MzAyODYsImV4cCI6MTU1NTQzNDE4NiwiYWNyIjoiMSIsImFpbyI6IjQyWmdZUGp0YlA1dHlpS0hxTFVxdTMrSnVqSVpwd2o4NmVHNXB4SS96K1A2WGsyeHRpb0EiLCJhbXIiOlsicHdkIl0sImFwcGlkIjoiZDM4YWE5YjctZmRkMS00OGYzLTg1YjktMGJkYTgzMzk2NWZkIiwiYXBwaWRhY3IiOiIwIiwiZmFtaWx5X25hbWUiOiJIQVIiLCJnaXZlbl9uYW1lIjoiMTAzODMxIiwiaXBhZGRyIjoiNTEuMTQwLjcuMTIxIiwibmFtZSI6IjEwMzgzMSIsIm9pZCI6ImZiMTA0ODk0LThhMjgtNDMzYS04MjNmLTRkYWVhNDdlZmE2ZiIsInNjcCI6InVzZXJfaW1wZXJzb25hdGlvbiIsInN1YiI6Im5oSTNJanVmaE1PMzZ6ZVpHTmhxUWlTZmVEcE9nQzV0ejdLbHNyRk9ObUkiLCJ0aWQiOiI5YWQ2ZTc4Ni0xNzkyLTQxNWItOGNiOS1mYmM5ZGY5NjAxNDkiLCJ1bmlxdWVfbmFtZSI6IjEwMzgzMUBvbGFtdGVzdC5vbm1pY3Jvc29mdC5jb20iLCJ1cG4iOiIxMDM4MzFAb2xhbXRlc3Qub25taWNyb3NvZnQuY29tIiwidXRpIjoiWUxrdDh0RkJva2E1U3d4OFdKc21BQSIsInZlciI6IjEuMCJ9.bgt0dr44FRxQIo81KapQaClKZUm7czwrN5dWS51v2ZVh5gRUC-urUeil79V3SXxVeNzBWqWHA9gdr0AjtTr02Bfl0rtX-FgwwhQH_9pEIamxYUgqq79h-4IlauVRyf3cKnywHkfMtHZ7sDvcIbi_W_25nAXfgdKUAaiI-lDUtGY1gvV3LYkksTVQGS-vUcMkZmv6tY_kPmMLi_o_VU4XiXEnWbDkwCxwKfIoX9o-ngNsu7IUn9WlNVogeNKFjtAvTRs6emMptAnzM9BDtdJOwK3vCKurF8SObM3CPGm6dmZ3g1jYq4vE8gwGajUn20Cyj74YCY3nKAAsg5qoy582Ug";
	Map<String, String> headerMap = new LinkedHashMap<>();
	JSONObject requestParams = new JSONObject();
	String deviceID = String.valueOf(getRandomId());

	@Parameters({ "plantation_Type_Id" })
	@BeforeTest
	public void setValues(String plantation_Type_Id) {

		this.plantationType = plantation_Type_Id;
		testCaseName = "Create Harvesting Data";
		testDescription = "Creating Harvest data for all test users";
		nodes = "Harvesting Data";
		authors = "Saravanan";
		category = "Regression";
		dataFileName = "data";
		dataFileType = "JSON";

		getAccessToken();

	}

	public void getAccessToken() {

		Map<String, String> headerMapForAccessToken = new LinkedHashMap<>();
		JSONObject requestParamsForAccessToken = new JSONObject();

		headerMapForAccessToken.put("Content-Type", "application/json");

		requestParamsForAccessToken = new JSONObject();
		requestParamsForAccessToken.put("password", "olam");
		requestParamsForAccessToken.put("username", getValueFromListOfMap(db(
				"select TOP (1) user_id from [dbo].[user] where role_id in(select role_id from [dbo].[role] where role_code='PR' and plantation_type_id="
						+ plantationType + ")\r\n" + " and plantation_type_id=" + plantationType + " and is_deleted=0;",
				"SELECT"), null, null, "user_id"));

		Response response = postWithHeaderAndJsonBody(headerMapForAccessToken, requestParamsForAccessToken.toJSONString(),
				"/login/retrieveToken?plantationTypeId=" + plantationType);

		accessToken = getAccessToken(response, "data[0].accessToken");
		System.out.println("accessToken-----" + accessToken);
		getAccessTokenTime = System.currentTimeMillis();

	}

	@DataProvider(name = "palmUserGang")
	public static Object[][] palmUserSet() {
		return getPalmUsersHarvest("User Details",false);
	}

	@Test(dataProvider = "palmUserGang")
	public void createHarvestingData(String username, String userRole, String harvesterID, String locationCode) {

		String obj = this.deviceID;
		getHarvestData();
		int currentBlockID,latitude,longitude;
		String cordinates;
		String[] parts;
		
		if (username != null && userRole != null && harvesterID != null && !"FER".equals(userRole)) {
			headerMap.put("Content-Type", "application/json");
			headerMap.put("Authorization", "Bearer " + accessToken);
			reportRequest("Access token generation successful and passed on to create Harvest data", "PASS");
			
			//System.out.println("Iam with: "+accessToken);
			requestParams = new JSONObject();
			requestParams.put("accuracy", 22.98200035095215);

			String estateloc = loc.get(harvesterID).toString();
			Object divisionLoc = getValueFromListOfMap(
					db("select TOP (1) sub_location_id from [dbo].[geo_location_hierarchy] " + " where location_id="
							+ estateloc + ";", "SELECT"),
					null, null, "sub_location_id");
			//System.out.println("Division-------------" + divisionLoc);
		
			requestParams.put("plantId", Integer.valueOf(gmLoc));
			requestParams.put("regionId", Integer.valueOf(rmLocation));
			requestParams.put("estateId", Integer.valueOf(estateloc));
			requestParams.put("divisionId", divisionLoc);

			requestParams.put("blockId",
					Integer.valueOf(getValueFromListOfMap(
							db("select TOP(1) sub_location_id from [dbo].[geo_location_hierarchy]"
									+ " where location_id = " + divisionLoc + ";", "SELECT"),
							null, null, "sub_location_id").toString()));
			reportRequest("Plant Region Estate Division Block ID's fetched from DB", "PASS");
			currentBlockID = Integer.valueOf(
					getValueFromListOfMap(db("select TOP(1) sub_location_id from [dbo].[geo_location_hierarchy]"
							+ " where location_id = "+divisionLoc+";", "SELECT"), null, null, "sub_location_id")
					.toString());
			
			cordinates = getValueFromListOfMap(db("select geolocation_json from [dbo].[geo_location_xref] where location_id='"+currentBlockID+"';", "SELECT"), null, null, "geolocation_json").toString();
			reportRequest("Based on Block ID XREF data fetched from DB", "PASS");
			parts = cordinates.split(",");
			reportRequest("Latitutude, Longitute processed and taken from DB", "PASS");
			
			requestParams.put("timeOfCapture", System.currentTimeMillis());
			requestParams.put("timeOfInsertion", 0);
			requestParams.put("bunchQualityTotalBunches", bunchQualityTotalBunches);
			requestParams.put("circle", circle);
			requestParams.put("syncId", 0);
			requestParams.put("cropRecoveryTotalBunches", cropRecoveryTotalBunches);
			requestParams.put("deviceId", "a5117739762df902");
			requestParams.put("diseasedBunches",diseasedBunches );
			requestParams.put("emptyBunch", emptyBunches);
			requestParams.put("frondExile", frondExile);
			requestParams.put("harvestId", 18);

			if (!userRole.equals("HAR")) {
				requestParams.put("isAudit", true);
				reportRequest("Generated user is HARVESTOR, Audit value set to 1 ", "PASS");
				
			} else {
				requestParams.put("isAudit", false);
				reportRequest("Generated user is not a HARVESTOR, Audit value set to 0 ", "PASS");
			}
			
			requestParams.put("isDeleted", false);
			requestParams.put("latitude", parts[3].replace("]", "").trim());
			requestParams.put("longitude", parts[2].replace("[", "").trim());
			requestParams.put("lfPath", Integer.valueOf("3"));
			requestParams.put("longStalk", Integer.valueOf("3"));
			requestParams.put("overRipe", overRipe);
			requestParams.put("platform", Integer.valueOf("3"));
			requestParams.put("recordId", 0);
			requestParams.put("ripe", ripe);
			requestParams.put("sickBunches", sickBunches);
			requestParams.put("uncollectedBunches", Integer.valueOf("3"));
			requestParams.put("underRipe", underRipe);
			requestParams.put("unharvestedBunches", Integer.valueOf("3"));
			requestParams.put("collectedLooseFruits", Integer.valueOf("3"));
			requestParams.put("unripeBunches", unripeBunches);
			requestParams.put("userId", username);
			requestParams.put("harvesterUserId", harvesterID);
			
			reportRequest("Payload created successfully with random input values", "PASS");

			System.out.println("[" + requestParams.toJSONString() + "]");

			Response response = postWithHeaderAndJsonBody(headerMap, "[" + requestParams.toJSONString() + "]",
					"/harvest/saveHarvestData");
			
			reportRequest("POST request successful with generated payload", "PASS");

			String retMessage = verifyContentsWithKeystring(response, "message", "Harvest data recorded successfully");

			if(retMessage.equals("Token Expire")) {
				
				reportRequest("Token Expired! -Sit back and  relax, I will be genarating new one for you ", "PASS");
				
				System.out.println("Regenerating New Access Token.....");
				getAccessToken();
				
				reportRequest("New Access token generation successful", "PASS");
				response = postWithHeaderAndJsonBody(headerMap, "[" + requestParams.toJSONString() + "]",
						"/harvest/saveHarvestData");
				reportRequest("Data saved with new access token generated", "PASS");
			
			}

			getValueFromListOfMap(
					db("select * from [dbo].[harvesting] where user_id='" + username + "' and harvester_user_id='"
							+ harvesterID + "' and device_id='" + deviceID + "';", "SELECT"),
					"device_id", deviceID, "device_id");
			
			reportRequest("Data saved in DB successfully and verified the same", "PASS");

			/*System.out.println("select * from [dbo].[harvesting] where user_id='" + username
					+ "' and harvester_user_id='" + harvesterID + "' and device_id='" + deviceID + "';");
			 */
			deviceID = String.valueOf(getRandomId());

		}
	}

}
