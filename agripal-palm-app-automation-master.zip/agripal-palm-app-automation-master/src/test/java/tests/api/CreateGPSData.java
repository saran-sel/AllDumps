package tests.api;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;

import org.json.simple.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import lib.api.RESTAssuredBase;

public class CreateGPSData extends RESTAssuredBase {

	public static final String PALM = "1";
	String plantationType = "";
	String accessToken;
	Map<String, String> headerMap = new LinkedHashMap<>();
	JSONObject requestParams = new JSONObject();
	JSONObject additionalParams1 = new JSONObject();
	JSONObject additionalParams2 = new JSONObject();
	String deviceID = String.valueOf(getRandomId());
	int currentBlockID,latitude,longitude;
	String cordinates;
	String[] parts;
	int latLongCount = 0;

	String startingPointLat,startingPointLong, wayPointLat, wayPointLong, endingPointLat, endingPointLong;

	@Parameters({ "plantation_Type_Id" ,"gpsStops"})
	@BeforeTest
	public void setValues(String plantation_Type_Id,int gpsStops) {
		this.latLongCount = gpsStops;
		this.plantationType = plantation_Type_Id;
		testCaseName = "Create GPS Trial";
		testDescription = "Creating GPS Trial data for all test users";
		nodes = "GPS Trial";
		authors = "Saravanan";
		category = "Regression";
		dataFileName = "data";
		dataFileType = "JSON";

		getAccessToken();

	}

	public void getAccessToken() {

		Map<String, String> headerMapForAccessToken = new LinkedHashMap<>();
		JSONObject requestParamsForAccessToken = new JSONObject();

		headerMapForAccessToken.put("Content-Type", "application/json");

		requestParamsForAccessToken = new JSONObject();
		requestParamsForAccessToken.put("password", "olam");
		requestParamsForAccessToken.put("username", getValueFromListOfMap(db(
				"select TOP (1) user_id from [dbo].[user] where role_id in(select role_id from [dbo].[role] where role_code='PR' and plantation_type_id="
						+ plantationType + ")\r\n" + " and plantation_type_id=" + plantationType + " and is_deleted=0;",
				"SELECT"), null, null, "user_id"));

		Response response = postWithHeaderAndJsonBody(headerMapForAccessToken,
				requestParamsForAccessToken.toJSONString(), "/login/retrieveToken?plantationTypeId=" + plantationType);

		accessToken = getAccessToken(response, "data[0].accessToken");
		System.out.println("accessToken-----" + accessToken);
		getAccessTokenTime = System.currentTimeMillis();

	}

	@DataProvider(name = "palmUserGang")
	public static Object[][] palmUserSet() {
		return getPalmUsersHarvest("User Details", false);
	}

	@Test(dataProvider = "palmUserGang")
	public void createGPSTrialForAllUsers(String username, String userRole, String workerId, String locationCode) {

		if (username != null && userRole != null && workerId != null && !"GM".equals(userRole)
				&& !"RM".equals(userRole) && !"EM".equals(userRole)) {
			
			reportRequest("Creating "+latLongCount+" latitude, longitude pairs for trial data", "PASS");
			reportRequest("GM, RM, EM ignored successfully from creating GPS", "PASS");
			String estateloc = loc.get(workerId).toString();
			Object divisionLoc = getValueFromListOfMap(
					db("select TOP (1) sub_location_id from [dbo].[geo_location_hierarchy] "
							+ " where location_id=" + estateloc + ";", "SELECT"),
					null, null, "sub_location_id");
			currentBlockID = Integer.valueOf(
					getValueFromListOfMap(db("select TOP(1) sub_location_id from [dbo].[geo_location_hierarchy]"
							+ " where location_id = "+divisionLoc+";", "SELECT"), null, null, "sub_location_id")
					.toString());
			reportRequest("User Block ID retreived successfully", "PASS");	
			
			cordinates = getValueFromListOfMap(db("select geolocation_json from [dbo].[geo_location_xref] where location_id='"+currentBlockID+"';", "SELECT"), null, null, "geolocation_json").toString();
			
			reportRequest("Based on Block ID XREF details fetched", "PASS");
			parts = cordinates.substring(cordinates.indexOf("coordinates\":")+15,cordinates.indexOf("\"type\":")-1).replace("[","").replace("]","").split(",");

			LinkedList<String> latList = new LinkedList<String>();
			LinkedList<String> longList = new LinkedList<>();
			int i =0;
			for (String part : parts) {
				if(i%2 == 0){
					longList.add(part);
				}else{
					latList.add(part);
				}
				i++;
			}
			
			reportRequest(latLongCount+" successfully retreived and processed", "PASS");
			
			System.out.println(latList);
			System.out.println(longList);
			System.out.println("running for: "+currentBlockID);
			String listRequestParams = "[";
			int diff = latList.size()/latLongCount;
			int index = 0;
			for(i = 0; i < latLongCount; i++){
				requestParams = new JSONObject();
				requestParams.put("accuracy", 0);
				requestParams.put("deviceId", deviceID);
				requestParams.put("gpsId", getRandomId());
				requestParams.put("insertTimestamp", System.currentTimeMillis());
				requestParams.put("latitude", latList.get(index));
				requestParams.put("longitude", longList.get(index));
				requestParams.put("plantationTypeId", plantationType);
				requestParams.put("recordId", getRandomId());
				requestParams.put("timeofCapture", System.currentTimeMillis());
				requestParams.put("userId", username);
				index = index + diff;
				listRequestParams = listRequestParams + requestParams.toJSONString()+",";
			}
			
			reportRequest(latLongCount+" no of payload's generated automatically", "PASS");
			listRequestParams = listRequestParams.substring(0,listRequestParams.length()-1) + "]";
			System.out.println("Final Payload ---- "+listRequestParams);
			headerMap.put("Content-Type", "application/json");
			headerMap.put("Authorization", "Bearer " + accessToken);
			reportRequest("Access token generation successful and passed on to create Quick Note data", "PASS");

			Response response = postWithHeaderAndJsonBody(headerMap,listRequestParams,"/GPS/saveGPSData");
			reportRequest("POST request successful with generated payload", "PASS");
			
			String retMessage = verifyContentsWithKeystring(response, "message", "GPS data recorded successfully");
			if (retMessage.equals("Token Expire")) {
				
				reportRequest("Token Expired! -Sit back and  relax, I will be generating new one for you ", "PASS");
				System.out.println("Regenerating New Access Token.....");
				getAccessToken();
				reportRequest("New Access token generation successful", "PASS");

				response = postWithHeaderAndJsonBody(headerMap, "[" + requestParams.toJSONString() + ","
						+ additionalParams1.toJSONString() + "," + additionalParams2.toJSONString() + "]",
						"/GPS/saveGPSData");
				
				reportRequest("Data saved with new access token generated", "PASS");
			}

			/*verifyDB("select * from [dbo].[gps_data] where user_id = '" + username + "' and device_id='" + deviceID
					+ "';", "SELECT", "device_id", "deviceID", "device_id");*/
			deviceID = String.valueOf(getRandomId());
		}
	}
}

