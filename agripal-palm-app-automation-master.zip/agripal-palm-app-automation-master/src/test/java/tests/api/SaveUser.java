package tests.api;

import static org.testng.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.Set;

import org.json.simple.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import lib.api.RESTAssuredBase;
import lib.utils.UserModel;

public class SaveUser extends RESTAssuredBase{

	Properties prop;
	public static final String PALM = "1";
	public static final String RUBBER = "2";
	public boolean isFailed = false;
	private static final String SUCCESS_MSG = "Data saved successfully";
	public int reportingCount = 1;
	public String reporting_Id = null;
	public String reporting_Type = null;
	int estate = 0;
	boolean canCreateNOG = false;
	String regionCode;
	String gmLoc;
	Map<String, String> headerMap = new HashMap<>();
	JSONObject requestParams = new JSONObject();
	List<HashMap<Object, Object>> roleList;
	List<HashMap<Object, Object>> locationList;
	List<HashMap<Object, Object>> locationhier;
	HashMap<Integer,LinkedList<UserModel>> reportingIds = new HashMap<>();
	LinkedHashMap<String,String> workerReporting = new LinkedHashMap<>();
	HashMap<String,Integer> reportingMap = new HashMap<>();
	static List<LinkedHashMap<String, String>> createdUserDetails = new ArrayList();
	Set<String> successIds = new HashSet<>();
	static String plantationType;
	int estateCount;
	String accessToken;
	List<Object> estateCodes;
	String adminToken ;
	List<HashMap<Object, Object>> gmMap = null;
	List<HashMap<Object, Object>> rmMap = null;
	
	public SaveUser() {
		prop = loadObjectRepository();
	}
	
	@Parameters({"plantation_Type_Id","estate_count","createNOG"})
	@BeforeTest
	public void setValues(String plantation_Type_Id,int estate_count,boolean createNOG) {
		adminToken = getAdminTokenForAD();
		this.estateCount = estate_count;
		this.canCreateNOG = createNOG;
		this.plantationType=plantation_Type_Id;
		System.out.println("Number of Estates -- "+estateCount);
		System.out.println("Plantation Type -- "+plantationType);
		System.out.println("Create NOG -- "+createNOG);
		testCaseName = "Create new users";
		testDescription = "Get the latest access token and create user gang through rest api";
		nodes = "Access Token";
		authors = "Saravanan";
		category = "smoke";
		dataFileName = "data";
		dataFileType = "JSON";
		roleList = db("select * from dbo.role  where plantation_type_id ="+plantationType,"SELECT");
		locationList = db("select * from geo_location  where plantation_type_id ="+plantationType,"SELECT");
		locationhier = db("select * from [dbo].[geo_location_hierarchy] where plantation_type_id  ="+plantationType,"SELECT");
		reportingMap.put("GM", 1);
		// Below to be changed from DB
		if(plantationType.equals(PALM)) {
			reportingMap.put("RM", 2);
			reportingMap.put("EM", 3);
			reportingMap.put("AM", 4);
			reportingMap.put("HAR", 5);
			reportingMap.put("FER", 5);
			reportingMap.put("WOR", 6);
			reportingMap.put("NOG", -1);
			reportingMap.put("SNOG", -1);
		}else {
			reportingMap.put("EM", 2);
			reportingMap.put("AM", 3);
			reportingMap.put("TAP", 4);
			reportingMap.put("FER", 4);
			reportingMap.put("WOR", 5);
			reportingMap.put("NOG", -1);
			reportingMap.put("SNOG", -1);
		}
		gmMap = db("select TOP(1) user_id, location_id from [dbo].[user] where role_id ="+ 
				getValueFromListOfMap(roleList,"role_code","GM","role_id").toString()  + 
				"and is_deleted = 0","SELECT");
		gmLoc = getValueFromListOfMap(gmMap,"location_id",null,"location_id").toString();
		getAccessToken();
		if(canCreateNOG){
			reporting_Id = getValueFromListOfMap(db("select TOP(1) user_id, location_id from [dbo].[user] where role_id ="+ 
					getValueFromListOfMap(roleList,"role_code","PH","role_id").toString()  + 
					"and is_deleted = 0","SELECT"),"user_id",null,"user_id").toString();
			reporting_Type = "PH";
			int nogId = getRandomId();
			callUserAPI(gmLoc,
					"NOG",
					getValueFromListOfMap(roleList,"role_code","NOG","role_id").toString(),
					nogId,
					0);
			reporting_Id = String.valueOf(nogId);
			reporting_Type = "NOG";
			callUserAPI(gmLoc,
					"SNOG",
					getValueFromListOfMap(roleList,"role_code","SNOG","role_id").toString(),
					getRandomId(),
					0);
			canCreateNOG = false;
		}
		reporting_Id = getValueFromListOfMap(gmMap,"user_id",null,"user_id").toString();
		LinkedHashMap temp = new LinkedHashMap();
		temp.put("password", "olam");
		temp.put("userId",reporting_Id );	
		temp.put("roleCode", "GM");
		temp.put("locationCode",gmLoc);
		regionCode = gmLoc;
		createdUserDetails.add(temp);
		if(plantation_Type_Id.equals(PALM)) {
			rmMap = db("select TOP(1) user_id, location_id from [dbo].[user] where user_id in (select reportee_user_id  from [dbo].[user_reporting_hierarchy] where usr_id = '"+reporting_Id+ "') and is_deleted = 0","SELECT");
			System.out.println(rmMap);
			reporting_Id = getValueFromListOfMap(rmMap,"user_id",null,"user_id").toString();
			regionCode = getValueFromListOfMap(rmMap,"location_id",null,"location_id").toString();
			temp = new LinkedHashMap();
			temp.put("password", "olam");
			temp.put("userId",reporting_Id);	
			temp.put("roleCode", "RM");
			temp.put("locationCode",regionCode);
			createdUserDetails.add(temp);
		}
	}

	public void getAccessToken() {

		Map<String, String> headerMapForAccessToken = new LinkedHashMap<>();
		JSONObject requestParamsForAccessToken = new JSONObject();

		headerMapForAccessToken.put("Content-Type", "application/json");
		requestParamsForAccessToken = new JSONObject();
		requestParamsForAccessToken.put("password", "olam");
		if(plantationType.equals(RUBBER)) {

			System.out.println("select user_id from [dbo].[user] where role_id in(select role_id from [dbo].[role] where role_code='GM' and plantation_type_id=2) and plantation_type_id=2 and is_deleted=0;");

			requestParamsForAccessToken.put("username", getValueFromListOfMap(db("select TOP (1) user_id from [dbo].[user] where role_id in(select role_id from [dbo].[role] where role_code='GM' and plantation_type_id="+plantationType+")\r\n" + 
					" and plantation_type_id="+plantationType+" and is_deleted=0;", "SELECT"), null, null, "user_id"));
		}else {
			requestParamsForAccessToken.put("username", getValueFromListOfMap(db("select TOP (1) user_id from [dbo].[user] where role_id in(select role_id from [dbo].[role] where role_code='GM' and plantation_type_id="+plantationType+")\r\n" + 
					" and plantation_type_id="+plantationType+" and is_deleted=0;", "SELECT"), null, null, "user_id"));
			System.out.println("select TOP (1) user_id from [dbo].[user] where role_id in(select role_id from [dbo].[role] where role_code='GM' and plantation_type_id="+plantationType+")\r\n" + 
					" and plantation_type_id="+plantationType+" and is_deleted=0;");
		}
		Response response = postWithHeaderAndJsonBody(headerMapForAccessToken, requestParamsForAccessToken.toJSONString(),"/login/retrieveToken?plantationTypeId="+plantationType);
		accessToken = getAccessToken(response, "data[0].accessToken");
		System.out.println("accessToken-----" + accessToken);
		getAccessTokenTime = System.currentTimeMillis();

	}

	/*
	 * Do not modify this method unless needed
	 */

	@Test(dataProvider="createData",enabled=true)
	public void createUsers(String roleCode,String locCode, int count, String four) {
		int userId = 0;
		int roleType = reportingMap.get(roleCode);
		if(reportingIds.get(roleType-1) != null) {
			reportingCount = reportingIds.get(roleType-1).size();
		}
		int totCount = count*estateCount;
		int mid = totCount/reportingCount;
		int remaining = totCount % reportingCount;
		int tempMid = 0;
		estateCodes = getListFromListOfMap(locationhier,"location_id",regionCode,"sub_location_id");
		System.out.println(estateCodes);
		for(int i = 1; i <= reportingCount ; i++) {
			if(remaining > 0) {
				tempMid = mid+1;
			}else {
				tempMid = mid;
			}
			if((plantationType.equals(RUBBER) && roleType == 2)) {
				reporting_Type = "GM";
			}else if(plantationType.equals(PALM) && roleType == 3){
				reporting_Type = "RM";
			}else {
				reporting_Id = reportingIds.get(reportingMap.get(roleCode)-1).get(i-1).getUserId();
				reporting_Type = reportingIds.get(reportingMap.get(roleCode)-1).get(i-1).getUserCode();
				locCode = reportingIds.get(reportingMap.get(roleCode)-1).get(i-1).getLocationCode();
			}
			while(tempMid != 0) {
				userId = getRandomId();
				if(!"WOR".equals(roleCode)) {
					locCode = estateCodes.get(estate).toString();
				}
				if(estate != estateCount-1) {
					estate ++;
				}else {
					estate = 0;
				}
				System.out.println("CurrentID:   "+userId+" "+roleCode);
				System.out.println("ReportingID:  "+ reporting_Id);
				System.out.println("LocationId:   "+ locCode);
				Object roleId = getValueFromListOfMap(roleList, "role_code",roleCode,"role_id");
				callUserAPI(locCode,roleCode,roleId,userId,roleType);
				tempMid --;
			}
			remaining --;
		}
		estate = 0;

	}

	public void callUserAPI(String locCode, String roleCode,Object roleId,int userId,int roleType){

		/*			
		access token expiry validation
		if(validateAccessTokenTime() >= 1) {
			System.out.println("Access token time has elapsed, Regenerating....");
			getAccessToken();
		}*/

		LinkedHashMap<String, String> temp;
		headerMap.put("Content-Type", "application/json");
		headerMap.put("Authorization","Bearer "+accessToken);
		requestParams = new JSONObject();
		requestParams.put("createdOn", System.currentTimeMillis());
		requestParams.put("dob", get18YearsBackDate());
		requestParams.put("email", "createdByAutomation@olamnet.com");
		requestParams.put("firstName", String.valueOf(userId));
		requestParams.put("geoLoc", locCode);
		requestParams.put("lastName", roleCode);
		requestParams.put("mobNum", "0987654321");
		requestParams.put("password", "olam");
		requestParams.put("plantationTypeId", plantationType);
		requestParams.put("reportingManagerId", String.valueOf(reporting_Id));
		requestParams.put("roleId", roleId);
		requestParams.put("securityQuestionEditFlag", "false");
		requestParams.put("userId", String.valueOf(userId));
		String retMessage = SUCCESS_MSG ;
		try {

			Response response = postWithHeaderAndJsonBody(headerMap, requestParams.toJSONString(), "/user/saveUser");
			retMessage = getJsonInfoWithKeystring(response, "message");
			

			if(retMessage.equals("Token Expire")) {

				System.out.println("Regenerating New Access Token.....");
				getAccessToken();

				response = postWithHeaderAndJsonBody(headerMap, requestParams.toJSONString(), "/user/saveUser");

			}

		}catch(Exception e) {
			retMessage = e.getMessage();
		}
		if(SUCCESS_MSG.equals(retMessage)) {
			//System.out.println("Success---------"+retMessage);
			temp = new LinkedHashMap();
			temp.put("password", String.valueOf(requestParams.get("password")));
			temp.put("userId", String.valueOf(userId));
			temp.put("roleCode", roleCode);
			temp.put("locationCode",locCode);
			createdUserDetails.add(temp);
			successIds.add(String.valueOf(userId));
			LinkedList<UserModel> list;
			UserModel reporting = new UserModel(String.valueOf(userId), roleCode, reporting_Id, roleType,locCode);
			if(reportingIds.get(roleType) == null) {
				list = new LinkedList<>();
			}else {
				list = reportingIds.get(roleType);
			}
			if ("WOR".equals(roleCode)) {
				String key = reporting_Type+reporting_Id + "*" + 99 + "#" + locCode;
				if (workerReporting.get(key) == null) {
					workerReporting.put(key, String.valueOf(userId));
				}else {
					workerReporting.put(key, workerReporting.get(key).toString()+"#"+String.valueOf(userId));
				}
				if (workerReporting.get(reporting_Type + "*" + locCode) == null) {
					workerReporting.put(reporting_Type + "*" + locCode, String.valueOf(userId));
				}
				if (workerReporting.get(reporting_Type + "*" + estate) == null) {
					workerReporting.put(reporting_Type + "*" + estate, String.valueOf(userId));
				}
			}
			list.add(reporting);
			reportingIds.put(roleType,list);
		}else {
			System.out.println("Error---------"+retMessage);
		}
	}

	@DataProvider(name = "createData")
	public Object[][] createData1() {
		if(plantationType.equals(RUBBER)) {
			return new Object[][] {
				{"EM","GA12-04-01",1,"" },
				{"AM","GA12-04-01",2,"" },
				{"TAP","GA12-04-01",2,"" },
				{"FER","GA12-04-01",2,"" },
				{"WOR","GA12-04-01",4,"" },
			};
		}else {
			return new Object[][] {
				//{"RM","",1,"" },
				{"EM","",Integer.valueOf(prop.getProperty("EstateManager")),"" },
				{"AM","",Integer.valueOf(prop.getProperty("AssistantManager")),"" },
				{"HAR","",Integer.valueOf(prop.getProperty("CDQH")),"" },
				{"FER","",Integer.valueOf(prop.getProperty("CDQF")),"" },
				{"WOR","",Integer.valueOf(prop.getProperty("Worker")),"" },
			};
		}

	}

	//@Test(dataProvider="excelData",enabled=true)
	public void createUsersFromExcel(String user_id,String firstName, String lastName, String managerId,
			String roleCode,String locCode, String dob, String mobileNum,
			String email,String password, String securityq1, String q1Ans,
			String securityq2,String q2Ans) {
		if(!isFailed) {

			if(!userValidationInAD(user_id)) {
				LinkedHashMap<String, String> temp;
				headerMap.put("Content-Type", "application/json");
				headerMap.put("Authorization","Bearer "+accessToken); 

				Object roleId = getValueFromListOfMap(roleList, "role_code",roleCode,"role_id");

				Object loc = getValueFromListOfMap(locationList, "location_code",locCode,"location_id");
				if(loc == null) {
					loc = "4027";
				}

				requestParams = new JSONObject();
				requestParams.put("userId", user_id);
				requestParams.put("firstName", user_id+"_"+firstName);  
				requestParams.put("lastName", lastName);
				requestParams.put("reportingManagerId", managerId);
				requestParams.put("roleId", roleId);
				requestParams.put("dob", dob);
				requestParams.put("mobNum", mobileNum);
				requestParams.put("email", email);
				requestParams.put("password", password);
				requestParams.put("geoLoc", loc);
				requestParams.put("plantationTypeId", plantationType);
				requestParams.put("securityQuestionEditFlag", "false");
				requestParams.put("createdOn", System.currentTimeMillis());

				String retMessage;
				try {
					Response response = postWithHeaderAndJsonBody(headerMap, requestParams.toJSONString(), "/user/saveUser");
					retMessage = getJsonInfoWithKeystring(response, "message");

					if(retMessage.equals("Token Expire")) {
						getAccessToken();
						response = postWithHeaderAndJsonBody(headerMap, requestParams.toJSONString(), "/user/saveUser");
					}

				}catch(Exception e) {
					retMessage = e.getMessage();
				}
				System.out.println("Error Message ---"+retMessage);
				if(SUCCESS_MSG.equals(retMessage)) {
					temp = new LinkedHashMap<>();
					temp.put("userId", user_id);
					temp.put("password", "olam");
					temp.put("roleCode", roleCode);
					if("WOR".equals(roleCode)) {
						if(workerReporting.get(reporting_Id) != null) {
							workerReporting.put(reporting_Id, String.valueOf(user_id));
						}
					}
					createdUserDetails.add(temp);
					successIds.add(user_id);
				}else {
					System.out.println("FAILED---------------"+retMessage);
					isFailed = true;
					revertChanges(successIds);
					assertEquals(true, false,retMessage);
				}
			}else {
				isFailed = true;
				revertChanges(successIds);
				assertEquals(true, false,"User already available  : Deleted all Created Users");
			}
		}else {
			assertEquals(true, false,"Cannot Create User !!! Previous User Creation Failed");
		}
	}

	@DataProvider(name = "excelData")
	public static Object[][] createDataFromExcel() {
		return getExcelUsers("C:\\Users\\sgnanasekar4048\\Desktop\\UserData.xlsx",0,14);
	}



	public boolean userValidationInAD(String userId) {
		boolean bReturn = false;
		headerMap.put("Content-Type", "application/json");
		headerMap.put("Authorization","Bearer "+adminToken); 
		System.out.println("AD lookup for :"+userId);
		Response response = getWithHeader(headerMap, "https://graph.windows.net/olamtest.onmicrosoft.com//users?api-version=1.6"
				+ "&$filter=(userPrincipalName eq '"+userId+"@olamtest.onmicrosoft.com')");
		if(response.jsonPath().get("value.userType").toString().contains("Member")) {
			bReturn = true;
		}
		return bReturn;

	}


	public int getRandomId() {
		Random random = new Random();
		int n = random.nextInt(87456) + 385497;
		while(userValidationInAD(String.valueOf(n))) {
			n = random.nextInt(87456) + 385497;
		}
		return n;
	}

	@AfterClass
	public void printCreatedData() {
		//System.out.println(reportingIds);
		if(createdUserDetails.size() > 0) {
			System.out.println("Created User details::::  "+createdUserDetails);
			System.out.println("Worker Reporting Map :::::::"+workerReporting);
			writeToExcel(createdUserDetails,workerReporting,reportingMap,estateCount,plantationType,estateCodes);
		}else {
			System.out.println("No User Created to Write on Excel");
		}
	}
}





