package tests.api;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import lib.api.RESTAssuredBase;

public class QuickNoteCapture  extends RESTAssuredBase  {


	public static final String PALM = "1";

	String plantationType ="";
	String accessToken;
	Map<String, String> headerMap = new LinkedHashMap<>();
	JSONObject requestParams = new JSONObject();
	JSONObject activityParams = new JSONObject();
	String deviceID = "REST-"+getRandomString(7);
	String fingerPrintData = "AutoFP"+getRandomString(30);

	@Parameters({"plantation_Type_Id"})
	@BeforeTest
	public void setValues(String plantation_Type_Id) {

		this.plantationType=plantation_Type_Id;
		testCaseName = "Create Quick Note";
		testDescription = "Creating Quick Note data for all test users";
		nodes = "Quick Note";
		authors = "Saravanan";
		category = "Regression";
		dataFileName = "data";
		dataFileType = "JSON";

		getAccessToken();

	}


	public void getAccessToken() {

		Map<String, String> headerMapForAccessToken = new LinkedHashMap<>();
		JSONObject requestParamsForAccessToken = new JSONObject();

		headerMapForAccessToken.put("Content-Type", "application/json");

		requestParamsForAccessToken = new JSONObject();
		requestParamsForAccessToken.put("password", "olam");
		requestParamsForAccessToken.put("username", getValueFromListOfMap(db(
				"select TOP (1) user_id from [dbo].[user] where role_id in(select role_id from [dbo].[role] where role_code='PR' and plantation_type_id="
						+ plantationType + ")\r\n" + " and plantation_type_id=" + plantationType + " and is_deleted=0;",
				"SELECT"), null, null, "user_id"));

		Response response = postWithHeaderAndJsonBody(headerMapForAccessToken, requestParamsForAccessToken.toJSONString(),
				"/login/retrieveToken?plantationTypeId=" + plantationType);

		accessToken = getAccessToken(response, "data[0].accessToken");
		System.out.println("accessToken-----" + accessToken);
		getAccessTokenTime = System.currentTimeMillis();

	}


	@DataProvider(name="palmUserGang")
	public static Object[][] palmUserSet(){
		return getPalmUsersHarvest("User Details",true);
	}

	@Test(dataProvider="palmUserGang")
	public void createQuickNoteForAllUsers(String username,String userRole,String workerId, String location) {


		/*access token expiry validation
		if(validateAccessTokenTime() >= 55) {
			System.out.println("Access token time has elapsed, Regenerating....");
			getAccessToken();
		}*/

		if(username != null && userRole != null && workerId != null && !"EM".equals(userRole) && !"WOR".equals(userRole) ) {

			headerMap.put("Content-Type", "application/json");
			headerMap.put("Authorization","Bearer "+accessToken);
			
			reportRequest("Access token generation successful and passed on to create Quick Note data", "PASS");
			
			int currentBlockID,latitude,longitude;
			String cordinates;
			String[] parts;


			requestParams = new JSONObject();

			requestParams.put("accuracy", 22.945999145507812);

			String estateloc = loc.get(workerId).toString();
			Object divisionLoc = getValueFromListOfMap(
					db("select TOP (1) sub_location_id from [dbo].[geo_location_hierarchy] "
							+ " where location_id=" + estateloc + ";", "SELECT"),
					null, null, "sub_location_id");
			requestParams.put("blockId", Integer.valueOf(
					getValueFromListOfMap(db("select TOP(1) sub_location_id from [dbo].[geo_location_hierarchy]"
							+ " where location_id = "+divisionLoc+";", "SELECT"), null, null, "sub_location_id")
					.toString()));
			currentBlockID = Integer.valueOf(
					getValueFromListOfMap(db("select TOP(1) sub_location_id from [dbo].[geo_location_hierarchy]"
							+ " where location_id = "+divisionLoc+";", "SELECT"), null, null, "sub_location_id")
					.toString());
			
			cordinates = getValueFromListOfMap(db("select geolocation_json from [dbo].[geo_location_xref] where location_id='"+currentBlockID+"';", "SELECT"), null, null, "geolocation_json").toString();
			parts = cordinates.split(",");
			reportRequest("Block ID retrieval success, Location co-ordinates are processing...", "PASS");
			
			requestParams.put("deviceId", deviceID);
			requestParams.put("insertTimestamp", System.currentTimeMillis());
			requestParams.put("latitude", parts[3].replace("]", "").trim());
			requestParams.put("longitude",parts[2].replace("[", "").trim());
			
			reportRequest("Latitute, Longitude data processed successfully", "PASS");
			
			requestParams.put("noteId", getRandomId());
			requestParams.put("plantationTypeId", plantationType);
			requestParams.put("recordId", getRandomId());
			requestParams.put("status", "Submitted");
			requestParams.put("timeOfCapture", System.currentTimeMillis());
			requestParams.put("userId", username);

			ArrayList<JSONObject> objList = new ArrayList<>();
			activityParams.put("fileCaption", "MyNote_"+username+"_"+getRandomString(20));
			activityParams.put("fileId", getRandomId());
			activityParams.put("fileName", getRandomString(10)+".txt");
			activityParams.put("fileType", "text");
			//activityParams.put("fileUrl","");
			objList.add(activityParams);
			requestParams.put("quickNoteFiles", objList);

			System.out.println("["+requestParams.toJSONString()+"]");

			Response response = postWithHeaderAndJsonBody(headerMap, "["+requestParams.toJSONString()+"]", "/quicknote/saveQuickNoteData");
			
			reportRequest("POST request successful with generated payload", "PASS");
			String retMessage = verifyContentsWithKeystring(response, "message", "Quick Note data recorded successfully");
			
			
			if(retMessage.equals("Token Expire")) {
				
				reportRequest("Token Expired! -Sit back and  relax, I will be generating new one for you ", "PASS");
				System.out.println("Regenerating New Access Token.....");
				getAccessToken();
				reportRequest("New Access token generation successful", "PASS");

				response = postWithHeaderAndJsonBody(headerMap, "["+requestParams.toJSONString()+"]", "/quicknote/saveQuickNoteData");
				
				reportRequest("Data saved with new access token generated", "PASS");

			}

			deviceID = "REST-"+getRandomString(7);



		}
	}
}
