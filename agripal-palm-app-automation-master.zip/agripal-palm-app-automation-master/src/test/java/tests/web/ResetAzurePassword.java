package tests.web;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.BrowserType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ResetAzurePassword {

	protected static ThreadLocal<RemoteWebDriver> driver;
	Actions action;
	WebDriverWait wait;




	@Test(enabled=false)
	public void test2() throws Exception {



		DesiredCapabilities dc = new DesiredCapabilities();
		dc.setBrowserName(BrowserType.CHROME);

		//WebDriver driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), dc);

		System.setProperty("webdriver.chrome.driver", "./chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.get("https://www.olamgroup.com/");

		String windowHandle = driver.getWindowHandle();

		Thread.sleep(10000);

		//driver.switchTo().newWindow(WindowType.TAB);

		driver.get("https://www.google.com");

		System.out.println(driver.getTitle());
		Thread.sleep(10000);


		driver.switchTo().window(windowHandle);

		System.out.println("Iam back to: "+driver.getTitle());
		driver.quit();


	}


	public static String[][] getUsersFromExcel(String sheetName){
		String[][] ret = null;
		try{

			String userId=null,name=null,rolePwd=null;
			File file = new File("./data/Password_Reset/UserListForPassword_Reset.xlsx");
			FileInputStream fis = new FileInputStream(file);

			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName);

			int row = sheet.getLastRowNum();
			ret = new String[row+1][3];
			for (int i = 0; i <= row; i++) {
				userId = sheet.getRow(i).getCell(0).getStringCellValue().trim();
				name = sheet.getRow(i).getCell(2).getStringCellValue().trim();
				rolePwd = sheet.getRow(i).getCell(3).getStringCellValue().trim();
				ret[i][0] = name;
				ret[i][1] = userId;
				ret[i][2] = rolePwd;
			}


			System.out.println(Arrays.deepToString(ret));

		}catch(Exception e){
			e.printStackTrace();
		}

		return ret;
	}

	@DataProvider(name = "resetUsers")
	public static Object[][] palmUserSet() {
		return getUsersFromExcel("Users");
	}


	@BeforeClass
	public void preTest() throws Exception {



		/*System.setProperty("webdriver.chrome.driver", "./chromedriver.exe");

		driver = new ChromeDriver(); 
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);*/

		driver = new ThreadLocal<>();

		/*DesiredCapabilities dc = new DesiredCapabilities();
		dc.setBrowserName(BrowserType.CHROME);
		driver = new ThreadLocal<RemoteWebDriver>();
		driver.set(new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), dc));*/
		driver.get().get("https://portal.azure.com/#blade/Microsoft_AAD_IAM/UsersManagementMenuBlade/AllUsers");
		driver.get().manage().window().maximize();

		//driver.findElement(By.xpath("//div[@data-bind='text: otherTileText']"));
		driver.get().findElement(By.name("loginfmt")).sendKeys("agripaladmin@oab2cuat2001.onmicrosoft.com");
		driver.get().findElement(By.id("idSIButton9")).click();
		Thread.sleep(3000);
		driver.get().findElement(By.name("passwd")).sendKeys("Ol@m.12345##");
		//driver.get().findElement(By.id("idSIButton9")).click();

		action = new Actions(driver.get());
		action.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(3000);
		action.sendKeys(Keys.ENTER).build().perform();
		action.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(5000);


	}

	@Test (dataProvider="resetUsers")
	public void updatePassword(String name,String userId, String roleBasedPassword) throws Exception, AWTException {

		/*System.setProperty("webdriver.chrome.driver", "./chromedriver.exe");

		driver = new ChromeDriver(); 
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		 */
		System.out.println("IAM IN:::::::"+driver);
		System.out.println("-----"+userId);

		String windowHandle = driver.get().getWindowHandle();

		wait = new  WebDriverWait(driver.get(), 30);
		wait.until(ExpectedConditions.presenceOfElementLocated
				(By.xpath("(//input[contains(@class,'azc-input')])[2]")));

		driver.get().findElement(By.xpath("(//input[contains(@class,'azc-input')])[2]")).clear();
		driver.get().findElement(By.xpath("(//input[contains(@class,'azc-input')])[2]")).sendKeys(name);

		Thread.sleep(3000);

		if(driver.get().findElement(By.xpath("//span[text()='Load more']")).isDisplayed()) {
			driver.get().findElement(By.xpath("//span[text()='Load more']")).click();
		}


		driver.get().findElement(By.xpath
				("//div[contains(text(),'"+userId+"@')]/ancestor::td/preceding-sibling::td/following::td/div/div/div/img/following::a")).click();
		Thread.sleep(5000);
		driver.get().findElement(By.xpath("(//div[text()='Reset password'])[2]")).click();
		System.out.println("2");
		Thread.sleep(5000);
		driver.get().findElement(By.xpath("//span[text()='Reset password']")).click();
		Thread.sleep(5000);
		System.out.println("3");


		String tempPwd = driver.get().findElement(By.xpath("//span[text()='Temporary password']/following::input")).getAttribute("title");
		System.out.println(tempPwd);

		Thread.sleep(5000);

		//	driver.switchTo().newWindow(WindowType.TAB);
		((JavascriptExecutor) driver.get()).executeScript("window.open('about:blank','_blank');");
		ArrayList<String> tabs = new ArrayList<String>(driver.get().getWindowHandles());
		driver.get().switchTo().window(tabs.get(1));

		/*Robot r = new Robot();                          
		r.keyPress(KeyEvent.VK_CONTROL); 
		r.keyPress(KeyEvent.VK_T); 
		r.keyRelease(KeyEvent.VK_CONTROL); 
		r.keyRelease(KeyEvent.VK_T);    
		//To switch to the new tab
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));*/
		//To navigate to new link/URL in 2nd new tab

		driver.get().get("https://portal.azure.com/");
		Thread.sleep(5000);

		driver.get().get("https://portal.azure.com/SignOut");

		Thread.sleep(5000);
		driver.get().get("https://portal.azure.com");

		Thread.sleep(5000);
		driver.get().findElement(By.xpath("(//div[contains(text(),'onmicrosoft.com')]/following::img)[1]")).click();
		driver.get().findElement(By.id("forgetLink")).click();


		driver.get().findElement(By.id("otherTileText")).click();

		System.out.println("newONE:::::::::"+""+userId+"@oab2cuat2001.onmicrosoft.com");
		Thread.sleep(3000);
		driver.get().findElement(By.name("loginfmt")).sendKeys(""+userId+"@oab2cuat2001.onmicrosoft.com");
		driver.get().findElement(By.id("idSIButton9")).click();
		driver.get().findElement(By.name("passwd")).sendKeys(tempPwd.trim());

		action.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(5000);
		action.sendKeys(Keys.ENTER).build().perform();

		driver.get().findElement(By.id("currentPassword")).sendKeys(tempPwd);

		System.out.println("Keying in::::"+roleBasedPassword);
		driver.get().findElement(By.id("newPassword")).sendKeys("Olam@123"+roleBasedPassword);
		driver.get().findElement(By.id("confirmNewPassword")).sendKeys("Olam@123"+roleBasedPassword);

		action.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(15000);

		//((JavascriptExecutor) driver).executeScript("window.close()");



		//String text = driver.findElement(By.xpath("//h1[text()='Welcome to Microsoft Azure']")).getText();

		/*r.keyPress(KeyEvent.VK_CONTROL); 
		r.keyPress(KeyEvent.VK_W); 
		r.keyRelease(KeyEvent.VK_CONTROL); 
		r.keyRelease(KeyEvent.VK_W);   */

		driver.get().switchTo().window(windowHandle);
		System.out.println("back to parent");

		Thread.sleep(5000);
		driver.get().get("https://portal.azure.com/#blade/Microsoft_AAD_IAM/UsersManagementMenuBlade/AllUsers");

		System.out.println("changed url...");
		Thread.sleep(5000);

	}

}
