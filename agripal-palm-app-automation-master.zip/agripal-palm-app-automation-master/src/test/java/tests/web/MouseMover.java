package tests.web;

import java.awt.AWTException;
import java.awt.Robot;
import java.util.Random;

public class MouseMover {
	
	public static void main(String[] args) {

		final int FIVE_SECONDS = 5000;
		final int MAX_Y = 400;
		final int MAX_X = 400;

		Robot robot = null;
		try {
			robot = new Robot();
		} catch (AWTException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Random random = new Random();
		while (true) {
			robot.mouseMove(random.nextInt(MAX_X), random.nextInt(MAX_Y));
			try {
				Thread.sleep(FIVE_SECONDS);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}



	}

}
