package tests.mobile;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import lib.mobile.General;
import pages.mobile.palm.GridPage;
import pages.mobile.palm.HarvestingDataPage_BunchQuality;
import pages.mobile.palm.HarvestingDataPage_CropRecovery;
import pages.mobile.palm.LoginPage;

public class CreateHarvestingData extends General {

	GridPage grid = new GridPage();
	LoginPage login = new LoginPage();  
	HarvestingDataPage_CropRecovery harvestCR = new HarvestingDataPage_CropRecovery();
	HarvestingDataPage_BunchQuality harvestBQ = new HarvestingDataPage_BunchQuality();
	int randomNum = (int)(Math.random() * 120 + 1);


	@BeforeTest
	public void setValues() {

		testCaseName = "Create new users";
		testDescription = "Creating harvesting data by all type of users";
		nodes = "Create Harvesting Data";
		authors = "Saravanan";
		category = "Regression";
	}

	@DataProvider(name="palmUserGang")
	public static Object[][] palmUserSet(){
		return getPalmUsers("User Details");
	}

	@BeforeMethod(alwaysRun = true)
	public void beforeMethod() {
		//for reports		
		System.out.println("Iam calling 2nd");
		svcTest = startTestModule(nodes);
		svcTest.assignAuthor(authors);
		svcTest.assignCategory(category);
	}

	@Test(dataProvider="palmUserGang")
	public void createHarvestingData(String password, String username,String getUserRole,String workerHAR, String workerIdFER){
		if(password != null && username != null && getUserRole != null && workerHAR != null && !"FER".equals(getUserRole)) {

			clearAppData();
			grid = login.loginAgripalUserSet(password, username, getUserRole) 
					.clickHarvestingData() 
					.selectHarvestor(workerHAR) 
					/*.enterRipe("1") 
					.enterOverRipe("1")
					.enterUnderRipe("1")
					.enterSickBunches("2")
					.enterEmptyBunches("2")
					.enterUnripeBunches("3")
					.enterLongStalk("4")
					.total()*/
					.selectCropRecovery()
					.uncollectedBunches(String.valueOf(this.randomNum))
					.unHarvestedBunches("1")
					//.totalCR()
					//			.looseFruitsOnPath("2").looseFruitsOnCircle("2")
					//		.looseFruitsOnPlatform("2").looseFruitsOnFrondExile("2")
					.clickSubmitButton() 
					.clickConfirmButton() 
					.clickBackAndGotoGridPage()
					.waitForTwoMins()
					.clickMoreOptions()
					.performManualSync()
					.verifyDB("select * from [dbo].[harvesting] where user_id='"+username+"' and harvester_user_id='"+workerHAR+"'"
							+ " and uncollected_bunches='"+randomNum+"';",
							"SELECT", "uncollected_bunches",String.valueOf(randomNum), "uncollected_bunches");

			

			//logPassed(username + " can create Harvesting data and saved in DB", false);
		}
	}
}
