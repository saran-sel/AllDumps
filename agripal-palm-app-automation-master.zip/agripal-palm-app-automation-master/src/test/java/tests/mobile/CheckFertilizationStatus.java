package tests.mobile;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import lib.mobile.General;
import pages.mobile.palm.GridPage;
import pages.mobile.palm.LoginPage;
import pages.mobile.palm.StatusPage;

public class CheckFertilizationStatus extends General {
	
	GridPage grid = new GridPage();
	LoginPage login = new LoginPage();
	StatusPage status = new StatusPage();

	@BeforeTest
	public void setValues() {

		testCaseName = "Create new users";
		testDescription = "Creating harvesting data by all type of users";
		nodes = "Create Harvesting Data";
		authors = "Saravanan";
		category = "Regression";
	}

	@DataProvider(name="palmUserGang")
	public static Object[][] palmUserSet(){
		return getPalmUsers("User Details");
	}

	@BeforeMethod(alwaysRun = true)
	public void beforeMethod() {
		//for reports		
		svcTest = startTestModule(nodes);
		svcTest.assignAuthor(authors);
		svcTest.assignCategory(category);
	}

	@Test(dataProvider="palmUserGang", description="Region view")
	public void checkHarvestingDataRegion(String password, String username,String getUserRole,String workerHAR, String workerIdFER) {

		if(password != null && username != null && getUserRole != null && workerHAR != null && !"FER".equals(getUserRole)) {

			//clearAppData();
			status = login.loginAgripalUserSet(password, username, getUserRole)
					.clickStatusTile()
					.getRipeValue()
					.getOverRipeValue()
					.getUnderRipeValue()
					.getSickBunchesValue()
					.getEmptyBunchesValue()
					.getUnripeBunchesValue()
					.getLongStalkValue();

		}

	}


	@Test(dataProvider="palmUserGang", description="Role view")
	public void checkHarvestingDataRole(String password, String username,String getUserRole,String workerHAR, String workerIdFER) {

		if(password != null && username != null && getUserRole != null && workerHAR != null && !"FER".equals(getUserRole)) {

			//clearAppData();
			status = login.loginAgripalUserSet(password, username, getUserRole)
					.clickStatusTile()
					.gotoRoleView()
					.getRipeValue()
					.getOverRipeValue()
					.getUnderRipeValue()
					.getSickBunchesValue()
					.getEmptyBunchesValue()
					.getUnripeBunchesValue()
					.getLongStalkValue();

		}

	}

}
