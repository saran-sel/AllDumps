package tests.mobile;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import lib.mobile.General;
import pages.mobile.palm.FertilizationDataPage;
import pages.mobile.palm.GridPage;
import pages.mobile.palm.LoginPage;

public class CreateFertilizationData extends General {

	GridPage grid = new GridPage();
	LoginPage login = new LoginPage();
	FertilizationDataPage fertilizer = new FertilizationDataPage();
	int randomNum = (int) (Math.random() * 120 + 1);

	@BeforeTest
	public void setValues() {

		testCaseName = "Create new users";
		testDescription = "Creating harvesting data by all type of users";
		nodes = "Create Harvesting Data";
		authors = "Saravanan";
		category = "Regression";
	}
	@BeforeMethod(alwaysRun = true)
	public void beforeMethod() {
		// for reports
		System.out.println("Iam calling 2nd");
		svcTest = startTestModule(nodes);
		svcTest.assignAuthor(authors);
		svcTest.assignCategory(category);
	}

	@DataProvider(name = "palmUserGang")
	public static Object[][] palmUserSet() {
		return getPalmUsers("User Details");
	}

	@Test(dataProvider = "palmUserGang",enabled=true)
	public void createFertilizationData(String password, String username, String getUserRole, String workerHAR,
			String workerIdFER) {
		if (password != null && username != null && getUserRole != null && workerHAR != null
				&& !"HAR".equals(getUserRole)) {

			clearAppData();
			grid = login.loginAgripalUserSet(password, username, getUserRole).clickFertilizationData()
					.selectFertilizer(workerIdFER).clickWrongType().clickWrongDosage().clickWrongPlacement()
					.clickWrongTiming().clickMissedOutPalm().clickMissedOutPalm().clickWrongTiming()
					.clickWrongPlacement().clickWrongDosage().clickWrongType().enterTotal("10").clickValidateButton()
					.enterBalance(String.valueOf(randomNum)).enterEmpty("3").clickSubmitButton().clickConfirmButton()
					.clickBackAndGotoGridPage().waitForTwoMins().clickMoreOptions().performManualSync()
					.verifyDB("select * from [dbo].[palm_fertilizer] where record_id in"
							+ " (select record_id from [dbo].[fertilizer] " + "where user_id='" + username
							+ "' and harvester_user_id='" + workerIdFER + "')" + " and balanced_fertilizer='"
							+ randomNum + ".00';",
							"SELECT", "balanced_fertilizer", String.valueOf(randomNum)+".00", "balanced_fertilizer");

			// System.out.println("select * from [dbo].[palm_fertilizer] where record_id in
			// (select record_id from [dbo].[fertilizer] where user_id='"+username+"' and
			// harvester_user_id='"+workerIdFER+"') and
			// balanced_fertilizer='"+randomNum+".00';");
			this.randomNum = (int) (Math.random() * 120 + 1);

		}

	}

}
