package tests.mobile;

import static org.testng.Assert.assertEquals;
import org.testng.annotations.Test;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import org.json.simple.JSONObject;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.asserts.SoftAssert;

import io.restassured.RestAssured;
import lib.mobile.General;
import lib.mobile.MobileWrappers;
import pages.mobile.palm.GridPage;
import pages.mobile.palm.LoginPage;
import pages.mobile.palm.QuickNotePage;
import pages.mobile.palm.StatusPage;

public class QuickNoteTest extends General{
	
	GridPage grid = new GridPage();
	LoginPage login = new LoginPage();  
	SoftAssert softAssert = new SoftAssert();
	MobileWrappers wrappers = new MobileWrappers();
	QuickNotePage qnPage = new QuickNotePage();

	//@DataProvider(name="palmUserGang")
	public static Object[][] palmUserSet(){
		return getPalmUsers("User Details");
	}


	@BeforeMethod(alwaysRun = true)
	public void beforeMethod(Method method) {
		// for reports
		nodes = method.getName();
		svcTest = startTestModule(nodes);
		svcTest.assignAuthor(authors);
		svcTest.assignCategory(category);
		RestAssured.baseURI = "https://zuul-sit-agripal.olamdigital.com";
	}

	@BeforeTest
	public void setValues() {

		testCaseName = "Quick Note Functionality";
		testDescription = "Quick Note Functionality";
		nodes = "EMPTY";
		authors = "Gayathri Gnanaraj";
		category = "Regression";
	}



	/* Validates all QN features when logged in as CDQ
	 * 
	 * 
	 */
	@Test
	public void validateQuickNoteForCQDLogin() {
		clearAppData();
		List cdqUserIdList = getUserIdForRole("HAR", "6", 1, getPalmUsers("User Details"));
		login
			.loginAgripalUserSet("olam", cdqUserIdList.get(0).toString(), "")
				.clickStatusTile()
				.clickQuickNoteTab()
				.validateQuickNoteCreatedByUser(cdqUserIdList.get(0).toString(), "HAR", getPalmUsers("User Details"));
				
	}
	
	/* Validates all QN features when logged in as AM
	 * 
	 * 
	 */
	@Test
	public void validateQuickNoteForAMLogin() {
		clearAppData();
		List amUserIdList = getUserIdForRole("AM", "6", 1, getPalmUsers("User Details"));
		login
			.loginAgripalUserSet("olam", amUserIdList.get(0).toString(), "")
				.clickStatusTile()
				.clickQuickNoteTab()
				.validateQuickNoteCreatedByUser(amUserIdList.get(0).toString(), "AM", getPalmUsers("User Details"));
				
	}
	
	/* Validates all QN features when logged in as EM
	 * 
	 * 
	 */
	@Test
	public void validateQuickNoteForEMLogin() {
		clearAppData();
		List emUserIdList = getUserIdForRole("EM", "6", 1, getPalmUsers("User Details"));
		login
			.loginAgripalUserSet("olam", emUserIdList.get(0).toString(), "")
				.clickStatusTile()
				.clickQuickNoteTab()
				.validateQuickNoteCreatedByUserForEM(emUserIdList.get(0).toString(), "EM", getPalmUsers("User Details"))
				.clickBackToGridPageFromQNPage()
				.clickMoreOptions()
				.performManualSync();
				 qnPage.verifyDB();
	}
	
	/* Validates all QN features when logged in as RM
	 * 
	 * 
	 */
	@Test
	public void validateQuickNoteForRMLogin() {
		clearAppData();
		List rmUserIdList = getUserIdForRole("RM", "2", 1, getPalmUsers("User Details"));
		login
			.loginAgripalUserSet("olam", rmUserIdList.get(0).toString(), "")
			.clickStatusTile()
			.clickQuickNoteTab()
			.validateQuickNoteCreatedByUser(rmUserIdList.get(0).toString(), "RM", getPalmUsers("User Details"));
	}
	
	/* Validates all QN features when logged in as GM
	 * 
	 * 
	 */
	@Test
	public void validateQuickNoteForGMLogin() {
		clearAppData();
		List gmUserIdList = getUserIdForRole("GM", "1", 1, getPalmUsers("User Details"));
		login
			.loginAgripalUserSet("olam", gmUserIdList.get(0).toString(), "")
			.clickStatusTile()
			.clickQuickNoteTab()
			.validateQuickNoteCreatedByUser(gmUserIdList.get(0).toString(), "GM", getPalmUsers("User Details"));
	}
	
	/* Validates all QN features when logged in as GM when QN has Unattended notifications
	 * 
	 * 
	 */
	@Test
	public void validateQuickNoteForGMLoginWithUnattendedStatus() {
		List gmUserIdList = getUserIdForRole("GM", "1", 1, getPalmUsers("User Details"));
		List<String> recordIds = null;
		recordIds = qnPage.getQNRecordIds(gmUserIdList.get(0).toString(), "GM", getPalmUsers("User Details"));
		
		wrappers.db(wrappers.queryBuilder("Update [dbo].[quick_note] set Status = 'Unattended' where record_id in (", recordIds), "UPDATE");
		sleep(20000);
		login
			.loginAgripalUserSet("olam", gmUserIdList.get(0).toString(), "")
			.clickStatusTile()
			.clickQuickNoteTab()
			.validateQuickNoteWithUnattendedStatus(gmUserIdList.get(0).toString(), "GM", getPalmUsers("User Details"), recordIds)
			.clickBackToGridPageFromQNPage()
			.clickNotificationBellIcon()
			.validateQNPageIsOpened();
	}
}



