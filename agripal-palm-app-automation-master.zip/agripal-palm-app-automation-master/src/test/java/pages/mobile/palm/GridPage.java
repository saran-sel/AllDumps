package pages.mobile.palm;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import lib.mobile.General;


public class GridPage extends General{

	Properties prop;

	public GridPage() {
		prop = loadObjectRepository();

	}

	public HarvestingDataPage_BunchQuality clickHarvestingData(){

		try{
			sleep(3000);
			m_clickElement("xpath", prop.getProperty("GridScreen.HarvestingData.Xpath"));
			sleep(3000);
			//logPassed("Harvesting data clicked", true);
			reportRequest("Harvesting tile clicked on GridPage", "PASS");
		}catch(Exception e){
			e.printStackTrace();
			//logFailed("Unable to click Harvesting data");
			reportRequest("Unable to click Harvesting tile on grid screen", "FAIL");
		}
		return new HarvestingDataPage_BunchQuality();
	}


	public FertilizationDataPage clickFertilizationData(){

		try{
			sleep(3000);
			m_clickElement("xpath", prop.getProperty("GridScreen.FertilizationData.Xpath"));
			sleep(3000);
			//logPassed("Harvesting data clicked", true);
			reportRequest("Fertilization tile clicked on GridPage", "PASS");
		}catch(Exception e){
			e.printStackTrace();
			//logFailed("Unable to click Harvesting data");
			reportRequest("Unable to click Fertilization tile on grid screen", "FAIL");
		}
		return new FertilizationDataPage();
	}




	public GridPage checkGreetingMessage(){

		try{

			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH");  
			LocalDateTime now = LocalDateTime.now();  

			int i = Integer.parseInt(dtf.format(now));

			if(i < 12){
				System.out.println("Good Morning");

			}else if((i >= 12)&&(i < 16)){
				System.out.println("Good Afternoon");
			}else if((i >= 16)&&(i < 21)){
				System.out.println("Good Evening");
			}else if((i >= 21)&&(i < 24)){
				System.out.println("Good Night");
			}

			m_getTextDisplayed("id", prop.getProperty("GridScreen.CheckGreetingMessage.Id"), "Good Morning");
			logPassed("Greeting Message displayed as per expected value", true);
		}catch(Exception e){
			logFailed("Greeting Message mismatched");
		}
		return this;
	}

	public GridPage clickMoreOptions(){

		try{

			sleep(3000);
			m_clickElement("xpath", prop.getProperty("GridScreen.MoreOptionsThreeDot.Xpath"));
			sleep(3000);
			//logPassed("More Options clicked in Grid Page", false);
			reportRequest("More options button clicked", "PASS");
		}catch(Exception e){
			//logFailed("Unable to click More Options in GridPage");
			reportRequest("Unable to click more options", "FAIL");
		}
		return this;
	}

	public LoginPage clickLogout(){

		try{

			m_clickElement("xpath", prop.getProperty("GridScreen.LogOut.Xpath"));
			//logPassed("Logout link clicked", false);
		}catch(Exception e){
			//logFailed("Unable to click LogOut button");
		}
		return new LoginPage();
	}

	public GridPage performManualSync(){

		try{

			m_clickElement("xpath", prop.getProperty("GridScreen.SyncAllData.Xpath"));
			sleep(15000);

			//logPassed("Manual Sync Performed", true);
			reportRequest("Manual Sync button clicked", "PASS");
		}catch(Exception e){
			//logFailed("Unable to perform Manual Sync");
			reportRequest("Unable to click manual sync ", "FAIL");
		}
		return this;

	}

	public GridPage verifyHarvestDataCreationInDB(String type, String queryFromPropFile, String userId){

		try{
			/*
			 * Manager Login
			 */

			if(type.equalsIgnoreCase("managerLogin")){

				System.out.println(prop.getProperty(queryFromPropFile) + userId+ "' and is_audit=1");
				executeQueryAndSaveDataInCSV(prop.getProperty(queryFromPropFile) + userId+ "' and is_audit=1");

				if(valOutPutDataFromCSV("is_audit","1")){
					logPassed(userId+" data saved in DB and Audit column updated as 1", false);
				}else{
					logFailed("KO");
				}

				/*
				 * CDQ Login
				 */

			}else if(type.equalsIgnoreCase("CDQLogin")){

				System.out.println(prop.getProperty(queryFromPropFile) + userId+ "' and is_audit=0");

				executeQueryAndSaveDataInCSV(prop.getProperty(queryFromPropFile) + userId+ "' and is_audit=0");
				if(valOutPutDataFromCSV("is_audit","0")){
					logPassed(userId+" data saved in DB and Audit column updated as 0", false);
				}else{
					logFailed("KO");
				}
			}


		}catch(Exception e){
			logFailed("DB Verification Failed");
		}
		return this;

	}


	public GridPage checkYieldRecordButton(){

		try{
			m_getTextDisplayed("id", prop.getProperty("GridScreen.YieldRecord.Id"), "Yield Record");

			logPassed("Yield Record Displayed text displayed", false);
		}catch(Exception e){
			logFailed("Unable to verify Yield Record");
		}
		return this;
	}


	public StatusPage clickStatusTile(){

		try{
			sleep(5000);
			m_clickElement("xpath", prop.getProperty("GridScreen.Status.Xpath"));
			reportRequest("Able to click Status tile", "PASS");
		}catch(Exception e){
			reportRequest("Unable to click Status tile", "WARNING");
		}
		return new StatusPage();
	}

	public GridPage waitForTwoMins() {

		try {
			//sleep(120000);

			int timet= 2 * 60;
			long delay = timet * 1000;
			do
			{
				int minutes = timet / 60;
				int seconds = timet % 60;
				System.out.println(minutes +" minute(s), " + seconds + " second(s)");
				sleep(1000);
				timet = timet - 1;
				delay = delay - 1000;
			}
			while (delay != 0);
			System.out.println("Time's Up!, Its time to Sync");

			sleep(2000);
			reportRequest("Waited for 2 mins ", "PASS");
		} catch (Exception e) {
			reportRequest("Unable to wait for 2 mins", "FAIL");
			e.printStackTrace();
		}

		return this;
	}

	public GridPage verifyDB(String query,String action,String columnName,String valueToBeCheck,String target_column) {
		Object obj = getValueFromListOfMap(db(query, action), columnName, valueToBeCheck, target_column);
		if(obj == null) {
			//reportRequest(columnName + "has value as null doesn't match with your expectedvalue : "+valueToBeCheck, "FAIL");
			System.out.println(columnName.toUpperCase() + " column value doesn't match with your expectedvalue : "+valueToBeCheck);
		 try
	        { 
	            throw new NullPointerException(columnName.toUpperCase() + " column value doesn't match with your expectedvalue : "+valueToBeCheck); 
	        } 
	        catch(NullPointerException e) 
	        { 
	            throw e; // rethrowing the exception 
	        } 
		}else {
			//reportRequest("passsssss", "PASS");
			System.out.println(columnName.toUpperCase() + " column value matches with your expectedvalue : "+valueToBeCheck);
			return this;
		}
	}
	
	public QuickNotePage clickNotificationBellIcon(){
		try{
			sleep(3000);
			m_clickElement("xpath", prop.getProperty("GridScreen.NotificationBell.Xpath"));
			sleep(3000);
			reportRequest("Notification Bell Icon is clicked - PASSED", "PASS");
		}catch(Exception e){
			reportRequest("Unable to click Notification Bell Icon - FAILED", "FAIL");
		}
		return new QuickNotePage();
	}

	/*public YieldRecordPage clickYieldrecord(){

		try{

			m_clickElement("id", prop.getProperty("GridScreen.YieldRecord.Id"));

			logPassed("Yield Record Clicked", false);
		}catch(Exception e){
			logFailed("Unable to click Yield record");
		}
		return new YieldRecordPage();
	}*/

	/*	public StatusRegionPage clickStatusButton(){


		try{

			System.out.println(prop.getProperty("GridScreen.Status.Xpath"));
			m_clickElement("xpath", prop.getProperty("GridScreen.Status.Xpath"));

			logPassed("Status link Clicked", false);
		}catch(Exception e){
			logFailed("Unable to click Status link");
		}
		return new StatusRegionPage();

	}*/












}
