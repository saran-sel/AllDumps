package pages.mobile.palm;

import java.util.Properties;

import lib.mobile.General;

public class StatusPage extends General {

	Properties prop;

	public StatusPage() {
		prop = loadObjectRepository();
	}
	
	public StatusPage gotoRoleView() {
		
		try {
			m_clearElement("id", prop.getProperty("StatusPage.Role.Id"));
			reportRequest("Switched to Role view", "PASS");
		}catch(Exception e) {
			reportRequest("Unable to switch role view", "WARNING");
		}
		return this;
	}


	public StatusPage getRipeValue(){

		try{

			m_getTextDisplayed("xpath", prop.getProperty("StatusPage.RipeValue.Xpath"));
			sleep(1000);
			reportRequest("Ripe Value verified", "PASS");
		}catch(Exception e){
			reportRequest("Unable to verify ripe value", "WARNING");
		}
		return this;
	}

	public StatusPage getOverRipeValue(){

		try{

			m_getTextDisplayed("xpath", prop.getProperty("StatusPage.OverRipe.Xpath"));
			sleep(1000);
			reportRequest("OverRipe Value fetched", "PASS");
		}catch(Exception e){
			reportRequest("Unable to fetch Ripe value", "WARNING");
		}
		return this;
	}

	public StatusPage getUnderRipeValue(){

		try{

			m_getTextDisplayed("xpath", prop.getProperty("StatusPage.UnderRipe.Xpath"));
			sleep(1000);
			reportRequest("UnderRipe Value fetched", "PASS");
		}catch(Exception e){
			reportRequest("Unable to fetch Ripe value", "WARNING");
		}
		return this;
	}

	public StatusPage getSickBunchesValue(){

		try{

			m_getTextDisplayed("xpath", prop.getProperty("StatusPage.SickBunches.Xpath"));
			sleep(1000);
			reportRequest("Sick Bunches Value fetched", "PASS");
		}catch(Exception e){
			reportRequest("Unable to fetch Ripe value", "WARNING");
		}
		return this;
	}

	public StatusPage getEmptyBunchesValue(){

		try{

			m_getTextDisplayed("xpath", prop.getProperty("StatusPage.EmptyBunch.Xpath"));

			sleep(1000);
			reportRequest("Empty Bunches Value fetched", "PASS");
		}catch(Exception e){
			reportRequest("Unable to fetch Ripe value", "WARNING");
		}
		return this;
	}

	public StatusPage getUnripeBunchesValue(){

		try{

			m_getTextDisplayed("xpath", prop.getProperty("StatusPage.UnripeBunches.Xpath"));
			sleep(1000);
			reportRequest("Unripe Bunches Value fetched", "PASS");
		}catch(Exception e){
			reportRequest("Unable to fetch Ripe value", "WARNING");
		}
		return this;
	}

	public StatusPage getLongStalkValue(){

		try{

			m_getTextDisplayed("id", prop.getProperty("StatusPage.LongStalk.Id"));
			reportRequest("Long Stalk value fetched", "PASS");



		}catch(Exception e){
			reportRequest("Long Stalk value not fetched", "WARNING");
		}
		return this;
	}

	public QuickNotePage clickQuickNoteTab(){

		try{
			sleep(5000);
			m_clickElement("xpath", prop.getProperty("QNPage.QNTab.Xpath"));
			reportRequest("Clicked QuickNote Tab - PASSED", "PASS");
		}catch(Exception e){
			reportRequest("Unable to clicked QuickNote Tab - FAILED", "FAIL");
		}
		return new QuickNotePage();
	}






}
