package pages.mobile.palm;

import java.util.Properties;

import lib.mobile.General;

public class QuickNoteTicketPage extends General {
	Properties prop;
	String recordId;

	public String getRecordId() {
		return recordId;
	}

	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}

	public QuickNoteTicketPage() {
		prop = loadObjectRepository();

	}

	public QuickNoteTicketPage validateQNStatusInQNStatusPage(String status) {
		try {
				String recordIdXpath = "//android.widget.TextView[@resource-id='com.olam.gabon.mvpaks:id/text_quick_note_refId'][@text='"+getRecordId()+"']";
				System.out.println("recordIdXpath:"+recordIdXpath);
				String qnStatusXpath = recordIdXpath+"/../../android.widget.RelativeLayout[@resource-id='com.olam.gabon.mvpaks:id/rel_quick_note_status']/android.widget.TextView[@resource-id='com.olam.gabon.mvpaks:id/text_quick_note_status']";
				System.out.println("qnStatusXpath:"+qnStatusXpath);
				m_checkElementAttributeValue("xpath", qnStatusXpath, "text", status);
				System.out.println("qnStatusXpath: "+qnStatusXpath);
				reportRequest("Checking QN Status is '"+status+"' Status - PASSED", "PASS");
		} catch (Exception e) {
			reportRequest("Unable to check QN Status is '"+status+"' Status - FAILED", "FAIL");
		}
		
		return this;
	}
	
	public QuickNoteTicketPage validateQNStatusInQNTicketPage(String status) {
		try {
				String qnStatusInTicketPageId = "com.olam.gabon.mvpaks:id/textViewQNDetailsStatus";
				m_checkElementAttributeValue("id", qnStatusInTicketPageId, "text", status);
				reportRequest("Checking QN Status is '"+status+"' Status - PASSED", "PASS");
		} catch (Exception e) {
			reportRequest("Unable to check QN Status is '"+status+"' Status - FAILED", "FAIL");
		}
		
		return this;
	}
	
	public QuickNoteTicketPage validateQuickNoteData(String role) {
		String query = "select file_caption from [dbo].[quick_note_files] where record_id = '"+getRecordId()+"';";
		System.out.println("Query: "+query);
		String fileCaption = getDBRecord(db(query, "SELECT"), "file_caption").get(0);
		try {
				System.out.println("QN REcord id xpath: "+prop.getProperty("QNPage.QNTicket.Xpath")+"[@text='"+recordId+"']");
				m_getTextDisplayed("id", prop.getProperty("QNTicketPage.QNText.Id"), fileCaption);
				reportRequest("Checking if Quick Note Text '"+fileCaption+"' is displayed - PASSED", "PASS");
		} catch (Exception e) {
			reportRequest("Unable to check Quick Note Text '"+fileCaption+"' is displayed - FAILED", "FAIL");
		}
		return this;
	}
	
	public QuickNoteTicketPage clickStartButton() {
		try {
			m_clickElement("xpath", prop.getProperty("QNTicketPage.StartButton.Xpath"));
			reportRequest("Checking if Start button is clicked - PASSED", "PASS");
		} catch (Exception e) {
			reportRequest("Unable to check if Start Button is clicked - FAILED", "FAIL");
		}
		return this;
	}
	
	public QuickNoteTicketPage clickCompleteButton() {
		try {
			m_clickElement("xpath", prop.getProperty("QNTicketPage.CompleteButton.Xpath"));
			reportRequest("Checking if Start button is clicked - PASSED", "PASS");
		} catch (Exception e) {
			reportRequest("Unable to check if Start Button is clicked - FAILED", "FAIL");
		}
		return this;
	}

	public QuickNoteTicketPage clickConfirm() {
		
		try {
			m_clickElement("id", prop.getProperty("QNTicketPage.ConfirmButton.Id"));
			reportRequest("Checking if Confirm button is clicked - PASSED", "PASS");
		} catch (Exception e) {
			reportRequest("Unable to check if Confirm Button is clicked - FAILED", "FAIL");
		}
		return this;
	}

	public GridPage clickBackToGridPageFromQNPage() {
		try {
			m_clickElement("xpath", prop.getProperty("QNPage.ClickBackButton.Xpath"));
			reportRequest("Clicking Back Button from Quick Note page - PASSED", "PASS");
		} catch (Exception e) {
			reportRequest("Unable to click Back Button from Quick Note page - FAILED", "FAIL");
		}
		return new GridPage();
		
	}
}
