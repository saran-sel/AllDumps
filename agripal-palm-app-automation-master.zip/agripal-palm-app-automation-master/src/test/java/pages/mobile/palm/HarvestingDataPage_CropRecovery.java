package pages.mobile.palm;

import java.util.ArrayList;
import java.util.Properties;

import lib.mobile.General;

public class HarvestingDataPage_CropRecovery extends General {

	Properties prop;
	ArrayList<Integer> metricsCR = new ArrayList<>();

	public HarvestingDataPage_CropRecovery() {
		prop = loadObjectRepository();
	}

	public HarvestingDataPage_CropRecovery uncollectedBunches(String uncollectedBunches){

		try{

			m_enterText("id", prop.getProperty("HarvestPage.UncollectedBunches.Id"), uncollectedBunches);
			/*metricsCR.add(Integer.parseInt(m_getTextDisplayed("id",  prop.getProperty("HarvestPage.UncollectedBunches.Id"))));*/
			hideKeyboard();
			sleep(2000);
			//logPassed("Uncollected Bunches Value Entered", false);
			reportRequest("Uncollected Bunches Value Entered", "PASS");

		}catch(Exception e){
			//logFailed("Unable to enter Uncollected Bunches ");
			reportRequest("Unable to enter Uncollected Bunches ", "FAIL");
		}
		return this;
	}

	public HarvestingDataPage_CropRecovery unHarvestedBunches(String unHarvestedBunches){

		try{

			m_enterText("id", prop.getProperty("HarvestPage.UnHarvestedBunches.Id"), unHarvestedBunches);
			/*metricsCR.add(Integer.parseInt(m_getTextDisplayed("id",  prop.getProperty("HarvestPage.UnHarvestedBunches.Id"))));*/
			hideKeyboard();
			sleep(2000);
			//logPassed("Unharvested Bunches Value Entered", false);
			reportRequest("Unharvested Bunches Value Entered", "PASS");

		}catch(Exception e){
		//	logFailed("Unable to enter Unharvested Bunches ");
			reportRequest("Unable to enter Unharvested Bunches ", "FAIL");
		}
		return this;
	}


	public HarvestingDataPage_CropRecovery totalCR(){

		try{

			int n = metricsCR.stream().mapToInt(Integer::intValue).sum();
			m_getTextDisplayed("id", prop.getProperty("HarvestPage.TotalCR.Id"),Integer.toString(n));

			sleep(2000);
			//logPassed("Total value verified", true);
			reportRequest("Total value verified", "PASS");
		}catch(Exception e){
			reportRequest("Total value not verified", "FAIL");
		}
		return this;
	}

	public HarvestingDataPage_CropRecovery looseFruitsOnPath(String path){

		try{

			m_enterText("id", prop.getProperty("HarvestPage.Path.Id"), path);
			sleep(2000);

			//logPassed("Path Value entered", false);
			reportRequest("Path Value entered", "PASS");
		}catch(Exception e){
			//logFailed("Unable to enter Path value");
			reportRequest("Unable to enter Path value", "FAIL");
		}
		return this;
	}

	public HarvestingDataPage_CropRecovery looseFruitsOnCircle(String circle){

		try{

			m_enterText("id", prop.getProperty("HarvestPage.Circle.Id"), circle);

			sleep(2000);
			//logPassed("Circle Value entered", false);
			reportRequest("Circle Value entered", "PASS");
		}catch(Exception e){
			//logFailed("Unable to enter Circle value");
			reportRequest("Unable to enter Circle value", "FAIL");
		}
		return this;
	}

	public HarvestingDataPage_CropRecovery looseFruitsOnPlatform(String platform){

		try{

			m_enterText("id", prop.getProperty("HarvestPage.Platform.Id"), platform);

			sleep(2000);
		//	logPassed("Platform Value entered", false);
			reportRequest("Platform Value entered", "PASS");
		}catch(Exception e){
			//logFailed("Unable to enter platform value");
			reportRequest("Unable to enter platform value", "FAIL");
		}
		return this;
	}

	public HarvestingDataPage_CropRecovery looseFruitsOnFrondExile(String frondExile){

		try{

			m_enterText("id", prop.getProperty("HarvestPage.FrondExile.Id"), frondExile);
			hideKeyboard();

			sleep(2000);
			//logPassed("FrondExile Value entered", false);
			reportRequest("FrondExile Value entered", "PASS");
		}catch(Exception e){
			//logFailed("Unable to enter FrondExile value");
			reportRequest("Unable to enter FrondExile value", "FAIL");
		}
		return this;
	}

	public HarvestingData_ConfirmationPage clickSubmitButton(){

		try{

			m_clickElement("id", prop.getProperty("HarvestPage.SubmitButton.Id"));

			//logPassed("Submit Button Clicked", true);
			reportRequest("Submit Button Clicked", "PASS");
		}catch(Exception e){
			//logFailed("Unable to click Submit Button");
			reportRequest("Unable to click Submit Button", "FAIL");
		}
		return new HarvestingData_ConfirmationPage();
	}

	public GridPage clickBackAndGotoGridPage(){

		try{

			m_clickElement("xpath", prop.getProperty("HarvestPage.ClickBackButton.Xpath"));
			//	logPassed("Back Button Clicked", false);
			reportRequest("Back button clicked to perform manual Sync", "PASS");

		}catch(Exception e){
			//logFailed("Unable to click Back Button");
			reportRequest("Unable to click device back button", "FAIL");

		}
		return new GridPage();
	}

	




}
