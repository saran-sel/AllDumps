package pages.mobile.palm;

import java.util.Properties;

import lib.mobile.General;

public class HarvestingData_ConfirmationPage extends General{

	Properties prop;
	HarvestingDataPage_BunchQuality harvestBunch = new HarvestingDataPage_BunchQuality();

	
	public HarvestingData_ConfirmationPage() {
		
		prop = loadObjectRepository();
	}
	
	
	public HarvestingData_ConfirmationPage verifyConfirmationForBQ(){

		try{
			
			System.out.println(harvestBunch.ripe);
			m_getTextDisplayed("id", prop.getProperty("HarvestPage.ConfirmPage.RipeValue.Id"),harvestBunch.ripe);
			logPassed("ripe value verified", true);
		}catch(Exception e){
			logFailed("Unable to enter ripe value");
		}
		return this;
	}
	
	public HarvestingDataPage_CropRecovery clickConfirmButton(){
		
		try{
			
			m_clickElement("id", prop.getProperty("HarvestPage.ConfirmPage.Confirm.Id"));
			sleep(3000);
			//logPassed("Confirmation button clicked", false);
			reportRequest("Confirm button clicked", "PASS");

		}catch(Exception e){
			reportRequest("Unable to click confirm button", "FAIL");

		}
		return new HarvestingDataPage_CropRecovery();
	}
	
	
}
