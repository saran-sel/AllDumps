package pages.mobile.palm;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import lib.mobile.General;
import lib.mobile.MobileWrappers;

public class QuickNotePage extends General {
	Properties prop;
	QuickNoteTicketPage qnTicketPage = new QuickNoteTicketPage();
	MobileWrappers wrapper = new MobileWrappers();
	
	List<String> recordIdList;

	public List<String> getRecordIdList() {
		return recordIdList;
	}

	public void setRecordIdList(List<String> recordIdList) {
		this.recordIdList = recordIdList;
	}

	public QuickNotePage() {
		prop = loadObjectRepository();

	}

	public QuickNotePage verifyAttendanceListPageIsDisplayed() {
		try {
			m_checkElementAttributeValue("id", prop.getProperty("AttendanceListPage.AttendListHeader.Id"), "text", "Attendance List");
			reportRequest("Checking if Attendance List Page is opened upon clicking Attendance List Button - PASSED", "PASS");
		} catch (Exception e) {
			reportRequest("Unable to check Attendance List Page is opened upon clicking Attendance List Button - FAILED", "FAIL");
		}
		return this;
	}
	
	public QuickNoteTicketPage validateQuickNoteCreatedByUser(String userId, String role, Object[][] userDetail) {
		/*String userHierarchyQuery = "Select * from [dbo].[user_reporting_hierarchy] where usr_id = '"+userId+"'";
		List<String> reportees = getDBRecord(db(userHierarchyQuery, "SELECT"), "usr_id", "reportee_user_id");*/
		List<String> recordIds = null;
		recordIds = getQNRecordIds(userId, role, userDetail);
		try {
			for (String recordId : recordIds) {
				System.out.println("QN REcord id xpath: "+prop.getProperty("QNPage.QNTicket.Xpath")+"[@text='"+recordId+"']");
				m_clickElement("xpath", prop.getProperty("QNPage.QNTicket.Xpath")+"[@text='"+recordId+"']");
				reportRequest("Checking if Quick Note Created By User "+userId+" is opened - PASSED", "PASS");
				qnTicketPage.setRecordId(recordId);
				qnTicketPage.validateQuickNoteData(role);
				clickBackFromQNTicketPage();
				
			}
		} catch (Exception e) {
			reportRequest("Unable to check if Quick Note Created By User "+userId+" is opened - FAILED", "FAIL");
		}
		return qnTicketPage;
	}
	
	public QuickNoteTicketPage validateQuickNoteCreatedByUserForEM(String userId, String role, Object[][] userDetail) {
		List<String> recordIds = null;
		recordIds = getQNRecordIds(userId, role, userDetail);
		setRecordIdList(recordIds);
		try {
			for (String recordId : recordIds) {
				qnTicketPage.setRecordId(recordId);
				qnTicketPage.validateQNStatusInQNStatusPage("Notified");
				openQNTicket(recordId);
				qnTicketPage.validateQNStatusInQNTicketPage("Acknowledged");
				qnTicketPage.clickStartButton();
				qnTicketPage.validateQNStatusInQNTicketPage("In Progress");
				qnTicketPage.clickCompleteButton();
				qnTicketPage.clickConfirm();
				openQNTicket(recordId);
				qnTicketPage.validateQNStatusInQNTicketPage("Completed");
				clickBackFromQNTicketPage();
			}
		} catch (Exception e) {
			reportRequest("Unable to check if Quick Note Created By User "+userId+" is opened - FAILED", "FAIL");
		}
		return qnTicketPage;
	}
	
	private void openQNTicket(String recordId) {
		try {
			System.out.println("QN REcord id xpath: "+prop.getProperty("QNPage.QNTicket.Xpath")+"[@text='"+recordId+"']");
			m_clickElement("xpath", prop.getProperty("QNPage.QNTicket.Xpath")+"[@text='"+recordId+"']");
			reportRequest("Checking if Quick Note is opened - PASSED", "PASS");	
		}
		catch (Exception e) {
			reportRequest("Unable to check if Quick Note is opened - FAILED", "FAIL");
		}
	}

	public QuickNoteTicketPage clickBackFromQNTicketPage() {
		try {
			m_clickElement("xpath", prop.getProperty("QNTicketPage.ClickBackButton.Xpath"));
			reportRequest("Checking if Back button can be clicked from Quick Note page - PASSED", "PASS");
		} catch (Exception e) {
			reportRequest("Unable to check if Back button can be clicked from Quick Note page - FAILED", "FAIL");
		}
		return qnTicketPage;
	}
	
	public List<String> getQNRecordIds(String userId, String role, Object[][] userDetail) {

		String queryBuilder = "select record_id from [dbo].[quick_note] where user_id in (";
		List<String> reportees = new ArrayList<String>();
		if ("HAR".equalsIgnoreCase(role)) {
			reportees.add(userId);
		}
		else if ("AM".equalsIgnoreCase(role)) {
			reportees.add(userId);
			reportees.addAll(getUserIdForRole("HAR", "6", 1, userDetail));
			reportees.addAll(getUserIdForRole("FER", "6", 1, userDetail));
		}
		else if ("EM".equalsIgnoreCase(role)) {
			reportees.add(userId);
			reportees.addAll(getUserIdForRole("EM", "6", 1, userDetail));
			reportees.addAll(getUserIdForRole("AM", "6", 1, userDetail));
			reportees.addAll(getUserIdForRole("HAR", "6", 1, userDetail));
			reportees.addAll(getUserIdForRole("FER", "6", 1, userDetail));
		}
		else if ("RM".equalsIgnoreCase(role)) {
			reportees.add(userId);
			reportees.addAll(getUserIdForRole("EM", "6", 1, userDetail));
			reportees.addAll(getUserIdForRole("AM", "6", 1, userDetail));
			reportees.addAll(getUserIdForRole("HAR", "6", 1, userDetail));
			reportees.addAll(getUserIdForRole("FER", "6", 1, userDetail));
		}
		else if ("GM".equalsIgnoreCase(role)) {
			//reportees.add(userId);
			reportees.addAll(getUserIdForRole("AM", "6", 1, userDetail));
			reportees.addAll(getUserIdForRole("HAR", "6", 1, userDetail));
			reportees.addAll(getUserIdForRole("FER", "6", 1, userDetail));
		}
		
		System.out.println("User and his Reportees list: "+reportees);
		reportRequest("User and his Reportees: "+reportees, "PASS");
		/*for (int i = 0; i < reportees.size(); i++) {
			if (reportees.size() == 1) {
				queryBuilder = queryBuilder + "'"+reportees.get(i)+"'";
				break;
			}
			if (i == 0) 
				queryBuilder = queryBuilder + "'"+reportees.get(i) +"',";
			
			else if (i == reportees.size()-1) 
				queryBuilder = queryBuilder + "'"+reportees.get(i) +"'";
			
			else 
				queryBuilder = queryBuilder + "'"+reportees.get(i) +"',";
		}
		queryBuilder = queryBuilder +");";
		System.out.println("Query: "+queryBuilder);*/
		
		queryBuilder = wrapper.queryBuilder(queryBuilder, reportees);
		reportRequest("Querying user's QN record ids: "+queryBuilder, "PASS");
		List<String> recordIds;
		recordIds = getDBRecord(db(queryBuilder, "SELECT"), "record_id");
		return recordIds;
	}
	
	

	public void verifyDB() {
		String query = "select * from [dbo].[quick_note] where record_id in (";
		query = wrapper.queryBuilder(query, getRecordIdList());
		try {
			validateDBResult(wrapper.db(query, "SELECT"), "status" , "Completed", false,
					"Validating if all Quick Note statuses are marked completed after Sync");
			reportRequest("Validating if all Quick Note statuses are marked completed after Sync -- Passed", "PASS");
		}
		catch(Exception e) {
			reportRequest("Unable to validating if all Quick Note statuses are marked completed after Sync", "FAIL");
			e.printStackTrace();
		}		
	}

	public QuickNoteTicketPage validateQuickNoteWithUnattendedStatus(String userId, String role, String[][] userDetail, List<String> recordIds) {
		setRecordIdList(recordIds);
		try {
			for (String recordId : recordIds) {
				qnTicketPage.setRecordId(recordId);
				qnTicketPage.validateQNStatusInQNStatusPage("Unattended");
				openQNTicket(recordId);
				qnTicketPage.validateQNStatusInQNTicketPage("Unattended");
				clickBackFromQNTicketPage();
			}
		} catch (Exception e) {
			reportRequest("Unable to check if Quick Note Created By User "+userId+" is opened - FAILED", "FAIL");
		}
		return qnTicketPage;		
	}

	public QuickNotePage validateQNPageIsOpened() {
		try {
			m_getTextDisplayed("id", prop.getProperty("QNPage.QNPageText.Id") , "GA 16");
			reportRequest("Checking if Quick Note page is opened - PASSED", "PASS");
		} catch (Exception e) {
			reportRequest("Unable to check if Quick Note page is opened - FAILED", "FAIL");
		}
		return this;
	}
}
