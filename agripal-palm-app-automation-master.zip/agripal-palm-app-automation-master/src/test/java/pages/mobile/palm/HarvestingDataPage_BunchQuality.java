package pages.mobile.palm;

import java.util.ArrayList;
import java.util.Properties;

import lib.mobile.General;

public class HarvestingDataPage_BunchQuality extends General{

	Properties prop;
	ArrayList<Integer> metrics = new ArrayList<Integer>();
	String ripe, overRipe, underRipe, emptyBunch, sickBunch, unRipeBunches, total, longStalk;

	public HarvestingDataPage_BunchQuality() {

		prop = loadObjectRepository();
	}


	public HarvestingDataPage_BunchQuality selectHarvestor(String harvestorID){

		try{

			m_clearElement("id" ,prop.getProperty("HarvestPage.HarvestorName.Id"));
			m_enterText("id", prop.getProperty("HarvestPage.HarvestorName.Id"), harvestorID);
			m_clickElement("xpath", prop.getProperty("HarvestPage.HarvestorNameList.Xpath"));

			hideKeyboard();

			//logPassed("Harvestor selected", false);
			reportRequest("Harvestor selected as "+harvestorID, "PASS");
		}catch(Exception e){
			//logFailed("Unable to select Harvestor");
			reportRequest("Unable to select harvestor ID", "FAIL");

		}
		return this;
	}

	public HarvestingDataPage_BunchQuality enterRipe(String ripeValue){

		try{

			m_enterText("id", prop.getProperty("HarvestPage.RipeValue.Id"), ripeValue);
			/*ripe = m_getTextDisplayed("id",  prop.getProperty("HarvestPage.RipeValue.Id"));
			metrics.add(Integer.parseInt(m_getTextDisplayed("id",  prop.getProperty("HarvestPage.RipeValue.Id"))));*/
			hideKeyboard();
			sleep(2000);
			//logPassed("Ripe Value Entered", false);
			reportRequest("Ripe value entered as: "+ripeValue, "PASS");
		}catch(Exception e){
			//logFailed("Unable to enter Ripe Value");
			reportRequest("Unable to enter Ripe Value","FAIL");
		}
		return this;
	}

	public HarvestingDataPage_BunchQuality enterOverRipe(String overRipeValue){

		try{

			m_enterText("id", prop.getProperty("HarvestPage.OverRipe.Id"), overRipeValue);
			/*overRipe = m_getTextDisplayed("id",  prop.getProperty("HarvestPage.OverRipe.Id"));
			metrics.add(Integer.parseInt(m_getTextDisplayed("id",  prop.getProperty("HarvestPage.OverRipe.Id"))));*/

			hideKeyboard();
			sleep(2000);
		//	logPassed("Over Ripe Value Entered", false);
			reportRequest("Over ripe value entered as: "+overRipeValue, "PASS");
		}catch(Exception e){
			logFailed("Unable to enter Over Ripe Value");
			reportRequest("Unable to enter Over Ripe Value","FAIL");
		}
		return this;
	}

	public HarvestingDataPage_BunchQuality enterUnderRipe(String underRipeValue){

		try{

			m_enterText("id", prop.getProperty("HarvestPage.UnderRipe.Id"), underRipeValue);
			/*underRipe = m_getTextDisplayed("id",  prop.getProperty("HarvestPage.UnderRipe.Id"));
			metrics.add(Integer.parseInt(m_getTextDisplayed("id",  prop.getProperty("HarvestPage.UnderRipe.Id"))));*/

			hideKeyboard();
			sleep(3000);
			//logPassed("Under Ripe Value Entered", false);
			reportRequest("Underripe value entered", "PASS");
		}catch(Exception e){
			//logFailed("Unable to enter Under Ripe Value");
			reportRequest("Unable to enter underripe value", "FAIL");
		}
		return this;
	}

	public HarvestingDataPage_BunchQuality enterSickBunches(String sickBunches){

		try{

			m_enterText("id", prop.getProperty("HarvestPage.SickBunches.Id"), sickBunches);
			/*sickBunch = m_getTextDisplayed("id",  prop.getProperty("HarvestPage.SickBunches.Id"));
			metrics.add(Integer.parseInt(m_getTextDisplayed("id",  prop.getProperty("HarvestPage.SickBunches.Id"))));*/

			hideKeyboard();
			sleep(2000);
			//logPassed("Sick Bunches Value Entered", false);
			reportRequest("Sick Bunches Value Entered", "PASS");
		}catch(Exception e){
			//logFailed("Unable to enter Sick bunches Value");
			reportRequest("Unable to enter Sick bunches Value", "FAIL");
		}
		return this;
	}

	public HarvestingDataPage_BunchQuality enterEmptyBunches(String emptyBunches){

		try{

			m_enterText("id", prop.getProperty("HarvestPage.EmptyBunch.Id"), emptyBunches);
			/*emptyBunch = m_getTextDisplayed("id",  prop.getProperty("HarvestPage.EmptyBunch.Id"));
			metrics.add(Integer.parseInt(m_getTextDisplayed("id",  prop.getProperty("HarvestPage.EmptyBunch.Id"))));*/

			hideKeyboard();
			sleep(2000);
			//logPassed("EmptyBunch Value Entered", false);
			reportRequest("EmptyBunch Value Entered", "PASS");
		}catch(Exception e){
			//logFailed("Unable to enter EmptyBunch Value");
			reportRequest("Unable to enter EmptyBunch Value", "FAIL");
		}
		return this;
	}

	public HarvestingDataPage_BunchQuality enterUnripeBunches(String unripeBunches){

		try{

			m_enterText("id", prop.getProperty("HarvestPage.UnripeBunches.Id"), unripeBunches);
		/*	unRipeBunches = m_getTextDisplayed("id",  prop.getProperty("HarvestPage.UnripeBunches.Id"));
			metrics.add(Integer.parseInt(m_getTextDisplayed("id",  prop.getProperty("HarvestPage.UnripeBunches.Id"))));*/

			hideKeyboard();
			sleep(2000);
		//	logPassed("Unripe Bunches Value Entered", false);
			reportRequest("Unripe Bunches Value Entered", "PASS");
		}catch(Exception e){
			//logFailed("Unable to enter Unripe Bunches Value");
			reportRequest("Unable to enter Unripe Bunches Value", "FAIL");
		}
		return this;
	}

	public HarvestingDataPage_BunchQuality total(){

		try{

			int n = metrics.stream().mapToInt(Integer::intValue).sum();
			/*m_getTextDisplayed("id", prop.getProperty("HarvestPage.Total.Id"),Integer.toString(n));
			total = m_getTextDisplayed("id", prop.getProperty("HarvestPage.Total.Id"));*/
			sleep(2000);
			//logPassed("Total value verified", true);
			reportRequest("Total value verified", "PASS");
		}catch(Exception e){
			//logFailed("Unable to enter Total Value");
			reportRequest("Unable to enter Total Value", "FAIL");
		}
		return this;
	}

	public HarvestingDataPage_BunchQuality enterLongStalk(String longStalk){

		try{

			m_enterText("id", prop.getProperty("HarvestPage.LongStalk.Id"), longStalk);

			hideKeyboard();
			sleep(2000);
			//logPassed("LongStalk Value Entered", false);
			reportRequest("LongStalk Value Entered", "PASS");
		}catch(Exception e){
			//logFailed("Unable to enter LongStalk Value");
			reportRequest("Unable to enter LongStalk Value", "FAIL");
		}
		return this;
	}

	public HarvestingDataPage_CropRecovery selectCropRecovery(){

		try{

			m_clickElement("Id", prop.getProperty("HarvestPage.ClickRipeLabel.Id"));
			m_clickElement("xpath", prop.getProperty("HarvestPage.CropRecovery.Xpath"));
			
			sleep(2000);
			//logPassed("Crop Recovery selected", false);
			reportRequest("Crop Recovery selected", "PASS");
		}catch(Exception e){
			//logFailed("Unable to select Crop recovery");
			reportRequest("Unable to select Crop recovery", "FAIL");
		}
		return new HarvestingDataPage_CropRecovery();
	}

	public HarvestingData_ConfirmationPage clickSubmitButton(){

		try{

			m_clickElement("id", prop.getProperty("HarvestPage.SubmitButton.Id"));
			sleep(2000);
			//logPassed("Submit Button Clicked", false);
			reportRequest("Submit button clicked", "PASS");

		}catch(Exception e){
			reportRequest("Unable to click SUbmit button", "FAIL");

		}
		return new HarvestingData_ConfirmationPage();
	}

}
