package pages.mobile.palm;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import lib.mobile.General;

public class LoginPage extends General {

	Properties prop;
	GridPage grid = new GridPage();


	public LoginPage() {
		prop = loadObjectRepository();

	}

	public GridPage invokeAgriPal(){

		sleep(5000);
		System.out.println("test1");
		appLaunchSetup();
		return new GridPage();
	}


	public LoginPage enterUsername(String userName){

		m_enterText("xpath", prop.getProperty("LoginPage.UserID.Xpath"), userName);
		hideKeyboard();
		return this;
	}

	public LoginPage enterPassword(String password){

		m_enterText("id", prop.getProperty("LoginPage.Password.ID"), password);
		return this;
	}

	public GridPage clickLoginButton(){

		m_clickElement("id", prop.getProperty("LoginPage.LoginButton.ID"));
		return new GridPage();
	}

	public GridPage loginAgripalUserSet(String password, String username, String getUserRole){

		try{
			WebDriverWait wait = new WebDriverWait(driver, 120);

			turnOffImplicitWaits();
			if(driver.findElementsByXPath(prop.getProperty("GridScreen.Status.Xpath")).size() > 0){
				turnOnImplicitWaits();
				grid.clickMoreOptions().clickLogout();
			}
			turnOnImplicitWaits();
			m_enterText("id", prop.getProperty("LoginPage.Password.ID"), password);
			//m_enterText("id", prop.getProperty("LoginPage.UserID.Id"), username);
			hideKeyboard();
			sleep(2000);
			m_clickElement("id", prop.getProperty("LoginPage.LoginButton.ID"));


			wait.until(ExpectedConditions.presenceOfElementLocated
					(By.xpath(prop.getProperty("GridScreen.Status.Xpath"))));

			sleep(30000);
			reportRequest("Logged in as "+getUserRole+ " ("+username+") ", "PASS");

		}catch(Exception e){
			
			reportRequest("Unable to login as "+getUserRole+ " ("+username+") ", "WARNING");
		}
		return new GridPage();
	}





	public LoginPage checkTextOnAlertMessage(){

		clearAppData();

		/*m_clickElement("xpath", prop.getProperty("GridScreen.MoreOptionsThreeDot.Xpath"));
		m_clickElement("xpath", prop.getProperty("GridScreen.LogOut.Xpath"));*/

		m_getTextDisplayed("id", prop.getProperty("GrantPermission.Alert.Message"), "Allow AgriPal Rubber to take pictures and record video?");
		m_clickElement("id", prop.getProperty("GrantPermission.Alert.Allow"));

		m_getTextDisplayed("id", prop.getProperty("GrantPermission.Alert.Message"), "Allow AgriPal Rubber to access this device's location?");
		m_clickElement("id", prop.getProperty("GrantPermission.Alert.Allow"));

		m_getTextDisplayed("id", prop.getProperty("GrantPermission.Alert.Message"), "Allow AgriPal Rubber to access photos, media and files on your device?");
		m_clickElement("id", prop.getProperty("GrantPermission.Alert.Allow"));

		m_getTextDisplayed("id", prop.getProperty("GrantPermission.Alert.Message"), "Allow AgriPal Rubber to record audio?");
		m_clickElement("id", prop.getProperty("GrantPermission.Alert.Allow"));
		return this;
	}

	public LoginPage denySecurityAlerts(){

		try{

			clearAppData();

			m_clickElement("id", prop.getProperty("DenyPermission.Alert.Deny"));
			m_clickElement("id", prop.getProperty("DenyPermission.Alert.Deny"));
			m_clickElement("id", prop.getProperty("DenyPermission.Alert.Deny"));
			m_clickElement("id", prop.getProperty("DenyPermission.Alert.Deny"));

			logPassed("Security Alerts are Denied", false);
		}catch(Exception e){
			logFailed("Unable to click Deny option");
		}
		return this;

	}

	public LoginPage checkDefaultPlaceHolderValues(){

		try{

			m_getTextDisplayed("id", prop.getProperty("LoginPage.UserID.Id"));
			m_getTextDisplayed("id", prop.getProperty("LoginPage.Password.ID"));

			logPassed("Default Place holder Values Verified", true);
		}catch(Exception e){
			logFailed("Unable to verify default placeholder values in loginPage");
		}
		return this;
	}

	public LoginPage checkForgotPasswordLink(){

		try{

			m_checkElementPresentAndClickable("xpath",prop.getProperty("LoginPage.ForgotPassword.Xpath"));
			logPassed("ForgotPassword Link is displayed and Active", true);
		}catch(Exception e){
			logFailed("Forgot Password Link not displayed");
		}
		return this;
	}

	public GridPage checkGuestLoginLink(){

		try{
			sleep(5000);
			m_checkElementPresentAndClickable("id",prop.getProperty("LoginPage.GuestLogin.Id"));
			logPassed("GuestLogin Link is displayed and Active", true);
		}catch(Exception e){
			logFailed("GuestLogin Link not displayed");
		}
		return new GridPage();
	}






}
