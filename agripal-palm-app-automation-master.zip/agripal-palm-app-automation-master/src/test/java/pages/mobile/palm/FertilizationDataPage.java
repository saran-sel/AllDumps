package pages.mobile.palm;

import java.util.Properties;

import lib.mobile.General;

public class FertilizationDataPage extends General {

	Properties prop;

	public FertilizationDataPage() {
		prop = loadObjectRepository();
	}

	public FertilizationDataPage selectFertilizer(String fertilizerID) {

		try {

			m_clearElement("id", prop.getProperty("FertilizationPage.FertilizerName.Id"));
			m_enterText("id", prop.getProperty("FertilizationPage.FertilizerName.Id"), fertilizerID);
			m_clickElement("xpath", prop.getProperty("FertilizationPage.FertilizerNameList.Xpath"));

			hideKeyboard();

			reportRequest("Fertilizer selected as " + fertilizerID, "PASS");
		} catch (Exception e) {

			reportRequest("Unable to select Fertilizer ID", "FAIL");

		}
		return this;
	}

	public FertilizationDataPage clickWrongType() {

		try {

			m_clickElement("id", prop.getProperty("FertilizationPage.RightType.Id"));

			reportRequest("Right Type selected", "PASS");
		} catch (Exception e) {
			reportRequest("Right type not selected", "FAIL");
		}
		return this;
	}

	public FertilizationDataPage clickWrongDosage() {

		try {

			m_clickElement("id", prop.getProperty("FertilizationPage.RightDosage.Id"));

			reportRequest("Right dosage selected", "PASS");
		} catch (Exception e) {
			reportRequest("Right dosage not selected", "FAIL");
		}
		return this;
	}

	public FertilizationDataPage clickWrongPlacement() {

		try {

			m_clickElement("id", prop.getProperty("FertilizationPage.RightPlacement.Id"));

			reportRequest("Right Placement selected", "PASS");
		} catch (Exception e) {
			reportRequest("Right Placement not selected", "FAIL");
		}
		return this;
	}

	public FertilizationDataPage clickWrongTiming() {

		try {

			m_clickElement("id", prop.getProperty("FertilizationPage.RightTiming.Id"));

			reportRequest("Right Timing selected", "PASS");
		} catch (Exception e) {
			reportRequest("Right Timing not selected", "FAIL");
		}
		return this;
	}

	public FertilizationDataPage clickMissedOutPalm() {

		try {

			m_clickElement("id", prop.getProperty("FertilizationPage.MissedOutPalm.Id"));

			reportRequest("Missedout palm selected", "PASS");
		} catch (Exception e) {
			reportRequest("Missedout palm not selected", "FAIL");
		}
		return this;
	}

	public FertilizationDataPage enterTotal(String totalValue) {

		try {

			m_enterText("id", prop.getProperty("FertilizationPage.Total.Id"), totalValue);

			reportRequest("Total value entered as : " + totalValue, "PASS");
		} catch (Exception e) {
			reportRequest("Missedout palm not selected", "FAIL");
		}
		return this;
	}

	public FertilizationDataPage clickValidateButton() {

		try {

			m_clickElement("id", prop.getProperty("FertilizationPage.ValidateButton.Id"));

			reportRequest("Validate button clicked", "PASS");
		} catch (Exception e) {
			reportRequest("Unable to click Validate button", "FAIL");
		}
		return this;
	}

	public FertilizationDataPage enterBalance(String balance) {

		try {

			m_enterText("id", prop.getProperty("FertilizationPage.Balance.Id"), balance);

			reportRequest("Balance value enetred as : " + balance, "PASS");
		} catch (Exception e) {
			reportRequest("Unable to enter balance value", "FAIL");
		}
		return this;
	}

	public FertilizationDataPage enterEmpty(String empty) {

		try {

			m_enterText("id", prop.getProperty("FertilizationPage.Empty.Id"), empty);
			hideKeyboard();
			
			reportRequest("Empty value enetered as : " + empty, "PASS");
		} catch (Exception e) {
			reportRequest("Unable to enter empty value", "FAIL");
		}
		return this;
	}

	public FertilizationDataPage clickSubmitButton() {

		try {

			m_clickElement("id", prop.getProperty("FertilizationPage.SubmitButton.Id"));
			
			reportRequest("Submit button clicked", "PASS");
		} catch (Exception e) {
			reportRequest("Unable to click submit button", "FAIL");
		}
		return this;
	}
	
	
	public FertilizationDataPage clickConfirmButton() {

		try {

			m_clickElement("id", prop.getProperty("FertilizationPage.ConfirmPage.Confirm.Id"));

			reportRequest("Submit button clicked", "PASS");
		} catch (Exception e) {
			reportRequest("Unable to click submit button", "FAIL");
		}
		return this;
	}
	
	
	public GridPage clickBackAndGotoGridPage(){

		try{

			m_clickElement("xpath", prop.getProperty("FertilizationPage.ClickBackButton.Xpath"));
			//	logPassed("Back Button Clicked", false);
			reportRequest("Back button clicked to perform manual Sync", "PASS");

		}catch(Exception e){
			//logFailed("Unable to click Back Button");
			reportRequest("Unable to click device back button", "FAIL");

		}
		return new GridPage();
	}

}
