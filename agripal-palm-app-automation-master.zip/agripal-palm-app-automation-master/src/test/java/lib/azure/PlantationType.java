/*******************************************************************************
 *
 * Copyright (c) 2018 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 *******************************************************************************/

package lib.azure;

import java.io.Serializable;



public class PlantationType implements Serializable{
  
  private int plantationTypeId;
  private String plantationTypeName;
  
  public PlantationType() {
    super();
  }
  
  /**
   * A parameterized constructor for PlantationType object.
   * 
   * @param plantationTypeId to set
   * @param plantationTypeName to set
   */
  public PlantationType(int plantationTypeId,String plantationTypeName) {
    super();
    this.plantationTypeId = plantationTypeId;
    this.plantationTypeName = plantationTypeName;
  }
  
  /**
   * plantationTypeId.
   * 
   * @return the plantationTypeId
   */
  public int getPlantationTypeId() {
    return plantationTypeId;
  }
  
  /**
   * plantationTypeId.
   * 
   * @param plantationTypeId to set
   */
  public void setPlantationTypeId(int plantationTypeId) {
    this.plantationTypeId = plantationTypeId;
  }
  
  /**
   * plantationTypeName.
   * 
   * @return the plantationTypeName
   */
  public String getPlantationTypeName() {
    return plantationTypeName;
  }
  
  /**
   * plantationTypeName.
   * 
   * @param plantationTypeName to set
   */
  public void setPlantationTypeName(String plantationTypeName) {
    this.plantationTypeName = plantationTypeName;
  }
}
