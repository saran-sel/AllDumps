/*******************************************************************************
 *
 * Copyright (c) 2018 OLAM Limited
 *
 * All information contained herein is, and remains the property of OLAM
 * Limited. The intellectual and technical concepts contained herein are
 * proprietary to OLAM and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is
 * strictly forbidden unless prior written permission is obtained from OLAM
 * Limited
 *
 *******************************************************************************/

package lib.azure;

import lib.azure.PlantationType;

public class TokenDetail {
	private String accessToken;
	private String refreshToken;
	private String idToken;
	private String firstName;
	private String lastName;
	private String userId;
	private Long lastLogin;
	private PlantationType plantationType;
	private Long lastPasswordResetTimestamp;

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getRefreshToken() {
		return refreshToken;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}

	public String getIdToken() {
		return idToken;
	}

	public void setIdToken(String idToken) {
		this.idToken = idToken;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Long getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(Long lastLogin) {
		this.lastLogin = lastLogin;
	}

	public PlantationType getPlantationType() {
		return plantationType;
	}

	public void setPlantationType(PlantationType plantationType) {
		this.plantationType = plantationType;
	}
	
	public Long getLastPasswordResetTimestamp() {
		return lastPasswordResetTimestamp;
	}

	public void setLastPasswordResetTimestamp(Long lastPasswordResetTimestamp) {
		this.lastPasswordResetTimestamp = lastPasswordResetTimestamp;
	}

}
