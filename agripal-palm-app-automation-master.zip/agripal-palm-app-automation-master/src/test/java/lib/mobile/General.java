package lib.mobile;



import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

import io.appium.java_client.android.Activity;
import pages.mobile.palm.LoginPage;

public class General extends MobileWrappers {

	Runtime runtime = Runtime.getRuntime();

	//LoginPage login = new LoginPage();

	@BeforeTest
	public void startAppiumServer(){
		try {
			runtime.exec("cmd.exe /c start cmd.exe /k \"appium -a 127.0.0.1 -p 4723\"");
			System.out.println("Appium started");
			sleep(10000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@AfterTest(alwaysRun=true)
	public void stopAppiumServer(){
		Runtime runtime = Runtime.getRuntime();
		try {
			//uninstallApp();
			runtime.exec("taskkill /F /IM node.exe");
			//runtime.exec("taskkill /F /IM cmd.exe");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@BeforeClass()
	public void launchApplication() {

		try {
			
			new LoginPage().invokeAgriPal();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@AfterClass(alwaysRun=true)
	public void closeApplication() {

		try {

			//closeAgriPal();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}	


	@BeforeMethod
	public void beforeMethod(){
		
		System.out.println("Iam calling 1st");
		driver.startActivity(new Activity(packageName, "com.olam.gabon.ui.SplashActivity"));
		

		sleep(3000);
		turnOffImplicitWaits();

		if(driver.findElementsById(prop.getProperty("GrantPermission.Alert.Allow")).size()>0){
			System.out.println("Security alert came---");
			turnOnImplicitWaits();
			acceptSecurityAlerts();
			
		


		} else if(driver.findElementsById(prop.getProperty("LoginPage.LoginButton.ID")).size()>0){
			System.out.println("No security alert - but login");
			turnOnImplicitWaits();
			
		


		}else{
			System.out.println("directly in dashboard");
			turnOnImplicitWaits();
		}

	}


	@AfterMethod(alwaysRun=true)
	public void afterMethod(){

		//driver.resetApp();
		System.out.println("");
	}






}
