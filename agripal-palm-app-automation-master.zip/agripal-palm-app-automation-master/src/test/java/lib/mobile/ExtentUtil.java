package lib.mobile;


import java.net.InetAddress;
import java.util.HashMap;
import java.util.Map;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.ExtentXReporter;
import com.aventstack.extentreports.reporter.KlovReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.mongodb.MongoClientURI;

public class ExtentUtil {

	static ExtentReports extentReports=null;
	static ExtentXReporter extentXReports=null;
	static KlovReporter klov = null;
	static Map<Integer,ExtentTest> extentTestMap = new HashMap<Integer, ExtentTest>();

	public static ExtentReports createReporter(String fileName) throws Exception{
		//HTML Reporter
		ExtentHtmlReporter extentHtmlReporter = new ExtentHtmlReporter(fileName);
		extentHtmlReporter.config().setTheme(Theme.STANDARD);
		extentHtmlReporter.config().setReportName("AgriPal Test Automation Reports");
		extentHtmlReporter.config().setChartVisibilityOnOpen(true);
		
		klov = new KlovReporter();
		MongoClientURI mongo = new MongoClientURI("mongodb://admin:admin1234@ds153763.mlab.com:53763/klov");
		klov.initMongoDbConnection(mongo);
		klov.setProjectName("Agripal-RestAssured");
		klov.setKlovUrl("https://cloudreports-agripal.herokuapp.com");
	
		
		
		extentXReports = new ExtentXReporter("admin:Test1234@ds153763.mlab.com",53763);
		extentXReports.config().setServerUrl("https://cloudreports-agripal.herokuapp.com");
		extentXReports.config().setReportName("Agripal Test Reports");

		extentReports = new ExtentReports();
		extentReports.attachReporter(extentHtmlReporter,klov);
		
		extentReports.attachReporter(extentHtmlReporter);
		
		extentReports.setSystemInfo("HostName", InetAddress.getLocalHost().getHostName());
		extentReports.setSystemInfo("IP Address", InetAddress.getLocalHost().getHostAddress());
		extentReports.setSystemInfo("OS",System.getProperty("os.name"));
		extentReports.setSystemInfo("Username", "Saravanan G");
		extentReports.setSystemInfo("Java Version", System.getProperty("java.version"));
		
		
		
		return extentReports;
	}

	public static ExtentReports getExtentReports(){
		return extentReports;
	}

	public static void saveReporter(){
		if(extentReports !=null){
			extentReports.flush();
		}
	}

	public static synchronized ExtentTest createTest(String testName){
		ExtentTest extentTest = extentReports.createTest(testName);
		extentTestMap.put((int) (Thread.currentThread().getId()),extentTest);
		return extentTest;
	}

	public static synchronized ExtentTest createTest(String testName,String testDesc){
		ExtentTest extentTest = extentReports.createTest(testName,testDesc);
		extentTestMap.put((int) (Thread.currentThread().getId()),extentTest);
		return extentTest;
	}

	public static synchronized ExtentTest fetchTest(){
		
		return extentTestMap.get((int) (Thread.currentThread().getId()));
	}


}
