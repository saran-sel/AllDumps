package lib.mobile;

import static org.testng.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;

import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import lib.api.PreAndTest;

public class MobileWrappers extends PreAndTest {

	Runtime runtime = Runtime.getRuntime();
	SoftAssert softAssert = new SoftAssert();

	public static AndroidDriver<WebElement> driver;
	Properties prop;


	public MobileWrappers() {
		prop = loadObjectRepository();
	}

	public Properties loadObjectRepository() {
		Properties prop = new Properties();

		try {
			prop.load(new FileInputStream(new File(".data/Object.properties")));
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

		return prop;
	}

	public void appLaunchSetup() {

		try{

			DesiredCapabilities capabilities = new DesiredCapabilities();

			File app = new File("./apk/SFGO-AgriPal-Rubber-Android-sitAKS-debug-2.0.5.apk");

			capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Android");
			capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "7.0");
			capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
			capabilities.setCapability("autoGrantPermissions", true);
			capabilities.setCapability("appPackage", "io.appium.settings");
			capabilities.setCapability("appActivity", "io.appium.settings.Settings");
			capabilities.setCapability("newCommandTimeout", "300");

			driver = new AndroidDriver<WebElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			
			System.out.println("Iam: "+packageName);
			
			if (driver.isAppInstalled(packageName)) {
				System.out.println("App already installed");
				/*BeforeMethod will be executed*/
			} else {

				System.out.println("Expected app not found on device, Trying to install....");
				driver.installApp(app.getAbsolutePath());

				/*BeforeMethod will be executed*/

			}


		}catch(Exception e){
			e.printStackTrace();

		}

	}

	public void acceptSecurityAlerts(){

		ArrayList<String> str = new ArrayList<String>();

		str.add("Allow AgriPal to take pictures and record video?");
		str.add("Allow AgriPal to access photos, media, and files on your device?");
		str.add("Allow AgriPal to access this device's location?");
		str.add("Allow Agripal to make and manage phone calls?");
		str.add("Allow AgriPal to record audio?");

		for (int i = 0; i < str.size(); i++) {

			//m_getTextDisplayed("id", prop.getProperty("GrantPermission.Alert.Message"), str.get(i));
			m_clickElement("id", prop.getProperty("GrantPermission.Alert.Allow"));
		}



	}

	public void loginAgripal(String username,String password){

		try{

			m_enterText("id", prop.getProperty("LoginPage.Password.ID"), password);
			m_enterText("id", prop.getProperty("LoginPage.UserID.Id"), username);
			hideKeyboard();
			sleep(2000);
			m_clickElement("id", prop.getProperty("LoginPage.LoginButton.ID"));
			sleep(30000);

		}catch(Exception e){

		}
	}

	public void conditionalWait(String locator,String locatorValue){

		WebDriverWait wait = new WebDriverWait(driver, 30);

		if(locator.equalsIgnoreCase("id")){
			//wait.until(ExpectedConditions.presenceOfElementLocated(By.id(locator)));

		}else if(locator.equalsIgnoreCase("xpath")){
			//wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(locator)));

		}
	}


	public boolean checkAlertMessages(){
		Boolean isItemPresent = driver.findElementsById("com.android.packageinstaller:id/dialog_container").size() > 0;
		return isItemPresent;
	}

	public void m_enterText(String locator, String locatorValue, String textTobeEntered) {

		if (locator.equalsIgnoreCase("id")) {
			driver.findElementById(locatorValue).sendKeys(textTobeEntered);

		} else if (locator.equalsIgnoreCase("xpath")) {
			driver.findElementByXPath(locatorValue).sendKeys(textTobeEntered);

		}

	}

	public void m_clickElement(String locator, String locatorValue) {

		if (locator.equalsIgnoreCase("id")) {
			driver.findElementById(locatorValue).click();

		} else if (locator.equalsIgnoreCase("xpath")) {
			driver.findElementByXPath(locatorValue).click();
		}
	}

	public void m_clearElement(String locator, String locatorValue) {

		if (locator.equalsIgnoreCase("id")) {
			driver.findElementById(locatorValue).clear();

		} else if (locator.equalsIgnoreCase("xpath")) {
			driver.findElementByXPath(locatorValue).clear();
		}
	}

	public String m_getTextDisplayed(String locator, String locatorValue, String expectedText) {

		String textOnScreen = "";

		if (locator.equalsIgnoreCase("id")) {
			textOnScreen = driver.findElementById(locatorValue).getText();
			assertEquals(textOnScreen, expectedText);
			System.out.println(textOnScreen);

		} else if (locator.equalsIgnoreCase("xpath")) {
			textOnScreen = driver.findElementByXPath(locatorValue).getText();
			assertEquals(textOnScreen, expectedText);
			System.out.println(textOnScreen);
		}
		return textOnScreen;

	}

	public String m_getTextDisplayed(String locator, String locatorValue) {

		String textOnScreen = "";

		if (locator.equalsIgnoreCase("id")) {
			textOnScreen = driver.findElementById(locatorValue).getText();
			//assertEquals(textOnScreen, expectedText);
			System.out.println(textOnScreen);

		} else if (locator.equalsIgnoreCase("xpath")) {
			textOnScreen = driver.findElementByXPath(locatorValue).getText();
			//assertEquals(textOnScreen, expectedText);
			System.out.println(textOnScreen);
		}

		return textOnScreen;
	}

	public void m_checkElementPresentAndClickable(String locator, String locatorValue){

		Boolean bReturn = null ;

		if(locator.equalsIgnoreCase("id")){

			bReturn =driver.findElementById(locatorValue).isDisplayed();
			System.out.println(driver.findElementById(locator).getAttribute("clickable"));

		}else if(locator.equalsIgnoreCase("xpath")){

			bReturn = driver.findElementByXPath(locatorValue).isDisplayed();
			System.out.println(driver.findElementById(locator).getAttribute("clickable"));

		}

		System.out.println("Element is "+bReturn);

	}

	public void checkElementAttribute(String xpath,String attributeValue){

		List<WebElement> ele =  driver.findElementsByXPath(xpath);

		for (int i = 0; i < ele.size(); i++) {

			System.out.println("vvvvvvvvvv  "+ele.get(i).getAttribute(attributeValue));
		}
	}

	public void getScreenshot(String logMessage) throws IOException {

		DateFormat df = new SimpleDateFormat("dd-MMM-yyyy_hh_mm_ss_aa");
		String fileName = df.format(new Date()) + ".png";

		File f = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(f, new File("images/" + fileName + ".png"));
		ExtentUtil.fetchTest().info(logMessage,
				MediaEntityBuilder.createScreenCaptureFromPath("images/" + fileName + ".png").build());

	}

	public void logPassed(String logMessage, Boolean snapShotOption) {

		ExtentUtil.fetchTest().log(Status.PASS, logMessage);
		try {

			if (snapShotOption) {
				getScreenshot(logMessage);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void logFailed(String logMessage) {

		ExtentUtil.fetchTest().log(Status.FAIL, logMessage);
		try {
			getScreenshot(logMessage);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public boolean explicitWaitUntilElementPresent(String id) {

		boolean bReturn = true;
		WebDriverWait wait = new WebDriverWait(driver, 2);
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		bReturn = false;

		return bReturn;
	}

	public boolean isElementPresent(String id) {

		return driver.findElementById(id).isDisplayed();
	}

	public void sleep(int msec) {
		try {
			Thread.sleep(msec);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	public void hideKeyboard() {
		driver.hideKeyboard();
	}

	public void checkAllElementsPresent(String id, String successLog){

		List eleSize = driver.findElementsById(id);
		System.out.println(eleSize.size());
		if(!eleSize.isEmpty()){
			logPassed(successLog, true);
		}
	}

	public void getStringValueFromList(String xpath){


		List<WebElement> ele =driver.findElementsByXPath(xpath);

		for (int i = 0; i < ele.size(); i++) {

			System.out.println(ele.get(i).getText());
		}


	}

	public String processTextForTreeRecordVerification(String temp){

		return temp.toUpperCase().replace("_", " ");

	}

	//	public void scrollDown(String textToBeFound) {
	//
	//		driver.scrollToExact(textToBeFound);
	//
	//	}

	/*public void clickBackButton() {

		driver.sendKeyEvent(4);
	}
	 */
	public void startNewActivity(String appPackage, String appActivity) {
		try {
			driver.startActivity(new Activity(appPackage, appActivity));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void restoreApp() {

		driver.resetApp();
	}

	public void closeAgriPal() {

		driver.closeApp();
	}

	public void turnOffImplicitWaits() {
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
	}

	public void turnOnImplicitWaits() {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	public void uninstallApp() {
		driver.removeApp("com.olam.gabon");
	}

	public String fetchCurrentDate(){

		Date date = new Date();  
		SimpleDateFormat formatter = new SimpleDateFormat("dd/M/yyyy");  
		String strDate= formatter.format(date);  
		System.out.println(strDate);  
		return strDate;
	}


	public static String[][] getPalmUsers(String sheetName){
		String[][] ret = null;
		try{

			String role=null, userID=null,password=null,workerIDOne=null,workerIDTwo=null;
			File file = new File("./data/user_details.xlsx");
			FileInputStream fis = new FileInputStream(file);

			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName);

			int row = sheet.getLastRowNum();
			ret = new String[row+1][5];
			for (int i = 0; i <= row; i++) {
				role = sheet.getRow(i).getCell(2).getStringCellValue();
				if(!"WOR".equals(role)){
					password = sheet.getRow(i).getCell(0).getStringCellValue();
					userID = sheet.getRow(i).getCell(1).getStringCellValue();
					workerIDOne = null != sheet.getRow(i).getCell(3) ? sheet.getRow(i).getCell(3).getStringCellValue() : null;
					workerIDTwo = null != sheet.getRow(i).getCell(4) ? sheet.getRow(i).getCell(4).getStringCellValue() : null;

					ret[i][0] = password;
					ret[i][1] = userID;
					ret[i][2] = role;
					ret[i][3] = workerIDOne;
					ret[i][4] = workerIDTwo;
				}

			}
			System.out.println(Arrays.deepToString(ret));

		}catch(Exception e){
			e.printStackTrace();
		}

		return ret;
	}

	public void executeQueryAndSaveDataInCSV(String query){

		try{

			String[] command1 = {"cmd.exe", "/C", "Start", "./Sql/test.bat" , query};


			Process p =  Runtime.getRuntime().exec(command1);
			sleep(5000);

		}catch(Exception e){
			e.printStackTrace();
		}

	}

	public ArrayList<HashMap<String, String>> readCSVFile(String filePath) throws IOException {
		List<String> header = new ArrayList<String>();
		HashMap<String, String> tempMap = null;
		List<String> tempArr = null;
		ArrayList<HashMap<String, String>> result = new ArrayList<HashMap<String, String>>();

		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";

		if(new File(filePath).exists()){
			br = new BufferedReader(new FileReader(filePath));

			int i = 0;
			while ((line = br.readLine()) != null) {
				String[] columns = line.split(cvsSplitBy.trim());

				if(i == 0){
					header = Arrays.asList(columns);
				}else if(i > 1){
					tempArr = Arrays.asList(columns);

					if(tempArr.size() > 30){
						tempMap = new HashMap<String, String>();

						for(int j=0;j<header.size();j++){
							tempMap.put(header.get(j).trim(), tempArr.get(j).trim());
						}

						result.add(tempMap);
					}
				}
				i++;
			}
		}
		return result;
	}

	public ArrayList<HashMap<String, String>> getDataFromCSV(){

		String filePath = "./Sql/data.csv";
		ArrayList<HashMap<String, String>> output = null;
		try {
			output = readCSVFile(filePath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return output;
	}

	public boolean valOutPutDataFromCSV(String columnName , String compareValue){
		ArrayList<HashMap<String, String>> dataArr = getDataFromCSV();
		for(HashMap<String, String> temp : dataArr){

			System.out.println(temp.get("record_id"));
			if(!(temp.get(columnName) != null && temp.get(columnName).equals(compareValue))){

				return false;
			}
		}
		return true;
	}
	public String identifyUserType(String getUserRole){

		String userRole=null;

		try{
			if(getUserRole.equalsIgnoreCase("GM")){
				userRole ="managerLogin";

			} else if(getUserRole.equalsIgnoreCase("RM")){
				userRole ="managerLogin";

			}else if(getUserRole.equalsIgnoreCase("EM")){
				userRole ="managerLogin";

			}else if(getUserRole.equalsIgnoreCase("AM")){
				userRole ="managerLogin";

			}else if(getUserRole.contains("CDQ")){
				userRole ="CDQLogin";
			}

		}catch(Exception e){
			e.printStackTrace();
		}
		return userRole;
	}




	public void clearAppData(){

		try {
			runtime.exec("adb shell pm clear "+packageName);
			System.out.println("app data cleared");
			
			startNewActivity(packageName, "com.olam.gabon.ui.SplashActivity");
			acceptSecurityAlerts();
			//loginAgripal("000701", "olamdev");



		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	public List<HashMap<Object,Object>> db(String query,String action) {

		List<HashMap<Object,Object>> returnMap = new ArrayList<>();
		Map<String,Integer> columnDetails = new HashMap<String,Integer>();
		try {
			connection = DriverManager.getConnection(url);

			Statement statement = connection.createStatement();
			if("SELECT".equals(action)) {
				ResultSet resultSet = statement.executeQuery(query);
				ResultSetMetaData rsMetaData = resultSet.getMetaData();
				int numberOfColumns = rsMetaData.getColumnCount();

				for (int i = 1; i < numberOfColumns + 1; i++) {
					columnDetails.put(rsMetaData.getColumnName(i), rsMetaData.getColumnType(i));
				}
				HashMap<Object,Object> temp;
				while(resultSet.next()) {
					temp = new HashMap<>();
					for(String columnName : columnDetails.keySet()) {
						if(columnDetails.get(columnName) == 4) {
							temp.put(columnName, resultSet.getInt(columnName));
						}else if (columnDetails.get(columnName) == 12) {
							temp.put(columnName, resultSet.getString(columnName));
						}else {
							temp.put(columnName, resultSet.getObject(columnName));
						}
					}
					returnMap.add(temp);
				}
				resultSet.close();
			}else {
				statement.execute(query);
			}
			statement.close();
		}
		catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("DB result----------------"+returnMap);
		return returnMap;
	}


	protected Object getValueFromListOfMap(List<HashMap<Object, Object>> listMap, String key, String value, String target_column) {
		// TODO Auto-generated method stub
		if(listMap.size() == 1) {
			if(key == null) {
				return listMap.get(0).get(target_column);
			}else {
				if(listMap.get(0).get(key).toString().equalsIgnoreCase(value)) {
					return listMap.get(0).get(target_column);
				}
			}
		}else {
			for(Map temp : listMap) {
				if(temp.get(key).toString().equalsIgnoreCase(value)) {
					return temp.get(target_column);
				}
			}
		}
		return null;
	}

	public static List<String> getUserIdForRole(String role, String location, int userCount, Object[][] palmUserSet) {

		List<String> userIdList = new ArrayList<String>();
		int count = 0;
		for (int i = 0; i < palmUserSet.length; i++) {
			String userId = null;
			String roleCode = (String) palmUserSet[i][2];
			String locationId = (String) palmUserSet[i][3];
			if (roleCode.equalsIgnoreCase(role) && location.equalsIgnoreCase(locationId)) {
				userId = (String) palmUserSet[i][1];
				userIdList.add(userId);
				count++;
			}
			System.out.println("User Id: " + userId);
			System.out.println("RoleCode: " + roleCode + "\n");

			if (count == userCount) {
				break;
			}
		}

		return userIdList;
	}

	public void validateDBResult(List<HashMap<Object, Object>> dbResult, String columnToBeChecked,
			String valueToBeChecked, boolean checkForNoResult, String message) {

		try {
			reportRequest(message, "PASS");
			List<HashMap<Object, Object>> mapList = dbResult;

			if (checkForNoResult) {
				System.out.println("Asserting if the result is empty, Map list Size: " + mapList.size());
				assertEquals(mapList.size(), 0);
			}

			else {
				for (HashMap<Object, Object> map : mapList) {
					JSONObject jsonObject = new JSONObject(map);
					Set<String> keys = jsonObject.keySet();

					// Need to remove this as , if the result set does not contain id, this may fail
					String userId = (String) jsonObject.get("user_id");
					for (String key : keys) {
						if (key.equalsIgnoreCase(columnToBeChecked)) {
							System.out.println("Asserting -- Expected :" + valueToBeChecked.toLowerCase() + " Actual : "
									+ jsonObject.get(key).toString().toLowerCase() + " User Id: " + userId);
							softAssert.assertEquals(jsonObject.get(key).toString().toLowerCase(),
									valueToBeChecked.toLowerCase(),
									"Expected :" + valueToBeChecked.toLowerCase() + " Actual : "
											+ jsonObject.get(key).toString().toLowerCase() + " User Id: " + userId);
						}
					}
				}
			}
		} catch (Exception e) {
			reportRequest(message, "FAIL");
			e.printStackTrace();
		}
	}
	
	public void m_checkElementAttributeValue(String locator, String locatorValue, String attributeName, String attributeValue){
		if(locator.equalsIgnoreCase("id")){
			String actualValue = driver.findElementById(locatorValue).getAttribute(attributeName);
			softAssert.assertEquals(actualValue.toLowerCase(), attributeValue.toLowerCase());
		}
		else if(locator.equalsIgnoreCase("xpath")){
			String actualValue = driver.findElementByXPath(locatorValue).getAttribute(attributeName);
			softAssert.assertEquals(actualValue.toLowerCase(), attributeValue.toLowerCase());
		}
	}
	
	public void m_checkWildCardAttributeValueMatch(String locator, String locatorValue, String attributeName, String attributeValue){
		
		String actualValue = "";
		boolean matchPresent;
		
		if(locator.equalsIgnoreCase("id")){
			actualValue = driver.findElementById(locatorValue).getAttribute(attributeName);
		}
		else if(locator.equalsIgnoreCase("xpath")){
			actualValue = driver.findElementByXPath(locatorValue).getAttribute(attributeName);
		}
		matchPresent = actualValue.toLowerCase().contains(attributeValue.toLowerCase()) 
				|| attributeValue.toLowerCase().contains(actualValue.toLowerCase()) ? true : false;
		softAssert.assertTrue(matchPresent);
	}
	
	public boolean m_isElementPresent(String id) {
		if (driver.findElementsById(id).size() > 0)
			return true;
		else 
			return false;
	}
	
	public void m_getParentElement(String locator, String locatorValue) {
		if(locator.equalsIgnoreCase("id")){
			WebElement childElement = driver.findElementById(locatorValue);
			WebElement parentElement = driver.findElementById(locatorValue+"/..");
			System.out.println("childElement.getTagName() = "+childElement.getTagName());
			System.out.println("parentElement.getTagName() = "+parentElement.getTagName());
		}
		else if(locator.equalsIgnoreCase("xpath")){
			WebElement childElement = driver.findElementByXPath(locatorValue);
			System.out.println("childElement.getTagName() = "+childElement.getTagName());
			WebElement parentElement = driver.findElementByXPath(locatorValue+"/../..");
			System.out.println("parentElement.getTagName() = "+parentElement.getTagName());
			WebElement statusElement = driver.findElementByXPath(locatorValue+"/../../android.widget.RelativeLayout[@resource-id='com.olam.gabon.mvpaks:id/rel_quick_note_status']/android.widget.TextView[@resource-id='com.olam.gabon.mvpaks:id/text_quick_note_status']");
			System.out.println("statusElement.getTagName() = "+statusElement.getTagName());
			System.out.println("statusElement.getText() = "+statusElement.getText());
		}
	}
	
	public List<String> getDBRecord(List<HashMap<Object, Object>> dbResult, String... columnValueToBeRetrievedList) {
		List<String> columnValueList = new ArrayList<String>();
		try {
			List<HashMap<Object, Object>> mapList = dbResult;
			for (HashMap<Object, Object> map : mapList) {
				JSONObject jsonObject = new JSONObject(map);
				String columnValue = null;
				for (String columnValueToBeRetrieved : columnValueToBeRetrievedList) {

					columnValue = jsonObject.get(columnValueToBeRetrieved).toString();
					System.out.println("Column Value :" + columnValue);
					columnValueList.add(columnValue);
				}
			}
		} catch (Exception e) {
			reportRequest("Unable to get result", "FAIL");
			e.printStackTrace();
		}
		return columnValueList;
	}
	
	public String queryBuilder(String query, List<String> queryParams) {
		String queryBuilder = query;
		for (int i = 0; i < queryParams.size(); i++) {
			if (queryParams.size() == 1) {
				queryBuilder = queryBuilder + "'"+queryParams.get(i)+"'";
				break;
			}
			if (i == 0) 
				queryBuilder = queryBuilder + "'"+queryParams.get(i) +"',";
			
			else if (i == queryParams.size()-1) 
				queryBuilder = queryBuilder + "'"+queryParams.get(i) +"'";
			
			else 
				queryBuilder = queryBuilder + "'"+queryParams.get(i) +"',";
		}
		queryBuilder = queryBuilder +");";
		System.out.println("Query: "+queryBuilder);
		return queryBuilder;
	}
}
