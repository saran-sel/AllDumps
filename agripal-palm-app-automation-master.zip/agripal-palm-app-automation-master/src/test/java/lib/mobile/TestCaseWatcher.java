package lib.mobile;

import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

public class TestCaseWatcher extends TestListenerAdapter {

	@Override
	public void onTestSuccess(ITestResult tr) {

		ExtentUtil.fetchTest().pass("Passed");
	}

	@Override
	public void onTestFailure(ITestResult tr) {
		
		ExtentUtil.fetchTest().fail("Failed");
	}

	@Override
	public void onTestSkipped(ITestResult tr) {

	}


	@Override
	public void onStart(ITestContext testContext) {

		try {
			ExtentUtil.createReporter("AgriPalTestReports.html");
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}

	@Override
	public void onFinish(ITestContext testContext) {
		
		ExtentUtil.saveReporter();
	}


	@Override
	public void onTestStart(ITestResult result) {

		ExtentUtil.createTest(result.getMethod().getMethodName());
	}

}
