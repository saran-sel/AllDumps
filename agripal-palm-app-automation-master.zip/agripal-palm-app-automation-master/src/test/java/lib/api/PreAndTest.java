package lib.api;

import java.io.File;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import io.restassured.RestAssured;
import lib.utils.DataInputProvider;
import lib.utils.HTMLReporter;

public class PreAndTest extends HTMLReporter {

	public String dataFileName, dataFileType;
	
/*	String hostName = "agripalsit.database.windows.net"; // update required
	String dbName = "AgriPalSIT"; // update required
	String user = "agripalsitdbuser"; // update required
	String password = "QWER!@#$0987asdf"; // update required
	public String url = String.format(
			"jdbc:sqlserver://%s:1433;database=%s;user=%s;password=%s;encrypt=true;"
					+ "hostNameInCertificate=*.database.windows.net;loginTimeout=30;",
			hostName, dbName, user, password);
	public Connection connection = null;*/

	
/*	  String hostName = "agripaluat.database.windows.net"; // update required
	  String dbName = "AgriPalUAT"; // update required 
	  String user = "agripaluatdbuser";
	  String password = "NbTX3edkaC"; //
	  public String url = String.format(
	  "jdbc:sqlserver://%s:1433;database=%s;user=%s;password=%s;encrypt=true;" +
	  "hostNameInCertificate=*.database.windows.net;loginTimeout=30;", hostName,
	  dbName, user, password); public Connection connection = null;*/
	  
	  String hostName = "agripalprod.database.windows.net"; // update required
	  String dbName = "AgriPalPROD"; // update required 
	  String user = "agripalproddbuser";
	  String password = "4sQfwPHXr5Bgb3k"; //
	  public String url = String.format(
	  "jdbc:sqlserver://%s:1433;database=%s;user=%s;password=%s;encrypt=true;" +
	  "hostNameInCertificate=*.database.windows.net;loginTimeout=30;", hostName,
	  dbName, user, password); public Connection connection = null;
	 

	public int ripe, overRipe, underRipe, sickBunches, emptyBunches, unripeBunches, uncollectedBunches,
			unHarvestedBunches, path, circle, platform, frondExile,diseasedBunches,cropRecoveryTotalBunches,bunchQualityTotalBunches;

	public int wrongType, wrongDosage, wrongPlacement, wrongTiming, missedOutPalm, total, balance, empty;

	Map<String, String> headerMap = new HashMap<>();
	JSONObject requestParams = new JSONObject();

	@BeforeSuite(alwaysRun = true)
	public void beforeSuite() {
		startReport();
		
		
	}

	@BeforeClass(alwaysRun = true)
	public void beforeClass() {
		startTestCase(testCaseName, testDescription);

	}

	@BeforeMethod(alwaysRun = true)
	public void beforeMethod() {
		// for reports
		svcTest = startTestModule(nodes);
		svcTest.assignAuthor(authors);
		svcTest.assignCategory(category);
//		RestAssured.baseURI = "https://zuul-sit-agripal.olamdigital.com";
//		 RestAssured.baseURI = "https://zuul-uat-agripal.olamdigital.com";
		RestAssured.baseURI = "https://agripal-zuul.olamdigital.com";
	}

	@AfterMethod(alwaysRun = true)
	public void afterMethod() {
	}

	@AfterSuite(alwaysRun = true)
	public void afterSuite() {
		endResult();
		/*
		 * try { connection.close(); } catch (SQLException e) { // TODO Auto-generated
		 * catch block e.printStackTrace(); }
		 */
	}

	@DataProvider(name = "fetchData")
	public Object[][] getData() {
		if (dataFileType.equalsIgnoreCase("Excel"))
			return DataInputProvider.getSheet(dataFileName);
		else {
			Object[][] data = new Object[1][1];
			data[0][0] = new File("./data/" + dataFileName + "." + dataFileType);
			System.out.println(data[0][0]);
			return data;
		}

	}

	@Override
	public long takeSnap() {
		return 0;
	}
	
	

}
