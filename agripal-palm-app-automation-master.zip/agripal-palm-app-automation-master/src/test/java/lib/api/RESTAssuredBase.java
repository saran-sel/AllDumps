package lib.api;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.microsoft.aad.adal4j.AuthenticationContext;
import com.microsoft.aad.adal4j.AuthenticationResult;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestLogSpecification;
import io.restassured.specification.RequestSpecification;
import lib.azure.TokenDetail;
import net.minidev.json.JSONObject;

public class RESTAssuredBase extends PreAndTest{

	Random randomNum = new Random();
	int max =10;
	int min =1;
	public static HashMap<String, String> loc = new HashMap<>();
	public static String gmLoc = "";
	public static String rmLocation = "";
	public static long getAccessTokenTime;

	public static RequestSpecification setLogs() {

		RequestLogSpecification log = RestAssured
				.given()
				.log();
		return log.ifValidationFails();
	}

	public static Response get(String URL) {
		return setLogs()
				.when().get(URL);
	}

	public static Response get() {
		return setLogs()
				.get();
	}

	public static Response getWithHeader(Map<String, String> headers, String URL) {

		return setLogs()
				.when()
				.headers(headers)
				.get(URL);
	}

	public static Response post() {

		return setLogs()
				.post();
	}

	public static Response post(String URL) {

		return setLogs()
				.post(URL);
	}

	public static Response postWithBodyAsFile(File bodyFile) {

		return setLogs()
				.body(bodyFile)
				.post();
	}

	public static Response postWithHeaderAndForm(Map<String, String> headers,
			JSONObject jsonObject, String URL) {

		return setLogs()
				.headers(headers)
				.body(jsonObject)
				.post(URL);
	}

	public static Response postWithJsonAsBody(String jsonObject, String URL) {

		return setLogs()
				.body(jsonObject)
				.post(URL);
	}

	public static Response postWithHeaderAndJsonBody(Map<String, String> headers,
			String jsonObject, String URL) {

		return setLogs()
				.relaxedHTTPSValidation()
				.when()
				.headers(headers)
				.body(jsonObject)
				.post(URL);
	}

	public static Response postWithHeaderParam(Map<String, String> headers, String URL) {

		return setLogs()
				.when()
				.headers(headers)
				.post(URL);
	}

	public static Response postWithRelaxedHttpsValidation(Map<String, String> headers,
			File jsonObject,String URL) {

		return setLogs()
				.relaxedHTTPSValidation()
				.headers(headers)
				.body(jsonObject)
				.post(URL);
	}

	public static Response delete(String URL) {
		return setLogs()
				.when()
				.delete(URL);
	}

	public static Response deleteWithHeaderAndPathParam(Map<String, String> headers,
			JSONObject jsonObject, String URL) {

		return setLogs()
				.when()
				.headers(headers)
				.body(jsonObject)
				.delete(URL);
	}

	public static Response deleteWithHeaderAndPathParamWithoutRequestBody(
			Map<String, String> headers, String URL) throws Exception {
		return setLogs()
				.when()
				.headers(headers)
				.delete(URL);
	}

	public static Response putWithHeaderAndBodyParam(Map<String, String> headers,
			JSONObject jsonObject, String URL) {

		return RestAssured.given().headers(headers).contentType(getContentType()).request()
				.body(jsonObject).when().put(URL);
	}

	public static Response putWithHeaderAndBodyParamFile(Map<String, String> headers, File jsonObject, String URL) {

		return setLogs().given().headers(headers).contentType(getContentType()).request().body(jsonObject).when()
				.put(URL);
	}

	private static ContentType getContentType() {

		return ContentType.JSON;

	}

	public static void verifyContentType(Response response, String type) {
		if(response.getContentType().toLowerCase().contains(type.toLowerCase())) {
			reportRequest("The Content type "+type+" matches the expected content type", "PASS");
		}else {
			reportRequest("The Content type "+type+" does not match the expected content type "+response.getContentType(), "FAIL");	
		}
	}

	public static void verifyResponseCode(Response response, int code) {

		System.out.println("Test: "+response.statusCode());
		if(response.statusCode() == code) {
			reportRequest("The status code "+code+" matches the expected code", "PASS");
		}else {
			reportRequest("The status code "+code+" does not match the expected code"+response.statusCode(), "FAIL");	
		}
	}

	public static void verifyResponseTime(Response response, long time) {
		if(response.time() <= time) {
			reportRequest("The time taken "+response.time() +" with in the expected time", "PASS");
		}else {
			reportRequest("The time taken "+response.time() +" is greater than expected SLA time "+time,"WARNING");		
		}
	}

	public static void verifyContentWithKey(Response response, String key, String expVal) {
		if(response.getContentType().contains("json")) {
			JsonPath jsonPath = response.jsonPath();
			String actValue = jsonPath.get(key);
			System.out.println("bearer token:  "+jsonPath.get(key));
			if(actValue.equalsIgnoreCase(expVal)) {
				reportRequest("The JSON response has value "+expVal+" as expected. ", "PASS");
			}else {
				reportRequest("The JSON response :"+actValue+" does not have the value "+expVal+" as expected. ", "WARNING");		
			}
		}
	}

	public String verifyContentsWithKeystring(Response response, String key, String expVal) {
		String actValue="";
		if (response.getContentType().contains("json")) {
			JsonPath jsonPath = response.jsonPath();
			actValue = jsonPath.get(key);
			System.out.println(actValue);

			if (actValue.equalsIgnoreCase(expVal)) {
				//	System.out.println("Iam the pass");
				reportRequest("The JSON response has value " + expVal + " as expected. ", "PASS");
			} else {
				System.out.println("Iam the fail");
				reportRequest("The JSON response :" + key + " does not have the value " + expVal + " as expected. ",
						"WARNING");
			}
		}
		return actValue;
	}

	public String getJsonInfoWithKeystring(Response response, String key) {
		String actValue="";
		try {
			if (response.getContentType().contains("json")) {
				JsonPath jsonPath = response.jsonPath();
				actValue = jsonPath.get(key);
				boolean bReturn = true;
				if (bReturn) {
					reportRequest("JSON contents returned suuccessfully: "+actValue, "PASS");
				} else {
					reportRequest("Unable to return JSON values" + actValue + " as expected. ",
							"FAIL");
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return actValue;
	}

	public void revertChanges(Set<String> successIds) {
		if(successIds.size() > 0) {
			StringBuffer updateQuery = new StringBuffer("Update  [dbo].[user] set is_deleted = '1' where user_id in (");
			for(String id : successIds) {
				updateQuery.append("'").append(id).append("',");
			}
			db(updateQuery.substring(0, updateQuery.length()-1) + ")","UPDATE");
		}
	}

	public static String getAccessToken(Response response, String key) {
		String actValue = null;
		if (response.getContentType().contains("json")) {
			JsonPath jsonPath = response.jsonPath();
			actValue = jsonPath.get(key);
			//	System.out.println("actual"+actValue);
			boolean bReturn = true;
			if (bReturn) {
				//reportRequest("Access token retreived successfully  "+actValue, "PASS");
			} else {
				//reportRequest("Unable to retreive access token","FAIL");
			}
		}
		return actValue;
	}

	public static void verifyContentsWithKey(Response response, String key, String expVal) {
		if(response.getContentType().contains("json")) {
			JsonPath jsonPath = response.jsonPath();
			List<String> actValue = jsonPath.getList(key);
			if(actValue.get(0).equalsIgnoreCase(expVal)) {
				reportRequest("The JSON response has value "+expVal+" as expected. ", "PASS");
			}else {
				reportRequest("The JSON response :"+actValue+" does not have the value "+expVal+" as expected. ", "FAIL");		
			}
		}
	}

	public static List<String> getContentsWithKey(Response response, String key) {
		if(response.getContentType().contains("json")) {
			JsonPath jsonPath = response.jsonPath();
			return jsonPath.getList(key);			
		}else {
			return null;
		}
	}

	public static String getContentWithKey(Response response, String key) {
		if(response.getContentType().contains("json")) {
			JsonPath jsonPath = response.jsonPath();
			return (String) jsonPath.get(key);			
		}else {
			return null;
		}
	}

	public long get18YearsBackDate() {

		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.YEAR, -18); // to get 18 years back timestamp from now
		long getTimeStamp = cal.getTimeInMillis();
		return getTimeStamp ;		
	}

	public List<HashMap<Object,Object>> db(String query,String action) {

		List<HashMap<Object,Object>> returnMap = new ArrayList<>();
		Map<String,Integer> columnDetails = new HashMap<String,Integer>();
		try {
			connection = DriverManager.getConnection(url);

			Statement statement = connection.createStatement();
			if("SELECT".equals(action)) {
				ResultSet resultSet = statement.executeQuery(query);
				ResultSetMetaData rsMetaData = resultSet.getMetaData();
				int numberOfColumns = rsMetaData.getColumnCount();

				for (int i = 1; i < numberOfColumns + 1; i++) {
					columnDetails.put(rsMetaData.getColumnName(i), rsMetaData.getColumnType(i));
				}
				HashMap<Object,Object> temp;
				while(resultSet.next()) {
					temp = new HashMap<>();
					for(String columnName : columnDetails.keySet()) {
						if(columnDetails.get(columnName) == 4) {
							temp.put(columnName, resultSet.getInt(columnName));
						}else if (columnDetails.get(columnName) == 12) {
							temp.put(columnName, resultSet.getString(columnName));
						}else {
							temp.put(columnName, resultSet.getObject(columnName));
						}
					}
					returnMap.add(temp);
				}
				resultSet.close();
			}else {
				statement.execute(query);
			}
			statement.close();
		}
		catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		//System.out.println(returnMap);
		return returnMap;
	}

	protected Object getValueFromListOfMap(List<HashMap<Object, Object>> listMap, String key, String value, String target_column) {
		// TODO Auto-generated method stub
		if(listMap.size() == 1) {
			return listMap.get(0).get(target_column);
		}else {
			for(Map temp : listMap) {
				if(temp.get(key).toString().equalsIgnoreCase(value)) {
					return temp.get(target_column);
				}
			}
		}
		return null;

	}

	protected List<Object> getListFromListOfMap(List<HashMap<Object, Object>> listMap, String key, String value, String target_column) {
		List<Object> ret = new ArrayList<Object>();
		for(Map temp : listMap) {
			if(temp.get(key).toString().equalsIgnoreCase(value)) {
				ret.add(null != target_column ? temp.get(target_column) : temp);
			}
		}
		return ret;

	}

	public  static String[][] getExcelUsers(String filePath,int sheetIndex,int columns){
		String[][] ret = null;
		try{
			String temp=null;
			File file = new File(filePath);
			FileInputStream fis = new FileInputStream(file);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheetAt(0);
			int row = sheet.getLastRowNum();
			ret = new String[row][columns];
			int cellType = 0;
			for (int i = 0; i < row; i++) {
				for (int j =0; j <columns; j++) {
					cellType = sheet.getRow(i+1).getCell(j).getCellType();
					if(cellType == CellType.NUMERIC.getCode()) {
						temp = String.valueOf((int)sheet.getRow(i+1).getCell(j).getNumericCellValue());
					}else {
						temp = sheet.getRow(i+1).getCell(j).getStringCellValue();
					}
					ret[i][j] = temp;
				}
			}
			workbook.close();
			System.out.println(Arrays.deepToString(ret));
		}catch(Exception e){
			e.printStackTrace();
		}

		return ret;
	}

	public String getAdminTokenForAD(){

		TokenDetail tokenDetail=null;

		try {
			System.out.println("getAdminToken method:: Starts ::: Get admin token  ");
			tokenDetail = new TokenDetail();
			ExecutorService service = Executors.newFixedThreadPool(1);
			AuthenticationContext context = null;
			context = new AuthenticationContext("https://login.microsoftonline.com/olamtest.onmicrosoft.com/",false,service);
			Future<AuthenticationResult> futureUsingCredentials =
					context.acquireToken("https://graph.windows.net","d38aa9b7-fdd1-48f3-85b9-0bda833965fd","tonystark@olamtest.onmicrosoft.com","Infinity123#",null);
			AuthenticationResult resultUsingAdminCredentials = futureUsingCredentials.get();
			tokenDetail.setAccessToken(resultUsingAdminCredentials.getAccessToken());
			tokenDetail.setRefreshToken(resultUsingAdminCredentials.getRefreshToken());
			tokenDetail.setIdToken(resultUsingAdminCredentials.getIdToken());
			System.out.println("getAdminToken method:: Ends ::: Get admin token  " );
			//System.out.println(tokenDetail.getAccessToken());
		}catch(Exception e) {
			e.printStackTrace();
		}
		return tokenDetail.getAccessToken();

	}

	public void writeToExcel(List<LinkedHashMap<String, String>> createdUserDetails, 
			LinkedHashMap<String, String> workerReporting, 
			HashMap<String, Integer> reportingMap, 
			int estateCount,
			String plantationType, List<Object> estateCodes) {
		XSSFWorkbook workbook = new XSSFWorkbook(); 
		XSSFSheet sheet = workbook.createSheet("User Details");
		int rownum = 0;
		Row row = null;
		int cellnum = 0;
		Cell cell = null;
		String estate = null;
		String workerloc = null;
		String temp;
		int tempInt = 0;
		int roleType;
		String roleCode;
		String userId;
		String keyForMap;
		for (Map userMap : createdUserDetails) { 
			int loop = 1;
			roleType = reportingMap.get((String)userMap.get("roleCode")); // integer value 0 , 1 etc
			roleCode = (String)userMap.get("roleCode"); // type of role like HAR, FER
			userId = (String)userMap.get("userId");
			estate = (String)userMap.get("locationCode");
			if(roleType <= 2 && !"EM".equals(roleCode)) {
				loop = estateCount;
				keyForMap =  "*" + estateCodes.get(loop-1).toString();
			}else if(roleType <= 3 || "AM".equals(roleCode)){
				keyForMap =  "*" + estate;
			}else {
				keyForMap = roleCode + userId + "*" + 99 + "#" + estate;
			}
			while(loop > 0) {
				row = sheet.createRow(rownum++); 
				cellnum = 0; 
				tempInt = 0;
				for(Object key : userMap.keySet()) {
					cell = row.createCell(cellnum++);
					cell.setCellValue(((String)userMap.get(key)));
				}
				if(!"WOR".equals((String)userMap.get("roleCode"))) {
					cell = row.createCell(cellnum++);
					temp = workerReporting.get(keyForMap);
					if(workerReporting.get(keyForMap) != null) {
						if(temp.contains("#")) {
							String[] arr = temp.split("#");
							cell.setCellValue(arr[0]);
							for(int j = 1; j < arr.length;j++) {
								cellnum = 0;
								row = sheet.createRow(rownum++);
								for(Object key : userMap.keySet()) {
									cell = row.createCell(cellnum++);
									cell.setCellValue(((String)userMap.get(key)));
								}
								cell = row.createCell(cellnum++);
								cell.setCellValue(arr[j]);
							}
						}else{
							cell.setCellValue(workerReporting.get(keyForMap));
						}
					}else{
						if("1".equalsIgnoreCase(plantationType)) {
							cell.setCellValue(workerReporting.get("HAR"+keyForMap));
						}else{
							cell.setCellValue(workerReporting.get("TAP"+keyForMap));
						}
						cell = row.createCell(cellnum++);
						cell.setCellValue(workerReporting.get("FER"+keyForMap));
					}
				}
				loop--;
				if(loop > 0){
					keyForMap =  "*" + estateCodes.get(loop-1).toString();
				}
			}
		}
		try { 
			FileOutputStream out = new FileOutputStream(new File("data/user_details.xlsx")); 
			workbook.write(out); 
			out.close(); 
			System.out.println("user_details.xlsx written successfully on disk."); 
		} 
		catch (Exception e) { 
			e.printStackTrace(); 
		}finally {
			try {
				workbook.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/*public static String[][] getPalmUsersHarvest(String sheetName){
		String[][] ret = null;
		try{

			String role=null, userID=null,workerIDOne=null,location=null;
			File file = new File("./data/user_details.xlsx");
			FileInputStream fis = new FileInputStream(file);

			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName);

			int row = sheet.getLastRowNum();
			ret = new String[row+1][4];
			for (int i = 0; i <= row; i++) {
				role = sheet.getRow(i).getCell(2).getStringCellValue();
				userID = sheet.getRow(i).getCell(1).getStringCellValue();
				location = null != sheet.getRow(i).getCell(3) ? sheet.getRow(i).getCell(3).getStringCellValue() : null;
				if(!"WOR".equals(role)){
					workerIDOne = null != sheet.getRow(i).getCell(4) ? sheet.getRow(i).getCell(4).getStringCellValue() : null;
					//password = sheet.getRow(i).getCell(0).getStringCellValue();

					//ret[i][0] = password;
					ret[i][0] = userID;
					ret[i][1] = role;
					ret[i][2] = workerIDOne;
					ret[i][3] = location;
					//ret[i][4] = workerIDTwo;
					if("GM".equals(role)) {
						gmLoc = location;
					}else if("RM".equals(role)) {
						rmLocation = location;
					}	
				}
				loc.put(userID, location);
			}
			System.out.println(Arrays.deepToString(ret));
			System.out.println(loc);

		}catch(Exception e){
			e.printStackTrace();
		}

		return ret;
	}*/

	public static String[][] getPalmUsersHarvest(String sheetName, boolean isQuickNote){
		String[][] ret = null;
		String[][] removeNull = null;
		try{
			Set<String> userIds = new LinkedHashSet<String>();
			String role=null, userID=null,workerIDOne=null,location=null;
			File file = new File("./data/user_details.xlsx");
			FileInputStream fis = new FileInputStream(file);

			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName);

			int row = sheet.getLastRowNum();
			ret = new String[row+1][4];
			Set<String> temp = new LinkedHashSet<String>();
			for (int i = 0; i <= row; i++) {
				role = sheet.getRow(i).getCell(2).getStringCellValue();
				userID = sheet.getRow(i).getCell(1).getStringCellValue();
				location = null != sheet.getRow(i).getCell(3) ? sheet.getRow(i).getCell(3).getStringCellValue() : null;

				if(!"WOR".equals(role)){
					workerIDOne = null != sheet.getRow(i).getCell(4) ? sheet.getRow(i).getCell(4).getStringCellValue() : null;
					//password = sheet.getRow(i).getCell(0).getStringCellValue();
					//ret[i][0] = password;
					if(!isQuickNote || !temp.contains(userID)){
						ret[i][0] = userID;
						ret[i][1] = role;
						ret[i][2] = workerIDOne;
						ret[i][3] = location;
						//ret[i][4] = workerIDTwo;
						temp.add(userID);
					}
					if("GM".equals(role)) {
						gmLoc = location;
					}else if("RM".equals(role)) {
						rmLocation = location;
					}	
				}
				loc.put(userID, location);
			}
			if(isQuickNote) {
				removeNull = new String[temp.size()][4];
				int j = 0;
				for (int i = 0; i < ret.length; i++) {
					if (ret[i][0] != null) {
						removeNull[j][0] = ret[i][0];
						removeNull[j][1] = ret[i][1];
						removeNull[j][2] = ret[i][2];
						removeNull[j][3] = ret[i][3];
						j++;
					}
				}
				System.out.println(Arrays.deepToString(removeNull));
				return removeNull;
			}
			System.out.println(Arrays.deepToString(ret));
			System.out.println(loc);
		}catch(Exception e){
			e.printStackTrace();
		}

		return ret;
	}

	public static String[][] getPalmUsersFertilization(String sheetName){
		String[][] ret = null;
		try{

			String role=null, userID=null,workerIDTwo=null,location=null;
			File file = new File("./data/user_details.xlsx");
			FileInputStream fis = new FileInputStream(file);

			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName);

			int row = sheet.getLastRowNum();
			ret = new String[row+1][4];
			for (int i = 0; i <= row; i++) {
				role = sheet.getRow(i).getCell(2).getStringCellValue();
				userID = sheet.getRow(i).getCell(1).getStringCellValue();
				location = null != sheet.getRow(i).getCell(3) ? sheet.getRow(i).getCell(3).getStringCellValue() : null;
				if(!"WOR".equals(role)){
					//password = sheet.getRow(i).getCell(0).getStringCellValue();
					workerIDTwo = null != sheet.getRow(i).getCell(5) ? sheet.getRow(i).getCell(5).getStringCellValue() : null;

					//ret[i][0] = password;
					ret[i][0] = userID;
					ret[i][1] = role;
					ret[i][2] = workerIDTwo;
					ret[i][3] = location;
					//ret[i][4] = workerIDTwo;

					if("GM".equals(role)) {
						gmLoc = location;
					}else if("RM".equals(role)) {
						rmLocation = location;
					}	
				}
				loc.put(userID, location);
			}


			System.out.println(Arrays.deepToString(ret));
			System.out.println(loc);

		}catch(Exception e){
			e.printStackTrace();
		}

		return ret;
	}

	public static String[][] getUsersForRegistration(String sheetName){
		String[][] ret = null;
		try{

			String role=null, userID=null,workerIDOne=null,location=null;
			File file = new File("./data/user_details.xlsx");
			FileInputStream fis = new FileInputStream(file);

			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName);

			int row = sheet.getLastRowNum();
			ret = new String[row+1][4];
			for (int i = 0; i <= row; i++) {
				role = sheet.getRow(i).getCell(2).getStringCellValue();
				//	if(!"WOR".equals(role)){
				//password = sheet.getRow(i).getCell(0).getStringCellValue();
				userID = sheet.getRow(i).getCell(1).getStringCellValue();
				location = null != sheet.getRow(i).getCell(3) ? sheet.getRow(i).getCell(3).getStringCellValue() : null;
				workerIDOne = null != sheet.getRow(i).getCell(4) ? sheet.getRow(i).getCell(4).getStringCellValue() : null;

				//ret[i][0] = password;
				ret[i][0] = userID;
				ret[i][1] = role;
				ret[i][2] = workerIDOne;
				ret[i][3] = location;
				//ret[i][4] = workerIDTwo;
				//}

			}
			System.out.println(Arrays.deepToString(ret));

		}catch(Exception e){
			e.printStackTrace();
		}

		return ret;
	}

	public String getRandomString(int n) {

		String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz";
		StringBuilder sb = new StringBuilder(n); 

		for (int i = 0; i < n; i++) { 

			// generate a random number between 
			// 0 to AlphaNumericString variable length 
			int index 
			= (int)(AlphaNumericString.length() 
					* Math.random()); 

			// add Character one by one in end of sb 
			sb.append(AlphaNumericString 
					.charAt(index)); 
		} 

		return sb.toString(); 
	}

	public void getHarvestData() {

		ripe= randomNum.nextInt(max - min + 1) + min;
		overRipe=randomNum.nextInt(max - min + 1) + min;
		underRipe=randomNum.nextInt(max - min + 1) + min;
		sickBunches=randomNum.nextInt(max - min + 1) + min;
		emptyBunches=randomNum.nextInt(max - min + 1) + min;
		unripeBunches=randomNum.nextInt(max - min + 1) + min;
		uncollectedBunches=randomNum.nextInt(max - min + 1) + min;
		unHarvestedBunches=randomNum.nextInt(max - min + 1) + min;
		path=randomNum.nextInt(max - min + 1) + min;
		circle=randomNum.nextInt(max - min + 1) + min;
		platform=randomNum.nextInt(max - min + 1) + min;
		frondExile=randomNum.nextInt(max - min + 1) + min;
		diseasedBunches=randomNum.nextInt(max - min + 1) + min;
		cropRecoveryTotalBunches=randomNum.nextInt(max - min + 1) + min;

	}

	public void getFertilizationData() {

		wrongType = 1;
		wrongDosage = 0;
		wrongPlacement = 0;
		wrongTiming = 1;
		missedOutPalm = 0;
		total = 10;
		balance = randomNum.nextInt(max - min + 1) + min;
		empty = randomNum.nextInt(max - min + 1) + min;

	}

	public int getRandomId() {
		Random random = new Random();
		int n = (int) (random.nextInt(99999999) + 100000+System.currentTimeMillis());

		return n;
	}

	public long getMorningNineTimestamp() {

		Calendar now = Calendar.getInstance();
		now.set(Calendar.HOUR, 0);
		now.set(Calendar.MINUTE, 0);
		now.set(Calendar.SECOND, 0);
		now.set(Calendar.HOUR_OF_DAY, 9);

		return now.getTimeInMillis();
	}

	public int validateAccessTokenTime() {

		java.util.Date date = new java.util.Date();
		Timestamp timestamp1 = new Timestamp(getAccessTokenTime);
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(timestamp1.getTime());
		cal.add(Calendar.SECOND, 98765);

		Timestamp timestamp2 = new Timestamp(System.currentTimeMillis());

		long milliseconds = timestamp2.getTime() - timestamp1.getTime();
		int seconds = (int) milliseconds / 1000;

		int minutes = (seconds % 3600) / 60;

		System.out.println(" Minutes: " + minutes);

		return minutes;

	}

	public void verifyDB(String query,String action,String columnName,String valueToBeCheck,String target_column) {
		Object obj = getValueFromListOfMap(db(query, action), columnName, valueToBeCheck, target_column);
		if(obj == null) {
			//reportRequest(columnName + "has value as null doesn't match with your expectedvalue : "+valueToBeCheck, "FAIL");
			System.out.println(columnName.toUpperCase() + " column value doesn't match with your expectedvalue : "+valueToBeCheck);
			try
			{ 
				throw new NullPointerException(columnName.toUpperCase() + " column value doesn't match with your expectedvalue : "+valueToBeCheck); 
			} 
			catch(NullPointerException e) 
			{ 
				throw e; // rethrowing the exception 
			} 
		}else {
			//reportRequest("passsssss", "PASS");
			System.out.println(columnName.toUpperCase() + " column value matches with your expectedvalue : "+valueToBeCheck);

		}
	}

	public void sleep(long time) {

		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public Properties loadObjectRepository() {
		Properties prop = new Properties();

		try {
			prop.load(new FileInputStream(new File("./Userdata.properties")));
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

		return prop;
	}

	public static String[][] getUserData(String sheetName){
		String[][] ret = null;
		try{

			String username=null;
			File file = new File("./data/UserDataForPasswordCheck.xlsx");
			FileInputStream fis = new FileInputStream(file);

			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName);

			int row = sheet.getLastRowNum();
			ret = new String[row+1][1];
			for (int i = 0; i <= row; i++) {
				//role = sheet.getRow(i).getCell(2).getStringCellValue();

				username = sheet.getRow(i).getCell(0).getStringCellValue();
				/*userID = sheet.getRow(i).getCell(1).getStringCellValue();
					workerIDOne = null != sheet.getRow(i).getCell(3) ? sheet.getRow(i).getCell(3).getStringCellValue() : null;
					workerIDTwo = null != sheet.getRow(i).getCell(4) ? sheet.getRow(i).getCell(4).getStringCellValue() : null;*/

				ret[i][0] = username;
				/*ret[i][1] = userID;
					ret[i][2] = role;
					ret[i][3] = workerIDOne;
					ret[i][4] = workerIDTwo;*/


			}
			System.out.println(Arrays.deepToString(ret));

		}catch(Exception e){
			e.printStackTrace();
		}

		return ret;
	}



}

