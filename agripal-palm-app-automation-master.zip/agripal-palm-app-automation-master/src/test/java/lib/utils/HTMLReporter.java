package lib.utils;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;

import org.apache.log4j.Logger;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.MediaEntityModelProvider;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.ExtentXReporter;
import com.aventstack.extentreports.reporter.KlovReporter;
import com.mongodb.MongoClientURI;

import io.restassured.RestAssured;

public abstract class HTMLReporter {

	public static ExtentHtmlReporter html;
	public static ExtentReports extent;
	public static ExtentTest svcTest;
	static ExtentXReporter extentXReports=null;
	static KlovReporter klov = null;
	public ExtentTest testSuite, test;
	public String testCaseName, testDescription, nodes, authors,category;
	public Logger log = Logger.getLogger("Execution Logger");  
	
	public static String packageName = "com.olam.gabon.mvpaks";
	
	

	//@BeforeSuite
	public void startReport() {
		
	//	RestAssured.baseURI = "https://zuul-sit-agripal.olamdigital.com";
		RestAssured.baseURI = "https://zuul-uat-agripal.olamdigital.com";

		
		html = new ExtentHtmlReporter("./reports/result.html");
		html.setAppendExisting(true);
		html.loadXMLConfig("./src/test/resources/extent-config.xml");
		klov = new KlovReporter();
		MongoClientURI mongo = new MongoClientURI("mongodb://admin:admin1234@ds153763.mlab.com:53763/klov");
		klov.initMongoDbConnection(mongo);
		klov.setProjectName("Agripal-RestAssured");
		klov.setKlovUrl("https://cloudreports-agripal.herokuapp.com");
		
		extentXReports = new ExtentXReporter("[admin:Test1234@ds15g3763.mlab.com]",53763);
		extentXReports.config().setServerUrl("https://cloudreports-agripal.herokuapp.com");
		extentXReports.config().setReportName("Agripal Test Reports");
		
		extent = new ExtentReports();
		extent.attachReporter(html,klov);
		//extent.attachReporter(html);
		
		try {
			extent.setSystemInfo("HostName", InetAddress.getLocalHost().getHostName());
			extent.setSystemInfo("IP Address", InetAddress.getLocalHost().getHostAddress());
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		extent.setSystemInfo("OS",System.getProperty("os.name"));
		extent.setSystemInfo("Username", "Saravanan G");
		extent.setSystemInfo("Java Version", System.getProperty("java.version"));
	
	}

	//@BeforeClass
	public ExtentTest startTestCase(String testCaseName, String testDescription) {
		testSuite = extent.createTest(testCaseName, testDescription);		
		return testSuite;
	}

	//@BeforeMethod
	public ExtentTest startTestModule(String nodes) {
		test = testSuite.createNode(nodes);
		return test;
	}

	//@AfterSuite
	public void endResult() {
		extent.flush();
	}

	public abstract long takeSnap();

	public void reportStep(String desc,String status, boolean bSnap) {

		MediaEntityModelProvider img = null;

		if(bSnap && !status.equalsIgnoreCase("INFO")){

			long snapNumber = 100000L;
			snapNumber = takeSnap();
			try {
				img = MediaEntityBuilder.createScreenCaptureFromPath
						("./../reports/images/"+snapNumber+".png").build();
			} catch (IOException e) {

			}
		}		

		if(status.equalsIgnoreCase("PASS")) {
			test.pass(desc, img);		
		}else if(status.equalsIgnoreCase("FAIL")) {
			test.fail(desc, img);
			throw new RuntimeException();
		}else if(status.equalsIgnoreCase("WARNING")) {
			test.warning(desc, img);		
		}else {
			test.info(desc);
		}
	}

	public void reportStep(String desc, String status) {
		reportStep(desc, status, true);
	}

	public static void reportRequest(String desc, String status) {
		
		MediaEntityModelProvider img = null;
		if(status.equalsIgnoreCase("PASS")) {
			svcTest.pass(desc, img);		
		}else if(status.equalsIgnoreCase("FAIL")) {
			svcTest.fail(desc, img);
			throw new RuntimeException();
		}else if(status.equalsIgnoreCase("WARNING")) {
			svcTest.warning(desc, img);		
		}else {
			svcTest.info(desc);
		}	
	}


}
