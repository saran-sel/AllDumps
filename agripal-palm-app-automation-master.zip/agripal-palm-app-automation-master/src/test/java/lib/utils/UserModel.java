package lib.utils;

public class UserModel {

	String userId;
	String userCode;
	String manager;
	int hierarchy;
	String locationCode;
	
	

	public UserModel(String userId, String userCode, String manager, int hierarchy,String locationCode) {
	this.userId = userId;
	this.userCode = userCode;
	this.manager = manager;
	this.hierarchy = hierarchy;
	this.locationCode = locationCode;
	}
	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getManager() {
		return manager;
	}
	public void setManager(String manager) {
		this.manager = manager;
	}
	public int getHierarchy() {
		return hierarchy;
	}
	public void setHierarchy(int hierarchy) {
		this.hierarchy = hierarchy;
	}

}
