package attributes;

import org.testng.annotations.Test;

public class Laptops {
	
	@Test(priority=-3)
	public void getMouse() {
		
	}
	
	@Test(priority=2)
	public void getKeyboard() {
		
	}
	
	@Test(priority=2)
	public void getMonitor() {
		
	}

}
