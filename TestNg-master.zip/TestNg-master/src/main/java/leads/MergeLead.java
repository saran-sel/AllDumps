package leads;

import org.testng.annotations.Test;

public class MergeLead {

	@Test(groups= {"leads","Sudharsan"})
	public void mergeLead() {
		
	}
}
