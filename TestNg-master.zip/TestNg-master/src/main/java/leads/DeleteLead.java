package leads;

import org.testng.annotations.Test;

public class DeleteLead {

	@Test(groups= {"leads","Babu"})
	public void deleteLead() {
		
	}
}
