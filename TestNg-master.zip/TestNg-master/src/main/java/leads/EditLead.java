package leads;

import org.testng.annotations.Test;

public class EditLead {

	@Test(groups= {"leads","Babu"})
	public void editLead() {
		
	}
}
