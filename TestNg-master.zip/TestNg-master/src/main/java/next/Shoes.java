package next;

import org.testng.annotations.Test;

public class Shoes {
	
	@Test
	public void getBrand() {
		
	}
	
	@Test
	public void getColor() {
		
	}

}
