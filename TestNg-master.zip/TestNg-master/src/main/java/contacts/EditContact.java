package contacts;

import org.testng.annotations.Test;

public class EditContact {

	@Test(groups= {"contacts","Sudharsan"},dependsOnGroups= {"leads"})
	public void editContact() {
		
	}
}
