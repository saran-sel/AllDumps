package contacts;

import org.testng.annotations.Test;

public class MergeContact {

	@Test(groups= {"contacts","Sudharsan"},dependsOnGroups= {"leads"})
	public void mergeContact() {
		
	}
}
