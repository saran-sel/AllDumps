package contacts;

import org.testng.annotations.Test;

public class UploadContact {
	
	@Test(groups= {"Babu"})
	public void createContact() {
		
	}

}
