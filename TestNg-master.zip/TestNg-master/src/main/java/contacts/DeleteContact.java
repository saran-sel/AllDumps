package contacts;

import org.testng.annotations.Test;

public class DeleteContact {

	@Test(groups= {"contacts","Sudharsan"},dependsOnGroups= {"leads"})
	public void deleteContact() {
		
	}
}
