package testng7.features;

import org.testng.annotations.Test;

public class Test3 {
	@Test
	public void testcase3() {
		System.out.println("testcase3");
		System.out.println(Thread.currentThread().getId());

	}

}
